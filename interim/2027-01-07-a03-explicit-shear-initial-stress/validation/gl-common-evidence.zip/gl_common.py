"""Project this work's freshly solved GL5/7 N8 paths onto the fixed common i/4 coordinates."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2]
HERE=ROOT/'interim/2027-01-07-a03-explicit-shear-initial-stress'
sys.path.insert(0,str(HERE))
from a03shear_binding import load,values,compare,study
from a03shear_fixture import plan
from a03shear_report import SELECTED
from a03shear_run import write

def main(run,out):
 out.mkdir(parents=True,exist_ok=False);specs=plan()['specs'];rows={};vectors={}
 for left in specs:
  if left['n']!=8 or left['volume']!=5:continue
  right=next(s for s in specs if s['stress']==left['stress'] and s['n']==8 and s['volume']==7)
  a,b=(load(run,s,'independent',4) for s in (left,right))
  assert len(a)==len(b)==16
  assert [r['progress'] for r,_ in a]==[.25,.5,.75,1.]*4
  rows[left['stress']]=compare(a,b)
  vectors[left['stress']]={k:(values(a,k)-values(b,k)).tolist() for k in SELECTED}
 write(out/'difference-vectors.json',vectors)
 write(out/'gl-common-coordinates.json',dict(passed=False,a03_complete=False,diagnostic_only=True,
  new_equilibrium_solves=0,formal_gl_paths_used=18,common_states_per_path=16,
  coordinates=[r for r,_ in a],fixed_order='phase / i/4 / physical connectivity / component; C-order; math.fsum; GL5-left minus GL7-right',
  original_full_n8_32_point_metrics_preserved=True,old_historical_saved_values_used_as_new_solves=False,
  comparisons=rows,vector_bytes=(out/'difference-vectors.json').stat().st_size,
  vector_sha256=hashlib.sha256((out/'difference-vectors.json').read_bytes()).hexdigest()))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a.run,a.output)
