"""Check every original tree entry; byte-check materialized originals except authorized P6 append/pin."""
from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path.cwd();base='cdaf850c0347c8d841decce7ddff608d03ae7933';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def tree(ref):
 values={}
 for raw in subprocess.check_output(['git','ls-tree','-r','-z',ref],env=env).split(b'\0'):
  if not raw:continue
  meta,path=raw.split(b'\t');mode,kind,oid=meta.decode().split();values[path.decode()]=dict(mode=mode,oid=oid)
 return values
before=tree(base);after=tree('HEAD')
allowed={'interim/2026-12-10-ci-p601-inventory-fix/inventory.toml','interim/2026-12-06-p6-01-status-reconciliation/audit_status.py'}
changed=[p for p in before if before[p]!=after.get(p)];assert set(changed)==allowed,changed
added=sorted(set(after)-set(before));assert all(p.startswith('interim/2027-01-07-a03-explicit-shear-initial-stress/') or p=='tests/test_a03_explicit_shear_initial_stress.py' for p in added)
old_inventory=subprocess.check_output(['git','show',base+':interim/2026-12-10-ci-p601-inventory-fix/inventory.toml'],env=env)
new_inventory=Path('interim/2026-12-10-ci-p601-inventory-fix/inventory.toml').read_bytes();assert new_inventory.startswith(old_inventory)
old_auditor=subprocess.check_output(['git','show',base+':interim/2026-12-06-p6-01-status-reconciliation/audit_status.py'],env=env)
new_auditor=Path('interim/2026-12-06-p6-01-status-reconciliation/audit_status.py').read_bytes()
pattern=rb"SUPPLEMENTAL_SHA256 = '[0-9a-f]{64}'"
assert re.sub(pattern,b'PIN',old_auditor)==re.sub(pattern,b'PIN',new_auditor)
pin=re.search(pattern,new_auditor).group().split(b"'")[1].decode();assert hashlib.sha256(new_inventory).hexdigest()==pin
original=json.loads(Path('work/a03shear/recovery-retry/preservation-before-registration.json').read_text())
proof=[]
for row in original['files']:
 name=row['path']
 if name in allowed:continue
 p=Path(name);data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();assert sha==row['sha256'],name
 oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert oid==row['git_blob_sha1'],name
 mode='100755' if p.stat().st_mode & 0o111 else '100644';assert mode==row['mode'],name
 proof.append(dict(path=name,bytes=len(data),sha256=sha,git_blob_sha1=oid,mode=mode))
out=Path('work/a03shear/preservation-final');out.mkdir(exist_ok=False)
(out/'files.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(dict(base=base,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 all_original_tree_entries_retained=True,all_original_nc_tree_entries_byte_identity_by_git_oid=True,original_tree_files=len(before),
 original_materialized_files=original['count'],original_materialized_bytes=original['bytes'],unchanged_materialized_files=len(proof),
 authorized_changes=sorted(allowed),inventory_old_exact_prefix=True,auditor_only_sha_pin_changed=True,
 added_paths=added,byte_and_git_mode_failures=0,excluded_from_materialized_byte_check='existing CI NC postfold parts only; every original OID/mode checked in tree'),indent=2)+'\n')
print(json.dumps(dict(unchanged_files=len(proof),all_old_tree_entries_retained=True,authorized_changes=sorted(allowed))))
