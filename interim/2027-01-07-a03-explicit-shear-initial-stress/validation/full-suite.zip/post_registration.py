"""Repeat only the affected P6 and new diagnostic contracts; do not inflate full-suite counts."""
from pathlib import Path
import json,unittest
ROOT=Path.cwd();out=ROOT/'interim/2027-01-07-a03-explicit-shear-initial-stress/validation/post-registration';out.mkdir(exist_ok=False)
reports={}
for name,pattern in (('p6','test_p6*.py'),('a03shear','test_a03_explicit_shear_initial_stress.py')):
 suite=unittest.TestLoader().discover(str(ROOT/'tests'),pattern=pattern);count=suite.countTestCases()
 with (out/(name+'.log')).open('x',encoding='utf-8') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 reports[name]=dict(discovered=count,executed=result.testsRun,passed=max(0,result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped)-len(result.expectedFailures)-len(result.unexpectedSuccesses)),
  failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),unexecuted=max(0,count-result.testsRun),
  expected_failures=len(result.expectedFailures),unexpected_successes=len(result.unexpectedSuccesses),not_added_to_full_unique_count=True)
 assert result.wasSuccessful() and count==result.testsRun and not result.skipped,reports[name]
(out/'results.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports))
