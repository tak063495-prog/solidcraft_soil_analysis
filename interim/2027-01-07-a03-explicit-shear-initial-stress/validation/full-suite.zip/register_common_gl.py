"""Append the common-coordinate GL source with the same fixed Git/SHA/typed-bool protocol."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
ROOT=Path.cwd();PREFIX='interim/2027-01-07-a03-explicit-shear-initial-stress/'
p=argparse.ArgumentParser();p.add_argument('--commit',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.commit)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1');name=PREFIX+'validation/gl-common-coordinates.json';raw=(ROOT/name).read_bytes()
assert raw==subprocess.check_output(['git','show',a.commit+':'+name],env=env)
value=json.loads(raw);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert subprocess.check_output(['git','rev-parse',a.commit+':'+name],env=env,text=True).strip()==blob
inventory=ROOT/'interim/2026-12-10-ci-p601-inventory-fix/inventory.toml';auditor=ROOT/'interim/2026-12-06-p6-01-status-reconciliation/audit_status.py'
before=inventory.read_bytes();sid='a03shear_20270107_gl_common';assert ('id = "'+sid+'"').encode() not in before
addition='\n[[sources]]\n'+''.join(k+' = '+json.dumps(v)+'\n' for k,v in dict(id=sid,path=name,commit=a.commit,kind='json',sha256=sha,git_blob_sha1=blob).items())
for key in ('passed','a03_complete','diagnostic_only'):
 assert type(value[key]) is bool
 addition+='[[sources.status_keys]]\npointer = '+json.dumps('/'+key)+'\nvalue_json = '+json.dumps(json.dumps(value[key]))+'\n'
after=before+addition.encode();oldpin=hashlib.sha256(before).hexdigest();newpin=hashlib.sha256(after).hexdigest()
text=auditor.read_text(encoding='utf-8');old="SUPPLEMENTAL_SHA256 = '"+oldpin+"'";new="SUPPLEMENTAL_SHA256 = '"+newpin+"'";assert text.count(old)==1
inventory.write_bytes(after);auditor.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(dict(path=name,commit=a.commit,sha256=sha,git_blob_sha1=blob,old_inventory_exact_prefix=True,auditor_only_pin_changed=True,inventory_sha256=newpin),f,indent=2);f.write('\n')
