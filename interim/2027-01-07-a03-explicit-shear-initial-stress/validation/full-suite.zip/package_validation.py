"""Small immutable evidence archives with file/member hashes and readback."""
from pathlib import Path
import argparse,hashlib,json,zipfile

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def seal(destination,sources):
 entries={}
 with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for prefix,source in sources:
   source=Path(source)
   paths=sorted(source.rglob('*')) if source.is_dir() else [source]
   for path in paths:
    if not path.is_file() or '__pycache__' in path.parts:continue
    name=prefix+'/'+path.relative_to(source).as_posix() if source.is_dir() else prefix
    assert name not in entries
    entries[name]=dict(bytes=path.stat().st_size,sha256=sha(path));z.write(path,name)
 with zipfile.ZipFile(destination) as z:
  assert set(z.namelist())==set(entries) and len(z.namelist())==len(entries)
  for name,record in entries.items():
   data=z.read(name);assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
 result=dict(archive=destination.name,bytes=destination.stat().st_size,sha256=sha(destination),entries=entries,all_members_read_back_sha_verified=True)
 destination.with_name(destination.stem+'-index.json').write_text(json.dumps(result,indent=2)+'\n')
 return {k:v for k,v in result.items() if k!='entries'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);p.add_argument('--source',action='append',nargs=2,default=[]);a=p.parse_args();print(json.dumps(seal(a.destination,a.source)))
