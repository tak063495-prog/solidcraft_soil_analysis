"""Fetch fixed blobs individually; keep working bytes, drop only newly fetched single-blob transport packs."""
from pathlib import Path
import subprocess,os,hashlib,json,time
from concurrent.futures import ThreadPoolExecutor
ROOT=Path.cwd();OUT=ROOT/'work/a03shear/recovery-retry';OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1')
base=subprocess.check_output(['git','rev-parse','cdaf850'],text=True).strip()
records=[]
raw=subprocess.check_output(['git','ls-tree','-r','-z',base],env=ENV)
for line in raw.split(b'\0'):
 if not line:continue
 meta,path=line.split(b'\t');mode,kind,oid=meta.decode().split();path=path.decode()
 if path.startswith('interim/2026-11-10-nc-postfold-branches/evidence.tar.gz.part'):continue
 records.append((mode,oid,path))
# Fetch into temporary bare transport repositories, so main Git never doubles archive storage.
def restore(item):
 mode,oid,name=item;p=ROOT/name
 if p.exists():return dict(path=name,oid=oid,existing=True)
 start=time.monotonic();repo=OUT/('transport-'+oid)
 subprocess.run(['git','init','--bare','-q',str(repo)],check=True)
 try:
  with (OUT/(oid+'.log')).open('x') as log:
   cmd=['git','-C',str(repo),'fetch','--filter=blob:none','--no-tags','--no-write-fetch-head','https://github.com/tak063495-prog/solidcraft_soil_analysis.git',oid]
   subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
  p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_name(p.name+'.a03shear-transport')
  with temp.open('xb') as f:subprocess.run(['git','-C',str(repo),'cat-file','blob',oid],stdout=f,check=True)
  data=temp.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert actual==oid
  temp.rename(p);p.chmod(0o755 if mode=='100755' else 0o644)
  result=dict(path=name,oid=oid,size=len(data),sha256=hashlib.sha256(data).hexdigest(),elapsed_seconds=time.monotonic()-start,fixed_commit=base)
  (OUT/(oid+'.json')).write_text(json.dumps(result,indent=2)+'\n')
  return result
 finally:
  import shutil;shutil.rmtree(repo)
missing=[r for r in records if not (ROOT/r[2]).exists()]
by_oid={}
for r in missing:by_oid.setdefault(r[1],[]).append(r)
def group_restore(group):
 result=restore(group[0])
 import shutil
 for mode,oid,name in group[1:]:
  target=ROOT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/group[0][2],target)
 return result

print('missing',len(missing),flush=True)
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for i,r in enumerate(pool.map(group_restore,by_oid.values())):
  results.append(r)
  if i%50==0:print(i+1,'/',len(missing),flush=True)
(OUT/'restoration.json').write_text(json.dumps(dict(base=base,files=results,excluded='existing CI NC postfold parts only',archives_modified=False),indent=2)+'\n')
# All existing materialized old files must match original Git object and mode.
proof=[]
for mode,oid,name in records:
 p=ROOT/name;data=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==oid,name
 proof.append(dict(path=name,git_blob_sha1=oid,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),mode=mode))
(OUT/'preservation-before-registration.json').write_text(json.dumps(dict(base=base,files=proof,count=len(proof),bytes=sum(x['bytes'] for x in proof),all_fixed_git_blobs_match=True),indent=2)+'\n')
print('preservation',len(proof),flush=True)
