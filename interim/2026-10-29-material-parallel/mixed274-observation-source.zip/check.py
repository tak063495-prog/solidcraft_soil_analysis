"""Measure actual three-field construction; require exact old fields before accepting timings."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent;root=p.parents[1];runtime=p/'runtime';old=root/'runs/mcc-kernel-profiling-development-20261029-v1'
read=lambda q:json.loads(q.read_text('utf-8-sig'));sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(old/'terminal.json')['passed'] and sha(old/'frozen-profiler/soil-fem-3d.exe')==read(old/'terminal.json')['profiler_solver_sha256']
with (p/'driver-child.json').open('x') as f:json.dump(dict(pid=os.getpid(),executable=sys._base_executable,script=str(Path(__file__).resolve()),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(old/'runtime/target'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
records=[]
def call(label,args):
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=list(map(str,args));began=time.monotonic()
    with (p/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (p/(label+'-child.json')).open('x') as f:json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
        code=child.wait()
    row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began);records.append(row)
    with (p/(label+'-terminal.json')).open('x') as f:json.dump(row,f,indent=2)
    print(json.dumps(row),flush=True);assert code==0
cargo='C:/Users/link_/.cargo/bin/cargo.exe'
call('format',[cargo,'fmt','--all'])
sys.path.insert(0,str(runtime/'tools'));from freeze_sources import manifest,freeze
quality=p/'quality';quality.mkdir();freeze(quality);sources=manifest();base=read(old/'source-snapshot.json')
assert len(sources)==611 and {n for n,h in sources.items() if h!=base[n]}=={'Cargo.toml','src/stages.rs','src/stages_mixed.rs'}
call('clippy',[cargo,'clippy','--locked','--all-targets','--features','kernel-profile','--','-D','warnings'])
call('build',[cargo,'build','--locked','--release','--features','kernel-profile'])
solver=p/'solver/soil-fem-3d.exe';solver.parent.mkdir();shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release/soil-fem-3d.exe',solver);solver_sha=sha(solver)
baseline=root/'runs/native-recovery-worker-development-20261029-v1/controls/continuous/workflow/analysis'
analysis=p/'workflow/analysis';(analysis/'ground').mkdir(parents=True)
paths=['ground/mesh.json','ground/ground.json','stages.json']
for name in paths:shutil.copy2(baseline/name,analysis/name);assert sha(baseline/name)==sha(analysis/name)
binding={name:sha(analysis/name) for name in paths}
job=analysis/'solver-job'
call('prepare',[solver,'prepare-durable-stages-job',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stages.json','4',job])
call('solve',[job/'solver/soil-fem-3d.exe','run-stages-job',job])
shutil.copy2(job/'result.json',analysis/'stage-results.json')
call('export',[sys.executable,runtime/'tools/export_stages.py',analysis/'ground/mesh.json',analysis/'stage-results.json',analysis/'results'])
call('verify',[sys.executable,runtime/'tools/verify_stage_package.py',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stage-results.json',analysis/'results','--solver',solver])
def stable(v):
    if isinstance(v,dict):return {k:stable(x) for k,x in v.items() if k!='elapsed_seconds'}
    if isinstance(v,list):return [stable(x) for x in v]
    return v
expected=read(baseline/'stage-results.json');actual=read(analysis/'stage-results.json')
for key in ['frames','last_committed','reference_displacement_m','integration_points','excavation_audits','transition_audits','geostatic','attempts']:
    assert stable(expected[key])==stable(actual[key]),key
metrics={}
for line in (p/'solve.log').read_text('utf-8').splitlines():
    if not line.startswith('{'):continue
    try:d=json.loads(line)
    except ValueError:continue
    if d.get('schema')!='soil-fem-kernel-profile/1':continue
    v=metrics.setdefault(d['backend'],dict(completed_evaluations=0,material_point_evaluations=0,total_seconds=0.,material_seconds=0.))
    v['completed_evaluations']+=1;v['material_point_evaluations']+=d['material_points'];v['total_seconds']+=d['total_seconds'];v['material_seconds']+=d['material_seconds']
    for key in ['setup_seconds','tangent_assembly_seconds','structure_seconds','residual_reduction_seconds']:
        v[key]=v.get(key,0.)+d.get(key,0.)
for v in metrics.values():v['material_fraction']=v['material_seconds']/v['total_seconds']
assert 'projected_p1_volume' in metrics and manifest()==sources and sha(solver)==solver_sha
assert all(sha(analysis/name)==h for name,h in binding.items())
with (p/'terminal.json').open('x') as f:json.dump(dict(passed=True,private_observation_only=True,actual_native274_immutable_prepared_inputs=True,
    all5_stages_and_all8_physical_groups_exact_to_root665b=True,stage_export_and_mechanical_audit_passed=True,only_elapsed_seconds_omitted=True,
    metrics_by_backend=metrics,failed_evaluations_not_included=True,concurrent_other_jobs=True,isolated_throughput_benchmark=False,
    earlier_displacement_profiler_full272_and_theory_separate=True,new_observation_not_a_fresh_full272_run=True,
    production_unchanged=True,source_files=611,solver_sha256=solver_sha,records=records,p6_complete=False),f,indent=2)
print(json.dumps(dict(passed=True,metrics_by_backend=metrics,all8_groups_exact=True,production_unchanged=True)),flush=True)
