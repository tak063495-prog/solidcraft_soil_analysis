import hashlib,json,os,pathlib,resource,subprocess,sys,time
root=pathlib.Path('/workspace/work/nc96')
binary=pathlib.Path('/workspace/work/pr13/target/release/examples/nc_history_trace')
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
cpu=int(sys.argv[1])
os.sched_setaffinity(0,{cpu})
resource.setrlimit(resource.RLIMIT_AS,(32_000_000_000,32_000_000_000))
for mode in sys.argv[2:]:
 case='stages.json' if mode=='baseline' else f'stages-{mode}.json'
 start=time.monotonic()
 with (root/f'{mode}.log').open('x') as log:
  p=subprocess.Popen([str(binary),'direct','mesh.json','ground.json',case,mode],stdout=log,stderr=subprocess.STDOUT,cwd=root)
  peak=0
  while p.poll() is None:
   try:
    status=pathlib.Path(f'/proc/{p.pid}/status').read_text()
    peak=max([peak]+[int(l.split()[1])*1024 for l in status.splitlines() if l.startswith('VmHWM:')])
   except FileNotFoundError:pass
   if time.monotonic()-start>21600:p.kill();p.wait();break
   time.sleep(.3)
  report=dict(mode=mode,exit_code=p.returncode,seconds=time.monotonic()-start,peak_hwm_bytes=peak,affinity=cpu,binary_sha256=sha)
  (root/f'{mode}-process.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
  if p.returncode:sys.exit(p.returncode)
