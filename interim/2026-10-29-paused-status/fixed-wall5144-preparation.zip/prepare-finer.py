"""Create the next fixed-wall discretization using the prior accepted preparation procedure."""
from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent
root=p.parents[1]
previous=root/'runs/native-mcc-compact-pit-fixed-surface-refinement-20261028-v2'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(previous/'terminal.json')['passed']
assert read(previous/'field-verification.json')['seed_load_and_recorded_cutback_gates_passed']
assert read(previous/'wall-spatial-topology-proof.json')['wall_mesh_equivalent_within_tolerance']
text=(previous/'run.py').read_text(encoding='utf-8')
replacements={
    'inside_size_m=.4,outside_size_m=1.':'inside_size_m=.3,outside_size_m=.8',
    'MeshSizeMin",400.':'MeshSizeMin",300.',
    'MeshSizeMax",1000.':'MeshSizeMax",800.',
    "\\'VIn\\':400.,\\'VOut\\':1000.":"\\'VIn\\':300.,\\'VOut\\':800.",
    'local_box_size_m=.4':'local_box_size_m=.3',
}
for a,b in replacements.items():
    assert text.count(a)==1,(a,text.count(a))
    text=text.replace(a,b,1)
compile(text,str(p/'run.py'),'exec')
with (p/'run.py').open('x',encoding='utf-8') as stream:stream.write(text)
with (p/'procedure-binding.json').open('x') as stream:
    json.dump(dict(previous_preparation_sha256=sha(previous/'run.py'),generated_preparation_sha256=sha(p/'run.py'),
        replacements=replacements,wall_surface_target_unchanged_m=1.,volume_inside_m=.3,volume_outside_m=.8,
        solver_start_not_authorized_by_this_helper=True,p6_complete=False),stream,indent=2)
subprocess.run([sys.executable,str(p/'run.py')],check=True)
