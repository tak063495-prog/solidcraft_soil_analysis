"""Run the separately verified field-only5144-element preparation, unchanged."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent;root=p.parents[1];runtime=p/'runtime';read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'));sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'preparation-only.json')['prepared'] and read(p/'wall-spatial-topology-proof.json')['wall_mesh_equivalent_within_tolerance']
prepared=read(p/'preparation.json');assert prepared['elements']==5144 and prepared['plates']==832
sources=read(p/'source-snapshot.json');assert len(sources)==600 and all(sha(runtime/n)==h for n,h in sources.items())
assert all(sha(Path(n))==h for n,h in prepared['sha256'].items())
solver=root/'runs/mcc-midpoint-quality-20261028-v9/solver/soil-fem-3d.exe';assert sha(solver)=='07064591643cbb32ec0d7b29506d592bb7196c3a7bae6f50afb6a0e13f43b4f6'
analysis=p/'workflow/analysis';job=analysis/'solver-job';bound={**prepared['sha256'],str(Path(__file__)):sha(Path(__file__))}
records=read(p/'progress.json')['records'];env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
def call(label,args):
 if (p/'pause-requested').exists():raise SystemExit(2)
 command=list(map(str,args));started=time.monotonic()
 with (p/(label+'.log')).open('x',encoding='utf-8') as log:
  child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  with (p/(label+'-child.json')).open('x') as stream:json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
  code=child.wait()
 row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-started);records.append(row);print(json.dumps(row),flush=True);assert code==0
call('prepare-solver',[solver,'prepare-stages-job',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stages.json',job])
call('solve',[solver,'run-stages-job',job]);shutil.copy2(job/'result.json',analysis/'stage-results.json')
call('export',[sys.executable,runtime/'tools/export_stages.py',analysis/'ground/mesh.json',analysis/'stage-results.json',analysis/'results'])
call('verify',[sys.executable,runtime/'tools/verify_stage_package.py',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stage-results.json',analysis/'results','--solver',solver])
assert all(sha(Path(n))==h for n,h in bound.items()) and all(sha(runtime/n)==h for n,h in sources.items())
with (p/'terminal.json').open('x') as stream:json.dump(dict(passed=True,records=records,sources_and_inputs_unchanged=True,sha256=bound,private_discretization_experiment=True,native_large_result_display_not_accepted=True,spatial_convergence_accepted=False,p6_complete=False),stream,indent=2)
