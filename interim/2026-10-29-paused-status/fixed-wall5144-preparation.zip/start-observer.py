"""Reuse the process-identity-checked Windows observer on the actual5144-cell construction solve."""
from pathlib import Path
import datetime,json,os,subprocess,sys
p=Path(__file__).resolve().parent
original=p.parent/'mcc-nonlinear-performance-20261028-v1/watch.py'
text=original.read_text(encoding='utf-8')
start=text.index('jobs=');end=text.index('\n',start)
text=text[:start]+"jobs={'mesh5144':p}"+text[end:]
needle="job=folder/('workflow/analysis/solver-job' if label=='mesh2262' else 'analysis/solver-job')"
assert text.count(needle)==1
text=text.replace(needle,"job=folder/'workflow/analysis/solver-job'",1)
compile(text,str(p/'watch.py'),'exec')
with (p/'watch.py').open('x',encoding='utf-8') as stream:stream.write(text)
command=[sys.executable,str(p/'watch.py'),'mesh5144']
with (p/'observer.log').open('x',encoding='utf-8') as log:
    child=subprocess.Popen(command,cwd=p.parents[1],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    with (p/'observer-child.json').open('x') as stream:
        json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
    code=child.wait()
assert code==0
