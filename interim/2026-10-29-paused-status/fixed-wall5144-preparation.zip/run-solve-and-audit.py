"""Run the5144-cell fixed-wall case with the unchanged prior-series solver and audits."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
p=Path(__file__).resolve().parent
previous=p.parent/'native-mcc-compact-pit-fixed-surface-refinement-20261028-v2'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert not (p/'pause-requested').exists()
assert read(p/'wall-spatial-topology-proof.json')['wall_mesh_equivalent_within_tolerance']
assert read(p/'preparation.json')['elements']==5144
original=(previous/'solve-prepared.py').read_text(encoding='utf-8')
assert original.count("prepared['elements']==2865")==1
solve=original.replace("prepared['elements']==2865","prepared['elements']==5144",1).replace('field-only2865-element','field-only5144-element')
audit=(previous/'audit-fields.py').read_text(encoding='utf-8')
assert audit.count("sys.path.insert(0,str(root/'tools'))")==1
audit=audit.replace("sys.path.insert(0,str(root/'tools'))","sys.path.insert(0,str(p/'runtime/tools'))",1)
for name,text in [('solve-prepared.py',solve),('audit-fields.py',audit)]:
    compile(text,str(p/name),'exec')
    with (p/name).open('x',encoding='utf-8') as stream:stream.write(text)
binding={str(q):sha(q) for q in [p/'solve-prepared.py',p/'audit-fields.py',p/'wall-spatial-topology-proof.json',p/'preparation.json',Path(__file__)]}
for label,program in [('series-solve','solve-prepared.py'),('independent-fields','audit-fields.py')]:
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=[sys.executable,str(p/program)]
    with (p/(label+'-driver.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=p.parents[1],stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (p/(label+'-driver-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    assert code==0,(label,code)
assert all(sha(Path(n))==h for n,h in binding.items())
assert read(p/'field-verification.json')['seed_load_and_recorded_cutback_gates_passed']
with (p/'study-terminal.json').open('x') as stream:
    json.dump(dict(passed=True,soil_elements=5144,wall_nodes=440,plates=832,prior_series_solver_unchanged=True,
        own_frozen600_python_audit=True,sha256=binding,spatial_comparison_pending=True,
        native_gpu_acceptance_not_part_of_this_run=True,spatial_convergence_accepted=False,p6_complete=False),stream,indent=2)
print('PASS fixed-wall5144 mechanics and independent field audit; spatial comparison pending',flush=True)
