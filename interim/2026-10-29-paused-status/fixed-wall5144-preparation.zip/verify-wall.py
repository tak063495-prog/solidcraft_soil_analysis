"""Check fixed structural geometry and oriented plate declarations before solving."""
from pathlib import Path
import hashlib,json
import numpy as np
from scipy.spatial import cKDTree
p=Path(__file__).resolve().parent
left=p.parent/'native-mcc-compact-pit-fixed-surface-refinement-20261028-v2'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'preparation-only.json')['solver_not_started']
assert read(left/'terminal.json')['passed']
analyses=[q/'workflow/analysis' for q in [left,p]]
meshes=[read(q/'ground/mesh.json') for q in analyses]
cases=[read(q/'stages.json') for q in analyses]
configs=[c['beam_system'] for c in cases]
xyz=[np.asarray([n['position_m'] for n in c['nodes']]) for c in configs]
distance,mapping=cKDTree(xyz[1]).query(xyz[0])
assert len(xyz[0])==len(xyz[1])==440 and len(set(mapping))==440
assert distance.max()==0.
for c in configs:assert all(n['match_soil_node'] for n in c['nodes'])
def plates(c):
    nodes={n['id']:tuple(n['position_m']) for n in c['nodes']}
    result={}
    for plate in c['plates']:
        corners=[nodes[n] for n in plate['nodes']]
        key=min(tuple(corners[k:]+corners[:k]) for k in range(3))
        assert key not in result
        result[key]={n:v for n,v in plate.items() if n not in ['id','nodes']}
    return result
assert plates(configs[0])==plates(configs[1]) and len(configs[0]['plates'])==len(configs[1]['plates'])==832
for key in ['sections','members','plate_sections','rotation_length_scale_m','maximum_condensed_dofs']:
    assert configs[0][key]==configs[1][key],key
assert meshes[0]['regions']==meshes[1]['regions']
assert read(analyses[0]/'ground/ground.json')==read(analyses[1]/'ground/ground.json')
assert read(left/'workflow/conformal/stages.json')==read(p/'workflow/conformal/stages.json')
assert cases[0]['settings']==cases[1]['settings']
for q in [left,p]:
    prep=read(q/'preparation.json')
    assert all(sha(Path(n))==h for n,h in prep['sha256'].items())
paths=[Path(__file__),p/'preparation.json',p/'private-mesher.json',p/'source-snapshot.json',left/'preparation.json']
for q in analyses:paths.extend(q/n for n in ['ground/mesh.json','ground/ground.json','stages.json'])
report=dict(recorded=True,wall_mesh_equivalent_within_tolerance=True,left_soil_elements=len(meshes[0]['tetrahedra']),
    right_soil_elements=len(meshes[1]['tetrahedra']),left_structural_nodes=440,right_structural_nodes=440,
    left_plates=832,right_plates=832,node_position_tolerance_m=1e-10,
    structural_node_position_maximum_matching_distance_m=float(distance.max()),structural_nodes_bijective=True,
    oriented_triangles_sections_and_global_tractions_equal=True,plate_section_declarations_equal=True,
    material_geometry_compact_stages_and_solver_settings_equal=True,only_spatial_wall_mesh_is_compared=True,
    solver_not_started=True,spatial_convergence_accepted=False,
    sha256={str(q.resolve()):sha(q) for q in paths},p6_complete=False)
with (p/'wall-spatial-topology-proof.json').open('x') as stream:json.dump(report,stream,indent=2)
print('PASS440 structural nodes and832 oriented plates fixed exactly; soil2865->5144',flush=True)
