"""Whole-process Windows counters, observed alongside concurrent validation jobs."""
from pathlib import Path
import ctypes,ctypes.wintypes as w,datetime,hashlib,json,os,sys,time
p=Path(__file__).resolve().parent;root=p.parents[1];label=sys.argv[1]
jobs={'mesh5144':p}
folder=jobs[label];job=folder/'workflow/analysis/solver-job'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'));sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
owner=read(folder/'solve-child.json');first=read(job/'status.json');assert first['process_id']==owner['pid'] and first['state']=='running'
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE;k.CloseHandle.argtypes=[w.HANDLE]
k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD]
k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
k.GetProcessTimes.argtypes=[w.HANDLE,*([ctypes.POINTER(w.FILETIME)]*4)]
class Counters(ctypes.Structure):
 _fields_=[('cb',w.DWORD),('faults',w.DWORD),*[(n,ctypes.c_size_t) for n in ['peak_ws','ws','peak_paged_pool','paged_pool','peak_nonpaged_pool','nonpaged_pool','commit','peak_commit','private']]]
k.K32GetProcessMemoryInfo.argtypes=[w.HANDLE,ctypes.POINTER(Counters),w.DWORD]
h=k.OpenProcess(0x1000|0x100000,False,owner['pid']);assert h
try:
 image=ctypes.create_unicode_buffer(32768);size=w.DWORD(len(image));assert k.QueryFullProcessImageNameW(h,0,image,ctypes.byref(size))
 assert str(Path(image.value).resolve()).lower()==str(Path(owner['executable']).resolve()).lower()
 assert sha(Path(image.value))=='07064591643cbb32ec0d7b29506d592bb7196c3a7bae6f50afb6a0e13f43b4f6'
 times=[w.FILETIME() for _ in range(4)];assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
 ticks=lambda v:(v.dwHighDateTime<<32)|v.dwLowDateTime
 created=ticks(times[0])/1e7-11644473600
 assert abs(created-datetime.datetime.fromisoformat(owner['created_utc']).timestamp())<5
 assert read(job/'status.json')['process_id']==owner['pid']
 count=0;last=None;peak_ws=0;peak_commit=0
 with (p/(label+'.jsonl')).open('x') as stream:
  while k.WaitForSingleObject(h,0)!=0:
   memory=Counters();memory.cb=ctypes.sizeof(memory);assert k.K32GetProcessMemoryInfo(h,ctypes.byref(memory),memory.cb)
   assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
   status=read(job/'status.json');assert status['job_id']==first['job_id']
   progress=status.get('last_progress') or {}
   last=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),age_seconds=time.time()-created,
             process_cpu_seconds=(ticks(times[2])+ticks(times[3]))/1e7,working_set_bytes=memory.ws,private_bytes=memory.private,
             lifetime_peak_working_set_bytes=memory.peak_ws,lifetime_peak_commit_bytes=memory.peak_commit,
             state=status['state'],stage=progress.get('stage'),stage_progress=progress.get('progress'),
             relative_force_residual=progress.get('relative_force_residual'),relative_volume_residual=progress.get('relative_volume_residual'),
             relative_pressure_residual=progress.get('relative_pressure_residual'))
   peak_ws=max(peak_ws,memory.peak_ws);peak_commit=max(peak_commit,memory.peak_commit)
   stream.write(json.dumps(last)+'\n');stream.flush();count+=1
   k.WaitForSingleObject(h,10000)
  assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
 final=read(job/'status.json')
 report=dict(measurements_recorded=True,job_final_state=final['state'],process_handle_signaled=True,samples=count,
             process_creation_identity_verified=True,solver_sha256=sha(Path(image.value)),logical_processors=os.cpu_count(),
             whole_process_elapsed_seconds=(ticks(times[1])-ticks(times[0]))/1e7,whole_process_cpu_seconds=(ticks(times[2])+ticks(times[3]))/1e7,
             observed_lifetime_peak_working_set_bytes=peak_ws,observed_lifetime_peak_commit_bytes=peak_commit,
             sampling_started_after_process_start=True,lifetime_peaks_are_os_counters=True,concurrent_ci_references_and_other_jobs=True,
             isolated_throughput_benchmark=False,large_mesh_p6_performance_acceptance=False,p6_complete=False,
             sha256={str(q):sha(q) for q in [Path(__file__),folder/'solve-child.json',job/'job.json',p/(label+'.jsonl')]})
 with (p/(label+'-terminal.json')).open('x') as stream:json.dump(report,stream,indent=2)
 print(json.dumps({k:v for k,v in report.items() if k!='sha256'}))
finally:k.CloseHandle(h)
