"""Private targeted meshing experiment from the same compact native capture.
Mechanical refinement only: native large-result display limits are a separate gate.
"""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,shutil,subprocess,sys,time,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1];quality=root/'runs/mcc-midpoint-quality-20261028-v9';read=lambda x:json.loads(x.read_text(encoding='utf-8-sig'));sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
def dump(x,v):
 with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
source=read(quality/'source-snapshot.json');runtime=p/'runtime';runtime.mkdir()
with zipfile.ZipFile(quality/'source-snapshot.zip') as z:
 assert z.testzip() is None
 for name in z.namelist():
  q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==source[name]
  target=runtime/q;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(data)
mesher=runtime/'tools/mesh_layers.py'
original_mesher=mesher.read_text(encoding='utf-8')
needle='        gmsh.model.mesh.generate(3)'
assert original_mesher.count(needle)==1
local_box=dict(xmin_m=3.,xmax_m=7.,ymin_m=1.,ymax_m=3.,zmin_m=0.,zmax_m=3.,inside_size_m=.3,outside_size_m=.8,transition_m=.5,fixed_surface_size_m=1.)
replacement='        gmsh.model.mesh.generate(2)\n        gmsh.option.setNumber("Mesh.MeshSizeMin",300.)\n        gmsh.option.setNumber("Mesh.MeshSizeMax",800.)\n        for option in ["Mesh.MeshSizeFromPoints","Mesh.MeshSizeFromCurvature","Mesh.MeshSizeExtendFromBoundary"]:gmsh.option.setNumber(option,0)\n        local_box=gmsh.model.mesh.field.add(\'Box\')\n        for key,value in {\'VIn\':300.,\'VOut\':800.,\'XMin\':3000.,\'XMax\':7000.,\'YMin\':1000.,\'YMax\':3000.,\'ZMin\':0.,\'ZMax\':3000.,\'Thickness\':500.}.items():\n            gmsh.model.mesh.field.setNumber(local_box,key,value)\n        gmsh.model.mesh.field.setAsBackgroundMesh(local_box)\n        gmsh.option.setNumber("Mesh.MeshOnlyEmpty",1)\n        gmsh.model.mesh.generate(3)'
mesher.write_text(original_mesher.replace(needle,replacement),encoding='utf-8')
sys.path.insert(0,str(runtime/'tools'))
from freeze_sources import freeze,manifest
private_sources=manifest();assert set(private_sources)==set(source)
assert [n for n in source if private_sources[n]!=source[n]]==['tools/mesh_layers.py']
freeze(p)
dump(p/'private-mesher.json',dict(private_discretization_experiment=True,local_box=local_box,only_changed_source='tools/mesh_layers.py',original_sha256=source['tools/mesh_layers.py'],private_sha256=sha(mesher),production_root_unchanged=True,constitutive_law_loads_and_geometry_unchanged=True))
solver=root/'runs/mcc-midpoint-quality-20261027-v7/solver/soil-fem-3d.exe';assert sha(solver)=='07064591643cbb32ec0d7b29506d592bb7196c3a7bae6f50afb6a0e13f43b4f6';capture=root/'runs/native-mcc-compact-pit-20261027-v1/capture';expected=read(capture/'capture.json')['input_sha256'];workflow=p/'workflow';python=root/'.venv/Scripts/python.exe';env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8');records=[]
def call(label,args):
 if (p/'pause-requested').exists():raise SystemExit(2)
 command=list(map(str,args));start=time.monotonic()
 with (p/(label+'.log')).open('x',encoding='utf-8') as log:
  child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  dump(p/(label+'-child.json'),dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()));code=child.wait()
 row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-start);records.append(row);(p/'progress.json').write_text(json.dumps(dict(records=records,p6_complete=False),indent=2));print(json.dumps(row),flush=True);assert code==0,row
call('prepare-capture',['pwsh','-NoProfile','-File',runtime/'scripts/Invoke-SolidCraftCapture.ps1','-CaptureFolder',capture,'-MeshSizeM',1.0,'-ElementOrder',2,'-QuadratureOrder',3,'-SolverPath',solver,'-OutputDirectory',workflow,'-PythonPath',python,'-PrepareOnly'])
analysis=workflow/'analysis';mesh=read(analysis/'ground/mesh.json');case=read(analysis/'stages.json');binding=read(analysis/'ground/plate-surface-binding.json')
assert read(workflow/'conformal/native-capture-import.json')['input_sha256']==expected
assert abs(sum(row['area_m2'] for row in binding['surfaces'])-72.)<1e-9
paths=[solver,analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stages.json',capture/'capture.json',quality/'source-snapshot.json',p/'source-snapshot.json',mesher,p/'private-mesher.json'];bound={str(x):sha(x) for x in paths}
dump(p/'preparation.json',dict(prepared=True,mesh_size_m=1.0,private_local_box=local_box,local_box_size_m=.3,elements=len(mesh['tetrahedra']),nodes=len(mesh['nodes']),points=27*len(mesh['tetrahedra']),plates=len(case['beam_system']['plates']),same_native_input_sha256=expected,wall_area_m2=72.,fresh_initialization_no_history_transfer=True,source_snapshot_sha256=sha(quality/'source-snapshot.json'),sha256=bound,mechanical_validation_pending=True,native_large_result_display_not_accepted=True,p6_complete=False))
dump(p/'preparation-only.json',dict(prepared=True,solver_not_started=True,background_field_only_size_controls=True,reference='https://gmsh.info/doc/texinfo/#Specifying-mesh-element-sizes',all_bound_inputs_unchanged=all(sha(Path(n))==h for n,h in bound.items()),p6_complete=False))
print('Field-only local meshing preparation complete; no solver started',flush=True)
