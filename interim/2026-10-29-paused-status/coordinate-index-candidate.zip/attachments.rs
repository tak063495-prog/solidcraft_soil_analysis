//! Bounded exact coordinate attachment: x-axis index, then the original3D metric.
use crate::{Result, geom::Vec3, params::bad};

const CMD: &str = "analysis.soil.results";
const TOLERANCE_M: f64 = 1e-8;
const MAX_NODES: usize = 1_000_000;
const MAX_DISTANCE_CHECKS: usize = 2_000_000;

pub(super) struct CoordinateIndex<'a> {
    points: &'a [[f64; 3]],
    sorted_x: Vec<(f64, usize)>,
}

impl<'a> CoordinateIndex<'a> {
    pub(super) fn new(points: &'a [[f64; 3]]) -> Result<Self> {
        if points.len() > MAX_NODES || points.iter().flatten().any(|x| !x.is_finite()) {
            return Err(bad(CMD, "invalid structural coordinate index input"));
        }
        let mut sorted_x: Vec<_> = points.iter().enumerate().map(|(i, p)| (p[0], i)).collect();
        sorted_x.sort_unstable_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        Ok(Self { points, sorted_x })
    }

    pub(super) fn find_unique(&self, position: [f64; 3], checked: &mut usize) -> Result<usize> {
        if position.iter().any(|v| !v.is_finite()) {
            return Err(bad(CMD, "non-finite structural attachment position"));
        }
        // Widen rounded subtraction/addition outwards. The final predicate is
        // unchanged, including tolerance equality and duplicate detection.
        let lower = (position[0] - TOLERANCE_M).next_down();
        let upper = (position[0] + TOLERANCE_M).next_up();
        let start = self.sorted_x.partition_point(|p| p.0 < lower);
        let end = self.sorted_x.partition_point(|p| p.0 <= upper);
        let candidates = self.sorted_x.get(start..end).ok_or_else(|| bad(CMD, "invalid structural coordinate index range"))?;
        *checked = checked.checked_add(candidates.len()).ok_or_else(|| bad(CMD, "structural coordinate matching budget exceeded; use bound node sets"))?;
        if *checked > MAX_DISTANCE_CHECKS {
            return Err(bad(CMD, "structural coordinate matching budget exceeded; use bound node sets"));
        }
        let mut found = None;
        for &(_, i) in candidates {
            let point = self.points.get(i).ok_or_else(|| bad(CMD, "invalid structural coordinate index"))?;
            if (Vec3::from(*point) - Vec3::from(position)).len() <= TOLERANCE_M {
                if found.is_some() {
                    return Err(bad(CMD, "ambiguous structural soil coordinate attachment"));
                }
                found = Some(i);
            }
        }
        found.ok_or_else(|| bad(CMD, "ambiguous structural soil coordinate attachment"))
    }
}
