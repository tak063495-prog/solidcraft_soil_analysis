pub use solidcraft_geom as geom;
pub type Result<T> = std::result::Result<T, String>;
pub mod params {
    pub fn bad(command: &str, message: impl std::fmt::Display) -> String {
        format!("{command}: {message}")
    }
}
#[path = "../../overlay/crates/engine/src/soil_results/attachments.rs"]
mod attachments;
#[cfg(test)]
mod tests {
    include!("../../coordinate-tests.rs");
}
fn main() -> Result<()> {
    let args: Vec<_>=std::env::args().skip(1).collect();
    if args.len()!=3 {return Err("expected actual mesh, case and frame0 paths".into());}
    let read=|p: &str| -> Result<serde_json::Value> {
        serde_json::from_reader(std::fs::File::open(p).map_err(|e|e.to_string())?).map_err(|e|e.to_string())
    };
    let mesh=read(&args[0])?;let case=read(&args[1])?;let frame=read(&args[2])?;
    let point=|v: &serde_json::Value| -> Result<[f64;3]> {
        let a=v.as_array().ok_or("missing coordinate")?;
        if a.len()!=3 {return Err("coordinate width".into());}
        Ok([a[0].as_f64().ok_or("x")?,a[1].as_f64().ok_or("y")?,a[2].as_f64().ok_or("z")?])
    };
    let points=mesh["nodes"].as_array().ok_or("missing nodes")?.iter().map(point).collect::<Result<Vec<_>>>()?;
    let definitions=case["beam_system"]["nodes"].as_array().ok_or("missing structural nodes")?;
    let mapped=frame["structures"]["nodes"]["soil_node_ids"].as_array().ok_or("missing displayed soil ids")?;
    let index=attachments::CoordinateIndex::new(&points)?;let mut checked=0;
    if definitions.len()!=662 || mapped.len()!=662 {return Err("actual source node count".into());}
    for (i,d) in definitions.iter().enumerate() {
        let p=point(&d["position_m"])?;
        let brute: Vec<_>=points.iter().enumerate().filter(|(_,q)|(geom::Vec3::from(**q)-geom::Vec3::from(p)).len()<=1e-8).map(|(j,_)|j).collect();
        let matched=index.find_unique(p,&mut checked)?;
        if brute!=[matched] || mapped[i].as_u64()!=Some(matched as u64) {return Err(format!("mapping differs at{i}"));}
    }
    println!("{}",serde_json::json!({"passed":true,"actual_soil_nodes":points.len(),"actual_structural_nodes":definitions.len(),"brute_force_distance_checks":points.len()*definitions.len(),"indexed_distance_checks":checked,"all_actual_source_and_display_attachments_exact":true,"distance_budget_unchanged":2000000,"full_native_integration_pending":true}));
    Ok(())
}
