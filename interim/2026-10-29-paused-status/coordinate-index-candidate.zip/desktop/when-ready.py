"""Open the actual large result once the review build succeeds; visual review remains manual."""
from pathlib import Path
import datetime,hashlib,json,os,socket,subprocess,sys,time
p=Path(__file__).resolve().parent
owner=p.parent
root=p.parents[2]
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
programs=['launch.py','gui-control.py','dismiss-startup-overlay.py','open-and-inspect.py','verify-desktop.py']
binding={n:sha(p/n) for n in programs}
print('Waiting for CI-profile app; final release and manual visual acceptance stay separate',flush=True)
while not (owner/'review-build-terminal.json').exists():
    if (owner/'pause-requested').exists():raise SystemExit(2)
    time.sleep(5)
assert read(owner/'review-build-terminal.json')['passed']
assert all(sha(p/n)==h for n,h in binding.items())
records=[]
def run(label,script):
    if (owner/'pause-requested').exists():raise SystemExit(2)
    command=[sys.executable,str(p/script)];began=time.monotonic()
    with (p/(label+'-driver.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        with (p/(label+'-driver-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]),flush=True)
    assert code==0
run('launch','launch.py')
port=read(p/'launch.json')['port']
ready=False
for _ in range(120):
    if (owner/'pause-requested').exists():raise SystemExit(2)
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=1):pass
        ready=True;break
    except OSError:time.sleep(1)
assert ready,'owned review app did not expose its control port'
run('startup-overlay','dismiss-startup-overlay.py')
run('inspect','open-and-inspect.py')
run('raw-fields','verify-desktop.py')
assert all(sha(p/n)==h for n,h in binding.items())
with (p/'review-ready.json').open('x') as stream:
    json.dump(dict(passed=True,records=records,programs_sha256=binding,ci_profile_review_only=True,
        manual_png_review_still_required=True,cad_invalidation_undo_and_owned_quit_pending=True,
        full_native_ci_and_release_validation_separate=True,p6_complete=False),stream,indent=2)
print('Actual large-source GPU captures ready for visual review; acceptance pending',flush=True)
