"""Compare live Native node, plate and section queries with the audited source."""
from pathlib import Path
import hashlib,json
import numpy as np
p=Path(__file__).resolve().parent
root=p.parents[2]
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
analysis=root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow/analysis'
source=analysis/'stage-results.json'
assert sha(source)=='750355444ed1c05325e0983dfbd006d90312f5ef049787f315f873043739e9c5'
run=read(source)
assert run['complete'] and len(run['frames'])==5 and len(run['integration_points'])==75789
plate=read(p/'wall-raw.json')['reply']['result']
assert plate['frame_index']==4 and plate['member']['result']==run['frames'][4]['beam_results']['plates'][0]
node=read(p/'floor-node-raw.json')['reply']['result']
i=node['node'];stored=node['stored_node_fields'];last=run['frames'][-1]['state']['displacement_m'];prior=run['frames'][-2]['state']['displacement_m']
assert stored['displacement_m']==last[i] and stored['display_reference_displacement_m']==run['reference_displacement_m'][i]
assert np.array_equal(stored['stage_displacement_increment_m'],np.asarray(last[i])-prior[i])
assert stored['total_displacement_from_seed_m']==last[i]
for name,area in [('ground',18.),('wall',12.)]:
    status=read(p/(name+'-section-status.json'))['reply']['result']
    assert abs(status['reference_section_area_m2']-area)<1e-9
status=read(p/'heave-status.json')['reply']['result']
assert status['loaded'] and not status['stale'] and status['active_plates']==1264
records=['floor-node-raw.json','wall-raw.json','ground-section-status.json','wall-section-status.json','heave-status.json','bending-status.json','launch.json']
with (p/'raw-field-verification.json').open('x') as stream:
    json.dump(dict(passed=True,raw_node_and_plate_exact=True,source_result_bytes=source.stat().st_size,
        source_result_sha256=sha(source),integration_points=75789,active_plates=1264,
        stage_increment_and_total_reference_exact=True,wall_section_area_m2=12.,ground_section_area_m2=18.,
        native_source_files=64,ci_profile_review_only=read(p/'launch.json').get('ci_profile_review_only',False),
        official_owned_job_flow_not_reaccepted_for_this_large_case=True,
        evidence_sha256={n:sha(p/n) for n in records},p6_complete=False),stream,indent=2)
print('PASS real-source raw node, plate, references and exact section areas',flush=True)
