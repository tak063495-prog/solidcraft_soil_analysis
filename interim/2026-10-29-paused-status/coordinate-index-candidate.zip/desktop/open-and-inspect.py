from pathlib import Path
import json,subprocess,sys
import numpy as np
p=Path(__file__).resolve().parent;root=p.parents[2]
read=lambda x:json.loads(x.read_text(encoding='utf-8-sig'))
assert read(root/'runs/native-large-source-stream-20261029-v1/real-view-preparation.json')['passed']
def call(tag,method,params):
 q=p/('request-'+tag+'.json')
 with q.open('x') as f:json.dump(dict(method=method,params=params),f)
 subprocess.run([sys.executable,str(p/'gui-control.py'),tag,str(q)],check=True,stdout=subprocess.DEVNULL)
 return read(p/(tag+'.json'))['reply']['result']
def engine(tag,command,params=None):return call(tag,'engine.execute',dict(command=command,params=params or {}))
def click(tag,name):
 h=call('handles-'+tag,'ui.handles',{});v=[x for x in h if x['name']==name];assert len(v)==1,(name,v)
 return call(tag,'ui.click',dict(x=v[0]['x'],y=v[0]['y']))
def picture(tag,name):
 h=call('handles-picture-'+tag,'ui.handles',{});close=[x for x in h if x['name']=='dialog:close']
 if close:assert len(close)==1;call('hide-controls-'+tag,'ui.click',dict(x=close[0]['x'],y=close[0]['y']))
 h=call('handles-hidden-'+tag,'ui.handles',{});assert not any(x['name']=='dialog:close' for x in h)
 call('image-'+tag,'ui.screenshot',dict(path=str(p/name)))
launch=read(p/'launch.json')
engine('open-real-result','analysis.soil.results.open',dict(manifest=str(root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow/view/view-manifest.json'),expected_input_sha256=launch['input_sha256']))
common=dict(frame=4,quantity='vertical_displacement',displacement_reference='stage',deformation_scale=20.,refinement=2,section=None,color_range=None,wireframe=False,principal_directions=False)
engine('configure-heave','analysis.soil.results.configure',common)
a=engine('heave-status','analysis.soil.results.status');assert a['loaded'] and not a['stale'] and a['frame_name']=='excavate_pit' and a['active_plates']==1264
analysis=root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow/analysis';mesh=read(analysis/'ground/mesh.json');result=read(analysis/'stage-results.json');ids=np.asarray(mesh['node_sets']['body:Lower11:zmax']);last=np.asarray(result['frames'][-1]['state']['displacement_m']);before=np.asarray(result['frames'][-2]['state']['displacement_m']);node=int(ids[np.argmax((last-before)[ids,2])])
engine('floor-node-raw','analysis.soil.results.query',dict(node=node))
picture('heave','large-source-heave.png')
click('plan-axis','axis_view:z');picture('plan','large-source-stage-increment-plan.png')
click('home-axis','axis_view:home')
common.update(quantity='plate_bending_xx',deformation_scale=2.,wireframe=True)
engine('configure-bending','analysis.soil.results.configure',common)
b=engine('bending-status','analysis.soil.results.status');assert b['quantity_available'] and b['unit']=='kN m/m'
engine('wall-raw','analysis.soil.results.query',dict(plate=0));picture('wall','large-source-wall.png')
common['section']=dict(normal=[1.,0.,0.],offset_m=3.,slice_only=True)
engine('configure-wall-section','analysis.soil.results.configure',common)
c=engine('wall-section-status','analysis.soil.results.status');assert abs(c['reference_section_area_m2']-12.)<1e-9
picture('wall-section','large-source-wall-section.png')
common.update(quantity='vertical_displacement',deformation_scale=20.,wireframe=False,section=dict(normal=[1.,0.,0.],offset_m=5.,slice_only=True))
engine('configure-ground-section','analysis.soil.results.configure',common)
d=engine('ground-section-status','analysis.soil.results.status');assert abs(d['reference_section_area_m2']-18.)<1e-9
picture('ground-section','large-source-ground-section.png')
common['section']=None;engine('restore-heave','analysis.soil.results.configure',common)
print(json.dumps(dict(manual_view_of_actual_audited_case=True,active_plates=1264,queried_node=node,wall_section_m2=12.,ground_section_m2=18.)),flush=True)
