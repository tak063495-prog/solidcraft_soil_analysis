"""Launch only the frozen Native64 CI-profile review app with the original synthetic design."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,socket,subprocess
desktop=Path(__file__).resolve().parent;p=desktop.parent;root=p.parents[1]
streaming=root/'runs/native-large-source-stream-20261029-v1'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert not (p/'pause-requested').exists()
quality=read(p/'review-build-terminal.json')
assert quality['passed'] and quality['source_files']==64 and quality['profile']=='ci'
sources=read(p/'source64.json')['files_sha256']
assert all(sha(streaming/'checkout'/n)==h for n,h in sources.items())
assert read(p/'proof-terminal.json')['passed'] and read(streaming/'real-view-preparation.json')['passed']
assert not (desktop/'launch.json').exists();(desktop/'native').mkdir()
for n,h in quality['binaries_sha256'].items():
    assert sha(p/'native'/n)==h;shutil.copy2(p/'native'/n,desktop/'native'/n);assert sha(desktop/'native'/n)==h
large=root/'runs/mcc-large-structures-development-20261028-v1/large-case'
design=desktop/'source.solidcraft.json';shutil.copy2(large/'source.solidcraft.json',design)
assert sha(large/'workflow/view-verification.json')==sha(streaming/'real-view-verification.json')
solver=root/'runs/mcc-midpoint-quality-20261029-v13/solver/soil-fem-3d.exe'
assert sha(solver)=='3d42671dc8a3f6c2d2fd48cf6afb8554a6df6dc004bfdc10b328009f4dffae0a'
with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
binary=desktop/'native/solidcraft.exe'
command=[str(binary),'--control',str(port),str(design)]
env=dict(os.environ,SOLIDCRAFT_SOIL_FEM_ROOT=str(root),SOLIDCRAFT_SOIL_FEM_SOLVER=str(solver))
with (desktop/'app.log').open('x') as log:
    child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
created=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (desktop/'app-child.json').open('x') as stream:
    json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=str(binary),arguments=command[1:],created_utc=created),stream,indent=2)
record=dict(process_id=child.pid,created_utc=created,port=port,binary_sha256=sha(binary),design_sha256=sha(design),
    solver_sha256=sha(solver),native_source_files=64,native_source_manifest_sha256=sha(p/'source64.json'),
    input_sha256=read(large/'preparation.json')['input_sha256'],original_case_solver_sha256=read(large/'preparation.json')['solver_sha256'],
    ci_profile_review_only=True,full_ci_and_release_validation_still_required=True,manual_view_of_audited_actual_case=True,
    official_owned_job_flow_not_reaccepted_for_this_large_case=True,p6_complete=False)
with (desktop/'launch.json').open('x') as stream:json.dump(record,stream,indent=2)
print(json.dumps(dict(process_id=child.pid,port=port,native_sources=64,input_sha256=record['input_sha256'])),flush=True)
