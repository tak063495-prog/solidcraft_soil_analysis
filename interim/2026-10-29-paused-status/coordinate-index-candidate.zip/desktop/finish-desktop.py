"""Check CAD invalidation and Undo, close results, and quit only the owned app."""
from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'raw-field-verification.json')['passed']
assert read(p/'manual-visual-review.json')['passed']
def call(tag,method,params):
    q=p/('request-'+tag+'.json')
    with q.open('x') as stream:json.dump(dict(method=method,params=params),stream)
    subprocess.run([sys.executable,str(p/'gui-control.py'),tag,str(q)],check=True,stdout=subprocess.DEVNULL)
    return read(p/(tag+'.json'))['reply']['result']
def engine(tag,command,params=None):return call(tag,'engine.execute',dict(command=command,params=params or {}))
engine('stale-rename','body.rename',dict(body='UpperSoil',name='UpperSoil_probe'))
assert engine('stale-check','analysis.soil.results.status')['stale']
engine('undo-rename','edit.undo')
status=engine('undo-check','analysis.soil.results.status')
assert status['loaded'] and not status['stale']
engine('return-cad','analysis.soil.results.close')
assert not engine('closed-check','analysis.soil.results.status')['loaded']
call('quit-owned','app.quit',{})
assert read(p/'owned-app-exited.json')['original_handle_signaled']
records=['raw-field-verification.json','manual-visual-review.json','owned-app-exited.json','stale-check.json','undo-check.json','closed-check.json','launch.json']
with (p/'desktop-verification.json').open('x') as stream:
    json.dump(dict(passed=True,manual_audited_large_case_view=True,native_source_files=64,
        ci_profile_review_only=read(p/'launch.json').get('ci_profile_review_only',False),
        raw_node_plate_references_and_sections_exact=True,changed_cad_invalidates_results=True,
        undo_restores_matching_results=True,results_closed=True,owned_app_gracefully_exited=True,
        official_owned_job_flow_not_reaccepted_for_this_large_case=True,
        spatial_convergence_accepted=False,evidence_sha256={n:sha(p/n) for n in records},p6_complete=False),stream,indent=2)
print('PASS CAD invalidation, Undo, result close and owned-app graceful exit',flush=True)
