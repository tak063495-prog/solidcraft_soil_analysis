"""Use the app's documented control API, bound to the owned process handle."""
import argparse,ctypes,ctypes.wintypes as w,datetime,hashlib,json,os,re,socket
from pathlib import Path
folder=Path(__file__).resolve().parent;root=folder.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('tag');parser.add_argument('request',type=Path);parser.add_argument('--before',action='store_true');args=parser.parse_args()
allowed_folder=folder
if args.before:folder=folder/'before-ui'
assert re.fullmatch(r'[a-z0-9][a-z0-9-]{0,80}',args.tag);output=folder/(args.tag+'.json');assert not output.exists()
launch=read(folder/'launch.json');kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];kernel.OpenProcess.restype=w.HANDLE
kernel.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD];kernel.CloseHandle.argtypes=[w.HANDLE]
kernel.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
kernel.GetProcessTimes.argtypes=[w.HANDLE,*([ctypes.POINTER(w.FILETIME)]*4)]
handle=kernel.OpenProcess(0x1000|0x100000,False,launch['process_id']);assert handle
try:
    assert kernel.WaitForSingleObject(handle,0)==258,'owned app is no longer live'
    buffer=ctypes.create_unicode_buffer(32768);size=w.DWORD(len(buffer))
    assert kernel.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(size))
    assert Path(buffer.value)==folder/'native/solidcraft.exe' and sha(Path(buffer.value))==launch['binary_sha256']
    times=[w.FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle,*[ctypes.byref(t) for t in times])
    created=((times[0].dwHighDateTime<<32)|times[0].dwLowDateTime)/1e7-11644473600
    assert abs(created-datetime.datetime.fromisoformat(launch['created_utc']).timestamp())<5,'owned app PID identity changed'
    command=read(args.request);port=launch['port']
    token=(Path(os.environ['LOCALAPPDATA'])/'SolidCraft/control'/f'{port}.token').read_text().strip()
    payload=dict(id=1,method=command['method'],params={**command.get('params',{}),'allow_paths':[str(allowed_folder),str(root/'runs/mcc-large-structures-development-20261028-v1/large-case')]},token=token)
    with socket.create_connection(('127.0.0.1',port),timeout=5) as connection:
        connection.settimeout(65);connection.sendall((json.dumps(payload)+'\n').encode())
        with connection.makefile('rb') as stream:data=stream.readline(20<<20)
    assert data;reply=json.loads(data)
    with output.open('x',encoding='utf-8') as f:json.dump(dict(request=command,reply=reply,owned_process_handle_verified=True),f,indent=2)
    if not reply.get('ok'):raise ValueError(reply.get('error'))
    result=reply.get('result');summary=result
    if isinstance(result,dict):summary={k:result[k] for k in ('loaded','stale','quantity_available','state','process_alive','result_usable','resume_usable','input_sha256','path','quitting') if k in result}
    print(json.dumps(dict(ok=True,result=summary)))
    if command['method']=='app.quit' and isinstance(result,dict) and result.get('quitting'):
        assert kernel.WaitForSingleObject(handle,30000)==0
        with (folder/'owned-app-exited.json').open('x') as f:json.dump(dict(original_handle_signaled=True),f)
finally:kernel.CloseHandle(handle)
