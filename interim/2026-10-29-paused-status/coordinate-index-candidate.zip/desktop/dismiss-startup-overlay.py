from pathlib import Path
import json,subprocess,sys
p=Path(__file__).resolve().parent
def call(tag,method,params):
 q=p/('request-'+tag+'.json')
 with q.open('x') as f:json.dump(dict(method=method,params=params),f)
 subprocess.run([sys.executable,str(p/'gui-control.py'),tag,str(q)],check=True,stdout=subprocess.DEVNULL)
 return json.loads((p/(tag+'.json')).read_text())['reply']['result']
h=call('startup-handles','ui.handles',{});close=[x for x in h if x['name']=='dialog:Close']
if close:
 assert len(close)==1 and any('Copy folder path' in x['name'] for x in h)
 call('dismiss-startup-report-without-delete','ui.click',dict(x=close[0]['x'],y=close[0]['y']))
print('Startup overlay handled without changing crash records',flush=True)
