#[test]
fn coordinate_index_matches_exhaustive_metric_at_tolerance_and_rounding_edges() {
    use super::attachments::CoordinateIndex;
    let tol: f64 = 1e-8;
    let cases = [
        (vec![[tol, 0., 0.]], [0., 0., 0.]),
        (vec![[tol.next_up(), 0., 0.]], [0., 0., 0.]),
        (vec![[tol.next_down(), 0., 0.]], [0., 0., 0.]),
        (vec![[1. + tol, 0., 0.]], [1., 0., 0.]),
        (vec![[-1. - tol, 0., 0.]], [-1., 0., 0.]),
        (vec![[tol, tol, 0.]], [0., 0., 0.]),
        (vec![[-0., 0., 0.], [0., 0., 0.]], [0., 0., 0.]),
        (vec![], [0., 0., 0.]),
        (vec![[f64::MAX, 0., 0.]], [f64::MAX, 0., 0.]),
    ];
    for (points, query) in cases {
        let expected: Vec<_> = points.iter().enumerate().filter(|(_, p)|
            (crate::geom::Vec3::from(**p)-crate::geom::Vec3::from(query)).len() <= tol).map(|(i,_)| i).collect();
        let index = CoordinateIndex::new(&points).unwrap();
        let got = index.find_unique(query, &mut 0);
        if expected.len()==1 { assert_eq!(got.unwrap(),expected[0]); }
        else { assert!(got.is_err()); }
    }
}

#[test]
fn coordinate_index_large_grid_matches_exact_attachments_with_bounded_work() {
    use super::attachments::CoordinateIndex;
    let mut points=Vec::new();
    for z in 0..18 { for y in 0..16 { for x in 0..16 {
        points.push([x as f64*0.03,y as f64*0.04,z as f64*0.05]);
    }}}
    let index=CoordinateIndex::new(&points).unwrap();
    let mut checked=0;
    for i in 0..662 { assert_eq!(index.find_unique(points[i],&mut checked).unwrap(),i); }
    assert!(points.len()*662>2_000_000);
    assert!(checked<200_000);
}

#[test]
fn coordinate_index_keeps_ambiguity_nonfinite_and_work_budget_rejections() {
    use super::attachments::CoordinateIndex;
    assert!(CoordinateIndex::new(&[[f64::NAN,0.,0.]]).is_err());
    assert!(CoordinateIndex::new(&[[0.,0.,f64::INFINITY]]).is_err());
    let points=[[0.,0.,0.],[0.,0.,0.]];
    let index=CoordinateIndex::new(&points).unwrap();
    assert!(index.find_unique([0.,0.,0.],&mut 0).is_err());
    assert!(index.find_unique([f64::NAN,0.,0.],&mut 0).is_err());
    assert!(index.find_unique([0.,0.,0.],&mut 2_000_000).is_err());
    assert!(index.find_unique([0.,0.,0.],&mut usize::MAX).is_err());
}
