"""Prepare a fresh pinned SolidCraft soil host; never reset an existing checkout."""
from pathlib import Path,PurePosixPath
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time,zipfile
BASE='edf57cec293dcea301201f1d5173b33e16351466'
REPOSITORY='https://github.com/tangency-labs/solidcraft.git'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-archive',type=Path,required=True)
parser.add_argument('--source-manifest',type=Path,required=True)
parser.add_argument('--destination',type=Path,required=True)
parser.add_argument('--local-repository',type=Path,help='Explicit trusted host argument for offline preparation tests; not CAD data')
parser.add_argument('--prepare-only',action='store_true')
parser.add_argument('--cargo',type=Path)
args=parser.parse_args();owner=Path(__file__).resolve().parent;destination=args.destination.resolve();archive=args.source_archive.resolve();manifest_path=args.source_manifest.resolve()
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
inputs_sha256={str(q):sha(q) for q in [archive,manifest_path,Path(__file__)]}
manifest=read(manifest_path);sources=manifest['files_sha256']
if manifest['base']!=BASE or not 1<=len(sources)<=256:raise ValueError('unsupported base or source inventory')
if destination.exists() or not destination.parent.is_dir():raise ValueError('destination must be a new checkout in an existing parent; existing work is preserved')
if archive.stat().st_size>64<<20:raise ValueError('source archive exceeds budget')
with zipfile.ZipFile(archive) as z:
 if len(z.namelist())!=len(set(z.namelist())) or set(z.namelist())!=set(sources):raise ValueError('source archive inventory differs')
 if sum(q.file_size for q in z.infolist())>64<<20:raise ValueError('expanded source patch exceeds budget')
 for n,h in sources.items():
  path=PurePosixPath(n)
  if path.is_absolute() or '..' in path.parts or any(part.lower()=='.git' for part in path.parts) or '\\' in n or ':' in n or not re.fullmatch('[0-9a-f]{64}',h):raise ValueError('unsafe source inventory')
  if hashlib.sha256(z.read(n)).hexdigest()!=h:raise ValueError('source archive hash differs: '+n)
repository=str(args.local_repository.resolve()) if args.local_repository else REPOSITORY
logs=destination.parent/(destination.name+'-installation');logs.mkdir();records=[]
env=dict(os.environ,CARGO_TARGET_DIR=str(destination/'target'),CARGO_BUILD_JOBS='2')
def call(label,command,cwd):
 if (owner/'pause-requested').exists():raise SystemExit(2)
 command=list(map(str,command));began=time.monotonic()
 with (logs/(label+'.log')).open('x',encoding='utf-8') as log:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
  with (logs/(label+'-child.json')).open('x',encoding='utf-8') as stream:json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
  code=child.wait()
 records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began));print(json.dumps(records[-1]),flush=True)
 if code!=0:raise RuntimeError(label+' failed; preserve installation logs before retrying in a different destination')
git=shutil.which('git')
if not git:raise ValueError('Git is required')
call('clone',[git,'-c','core.longpaths=true','clone','--no-hardlinks','--filter=blob:none','--no-checkout','--depth','1','--',repository,destination],destination.parent)
call('fetch-base',[git,'fetch','--depth','1','origin',BASE],destination)
call('checkout-base',[git,'checkout','--detach',BASE],destination)
head=subprocess.check_output([git,'rev-parse','HEAD'],cwd=destination,text=True).strip()
if head!=BASE:raise ValueError('checkout base differs')
with zipfile.ZipFile(archive) as z:
 for n,h in sources.items():
  target=destination/n
  if not target.resolve().is_relative_to(destination):raise ValueError('source destination escapes checkout')
  data=z.read(n)
  if hashlib.sha256(data).hexdigest()!=h:raise ValueError('source archive changed during installation')
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
if not all(sha(destination/n)==h for n,h in sources.items()):raise ValueError('installed source bytes differ')
changed=subprocess.check_output([git,'diff','--name-only','HEAD'],cwd=destination,text=True).splitlines()+subprocess.check_output([git,'ls-files','--others','--exclude-standard'],cwd=destination,text=True).splitlines()
if set(changed)!=set(sources):raise ValueError('installed patch changes an unexpected file inventory')
binaries={}
if not args.prepare_only:
 cargo=str(args.cargo.resolve()) if args.cargo else shutil.which('cargo')
 if not cargo:raise ValueError('Cargo is required; install the pinned toolchain first')
 call('build',[cargo,'build','--locked','--release','-p','solidcraft','-p','solidcraft-cli'],destination)
 if not all(sha(destination/n)==h for n,h in sources.items()):raise ValueError('sources changed during build')
 suffix='.exe' if os.name=='nt' else ''
 for name in ['solidcraft','solidcraft-cli']:
  binary=destination/'target/release'/(name+suffix);binaries[name]=dict(path=str(binary),sha256=sha(binary))
if not all(sha(Path(n))==h for n,h in inputs_sha256.items()):raise ValueError('installation inputs changed')
with (logs/'installation.json').open('x',encoding='utf-8') as stream:json.dump(dict(prepared=True,built=not args.prepare_only,source_base=BASE,source_files=len(sources),source_archive_sha256=sha(archive),source_manifest_sha256=sha(manifest_path),all_source_bytes_verified=True,only_declared_patch_files_changed=True,fresh_checkout=True,local_repository_used=bool(args.local_repository),binaries=binaries,records=records,installation_inputs_sha256=inputs_sha256,original_checkout_modified=False,same_pc=True,new_pc_acceptance=False,full_native_ci_or_gpu_not_implied=True,p6_complete=False),stream,indent=2)
print('PASS '+('fresh host build; inspect acceptance before use' if not args.prepare_only else 'source preparation only; no compiler or GUI acceptance'),flush=True)
