from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,unittest,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1];script=p/'install-v2.py';native=root/'runs/native-large-source-stream-20261029-v1'
class InstallerGuards(unittest.TestCase):
 def invoke(self,archive,manifest,destination):
  result=subprocess.run([sys.executable,str(script),'--source-archive',str(archive),'--source-manifest',str(manifest),'--destination',str(destination),'--local-repository',str(root/'external/solidcraft-soil-fem'),'--prepare-only'],capture_output=True,text=True,encoding='utf-8')
  self.assertNotEqual(result.returncode,0);return result
 def test_existing_source_checkout_is_never_overwritten(self):
  installed=p/'installed';manifest=json.loads((native/'source63.json').read_text(encoding='utf-8'));before={n:hashlib.sha256((installed/n).read_bytes()).hexdigest() for n in manifest['files_sha256']}
  result=self.invoke(native/'source63.zip',native/'source63.json',installed);self.assertIn('existing work is preserved',result.stderr)
  self.assertEqual(before,{n:hashlib.sha256((installed/n).read_bytes()).hexdigest() for n in before})
 def test_archive_corruption_is_rejected_before_checkout_creation(self):
  with tempfile.TemporaryDirectory() as folder:
   folder=Path(folder);archive=folder/'bad.zip';manifest=folder/'manifest.json';data=b'actual';inventory={'Cargo.lock':hashlib.sha256(b'expected').hexdigest()}
   with zipfile.ZipFile(archive,'w') as z:z.writestr('Cargo.lock',data)
   manifest.write_text(json.dumps(dict(base='edf57cec293dcea301201f1d5173b33e16351466',files_sha256=inventory)),encoding='utf-8')
   destination=folder/'new';result=self.invoke(archive,manifest,destination);self.assertIn('archive hash differs',result.stderr);self.assertFalse(destination.exists());self.assertFalse((folder/'new-installation').exists())
 def test_traversal_and_git_metadata_are_rejected_before_any_git_command(self):
  with tempfile.TemporaryDirectory() as folder:
   folder=Path(folder)
   for i,name in enumerate(['../escaped.rs','.git/config','crates/.GIT/config']):
    archive=folder/(str(i)+'.zip');manifest=folder/(str(i)+'.json');data=b'inert'
    with zipfile.ZipFile(archive,'w') as z:z.writestr(name,data)
    manifest.write_text(json.dumps(dict(base='edf57cec293dcea301201f1d5173b33e16351466',files_sha256={name:hashlib.sha256(data).hexdigest()})),encoding='utf-8')
    destination=folder/('new'+str(i));result=self.invoke(archive,manifest,destination);self.assertIn('unsafe source inventory',result.stderr);self.assertFalse(destination.exists());self.assertFalse((folder/(destination.name+'-installation')).exists())
   self.assertFalse((folder.parent/'escaped.rs').exists())
if __name__=='__main__':unittest.main()
