"""Compare all eight physical groups only after published-input recomputation audits pass."""
from pathlib import Path
import datetime,hashlib,json,time
p=Path(__file__).resolve().parent
root=p.parents[1]
out=p/'Portable full recomputation'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
def sha(q):
    digest=hashlib.sha256()
    with q.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()
print('Waiting for full published2807 solve, force/material/seed audits and input bindings',flush=True)
while not (out/'reproduction.json').exists():
    if (p/'pause-requested').exists():raise SystemExit(2)
    status=out/'workflow/analysis/solver-job/status.json'
    if status.exists() and read(status)['state']=='failed':raise SystemExit('published solve failed; physical equivalence not accepted')
    time.sleep(10)
reproduction=read(out/'reproduction.json')
assert reproduction['executed'] and reproduction['independent_force_material_and_seed_audits_passed']
assert reproduction['same_binary_as_published_root'] and reproduction['source_files']==610
original=root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow/analysis'
fresh=out/'workflow/analysis'
for n in ['ground/mesh.json','ground/ground.json','stages.json']:assert sha(original/n)==sha(fresh/n),n
a_path=original/'stage-results.json';b_path=fresh/'stage-results.json'
a_hash=sha(a_path);b_hash=sha(b_path)
assert a_hash=='750355444ed1c05325e0983dfbd006d90312f5ef049787f315f873043739e9c5'
a=read(a_path);b=read(b_path)
assert a['complete'] and b['complete'] and len(a['frames'])==len(b['frames'])==5
groups=['frames','last_committed','reference_displacement_m','integration_points','excavation_audits','transition_audits','geostatic','attempts']
ignored=0;leaves=0
def compare(x,y,path):
    global ignored,leaves
    if isinstance(x,dict):
        assert isinstance(y,dict),path
        keys=set(x)-{'elapsed_seconds'}
        assert keys==set(y)-{'elapsed_seconds'},path
        if 'elapsed_seconds' in x or 'elapsed_seconds' in y:ignored+=1
        for key in keys:compare(x[key],y[key],path+'.'+key)
    elif isinstance(x,list):
        assert isinstance(y,list) and len(x)==len(y),path
        for i,(u,v) in enumerate(zip(x,y)):compare(u,v,path+'['+str(i)+']')
    else:
        assert x==y,(path,x,y)
        leaves+=1
for group in groups:
    assert group in a and group in b,group
    compare(a[group],b[group],group)
    print('Exact '+group,flush=True)
assert sha(a_path)==a_hash and sha(b_path)==b_hash
with (p/'published-root610-physical-equivalence.json').open('x') as stream:
    json.dump(dict(passed=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        physical_groups_exact=groups,only_elapsed_seconds_omitted=True,ignored_timing_fields=ignored,
        scalar_leaves_compared=leaves,all_three_mechanical_inputs_byte_exact=True,
        original_result_sha256=a_hash,recomputed_result_sha256=b_hash,reference_candidate_solver_sha256=reproduction['reference_candidate_solver_sha256'],
        recomputed_solver_sha256=reproduction['solver_sha256'],same_pc=True,new_pc_acceptance=False,
        full_recomputation_and_independent_audits_verified=True,spatial_convergence_accepted=False,
        native_gpu_acceptance_separate=True,p6_complete=False),stream,indent=2)
print('PASS published Root610 full2807 reproduction and all physical histories',flush=True)
