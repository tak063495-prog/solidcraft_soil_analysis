"""Prepare or fully recompute the published2807-cell benchmark using frozen tools.

Programs come from explicit host arguments and the trusted published source
archive. The archived CAD design is data only and is never executed here.
"""
from pathlib import Path
import argparse,datetime,hashlib,importlib.metadata,json,os,shutil,subprocess,sys,time,zipfile
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
parser.add_argument('--solver',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--run',action='store_true',help='Run all5 stages and independent audits; may take hours')
args=parser.parse_args();bundle=args.bundle.resolve();solver=args.solver.resolve();out=args.output.resolve();owner=Path(__file__).resolve().parent
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
def sha(q):
 digest=hashlib.sha256()
 with q.open('rb') as stream:
  for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
 return digest.hexdigest()
assert solver.is_file() and not out.exists() and out.parent.is_dir()
milestone=read(bundle/'milestone.json');archive=bundle/'unsolved-inputs-and-native-design.zip';inventory=read(bundle/'archive-manifest.json')
assert milestone['source_files']==610 and sha(archive)==milestone['archive_sha256']
source_archive=bundle/'tested610-sources.zip';sources=read(bundle/'tested610-source-manifest.json');assert len(sources)==610
assert archive.stat().st_size<=64<<20 and source_archive.stat().st_size<=64<<20
out.mkdir();runtime=out/'runtime';runtime.mkdir();analysis=out/'workflow/analysis';(analysis/'ground').mkdir(parents=True)
with zipfile.ZipFile(source_archive) as z:
 assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(sources)
 assert sum(q.file_size for q in z.infolist())<=64<<20
 for n,h in sources.items():
  target=runtime/n;assert target.resolve().is_relative_to(runtime)
  data=z.read(n);assert hashlib.sha256(data).hexdigest()==h
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as stream:stream.write(data)
paths={'inputs/mesh.json':analysis/'ground/mesh.json','inputs/ground.json':analysis/'ground/ground.json','inputs/stages.json':analysis/'stages.json'}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(inventory)
 assert sum(q.file_size for q in z.infolist())<=64<<20
 for n,target in paths.items():
  expected=inventory[n];data=z.read(n);assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
  with target.open('xb') as stream:stream.write(data)
for n in ['requirements.lock.txt','requirements-reference.lock.txt']:
 for line in (runtime/n).read_text(encoding='utf-8').splitlines():
  if '==' in line and not line.lstrip().startswith('#'):
   package,version=line.strip().split('==');assert importlib.metadata.version(package)==version,(package,version)
auditor=bundle/'audit-large-fields.py';assert auditor.is_file();shutil.copy2(auditor,out/'audit-fields.py')
shutil.copy2(bundle/'reports/large-case-preparation.json',out/'preparation.json')
binding={str(q):sha(q) for q in [*paths.values(),solver,Path(__file__),auditor,source_archive,archive]};records=[]
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
def call(label,command):
 if (owner/'pause-requested').exists():raise SystemExit(2)
 command=list(map(str,command));began=time.monotonic()
 with (out/(label+'.log')).open('x',encoding='utf-8') as log:
  child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
  with (out/(label+'-child.json')).open('x',encoding='utf-8') as stream:json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
  code=child.wait()
 records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began));print(json.dumps(records[-1]),flush=True);assert code==0
job=analysis/'solver-job';call('prepare',[solver,'prepare-stages-job',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stages.json',job])
if args.run:
 call('solve',[job/'solver/soil-fem-3d.exe','run-stages-job',job]);shutil.copy2(job/'result.json',analysis/'stage-results.json')
 call('export',[sys.executable,runtime/'tools/export_stages.py',analysis/'ground/mesh.json',analysis/'stage-results.json',analysis/'results'])
 call('verify',[sys.executable,runtime/'tools/verify_stage_package.py',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stage-results.json',analysis/'results','--solver',solver])
 with (out/'mechanical-acceptance.json').open('x') as stream:json.dump(dict(passed=True,scope='mechanics only; final independent seed/load audit still required'),stream)
 call('audit-fields',[sys.executable,out/'audit-fields.py'])
 assert read(out/'field-verification.json')['seed_load_and_recorded_cutback_gates_passed']
assert all(sha(runtime/n)==h for n,h in sources.items()) and all(sha(Path(n))==h for n,h in binding.items())
with (out/'reproduction.json').open('x',encoding='utf-8') as stream:json.dump(dict(prepared=True,executed=args.run,independent_force_material_and_seed_audits_passed=args.run,case='large2807',source_files=610,published_input_bytes_exact=True,source_archive_and_pinned_python_versions_verified=True,solver_sha256=sha(solver),reference_candidate_solver_sha256=milestone['large_case_solver_sha256'],root_tested_solver_sha256=milestone['root_solver_sha256'],same_binary_as_published_root=sha(solver)==milestone['root_solver_sha256'],records=records,files_sha256=binding,same_pc=True,new_pc_acceptance=False,spatial_convergence_accepted=False,large_native_gpu_acceptance=False,p6_complete=False),stream,indent=2)
print('PASS '+('full published-input solve and independent audits' if args.run else 'preparation only; use --run with a different new output folder'),flush=True)
