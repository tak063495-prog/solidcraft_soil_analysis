"""Advance to105456 cells only after the10k solve and unchanged analytical audit pass."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
binding={str(q):sha(q) for q in [p/'run.py',p/'prepare.py',p/'verify.py',Path(__file__)]}
print('Waiting for10368-cell analytical acceptance before105456-cell run',flush=True)
while not (p/'n12/terminal.json').exists():
    if (p/'pause-requested').exists():raise SystemExit(2)
    failed=p/'n12/process-terminal.json'
    if failed.exists() and read(failed)['exit_code']!=0:raise SystemExit('10k solve failed; keep100k unstarted')
    time.sleep(10)
assert read(p/'n12/terminal.json')['passed'] and read(p/'n12/analytical-verification.json')['passed']
assert read(p/'n12/analytical-verification.json')['tetrahedra']==10368
assert all(sha(Path(n))==h for n,h in binding.items())
assert not (p/'pause-requested').exists() and not (p/'n26').exists()
command=[sys.executable,str(p/'run.py'),'26']
with (p/'100k-driver.log').open('x',encoding='utf-8') as stream:
    child=subprocess.Popen(command,cwd=p.parents[1],stdout=stream,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    with (p/'100k-driver-child.json').open('x') as receipt:
        json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),receipt)
    code=child.wait()
with (p/'100k-sequence-terminal.json').open('x') as stream:
    json.dump(dict(passed=code==0,exit_code=code,driver_binding_sha256=binding,only_started_after10k_analytical_acceptance=True,p6_complete=False),stream,indent=2)
assert code==0
print('PASS10k and100k nonlinear hydrostatic scaling; full excavation scope remains separate',flush=True)
