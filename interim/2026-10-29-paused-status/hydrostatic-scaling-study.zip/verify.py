"""Independent analytical field and geometric load checks, without solver imports."""
from pathlib import Path
import argparse, hashlib, json, math
import numpy as np

p = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('subdivisions', type=int)
args = parser.parse_args()
out = p/('n'+str(args.subdivisions))
read = lambda q: json.loads(q.read_text(encoding='utf-8-sig'))
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
preparation = read(out/'preparation.json')
assert all(sha(out/n)==h for n,h in preparation['files_sha256'].items())
mesh = read(out/'mesh.json')
ground = read(out/'ground.json')
run = read(out/'solver-job/result.json')
assert run['complete'] and len(run['frames'])==3 and len(run['integration_points'])==len(mesh['tetrahedra'])
points = np.asarray(mesh['nodes'])
independent_weights = np.zeros(len(points))
volume = 0.
for t in mesh['tetrahedra']:
    q = points[t]
    v = abs(np.linalg.det((q[1:]-q[0]).T))/6.
    assert v>0.
    volume += v
    independent_weights[t] += v/4.
assert abs(volume-1.)<1e-10
loads = ground['initialization']['geostatic']['base_loads']['nodal_loads']
actual_counter = np.zeros((len(points),3))
for item in loads:
    ids = mesh['node_sets'][item['node_set']]
    assert len(ids)==1
    actual_counter[ids[0]] += item['total_force_kn']
assert np.max(np.abs(actual_counter[:,:2]))==0.
counter_error = float(np.max(np.abs(actual_counter[:,2]-20.*independent_weights)))
assert counter_error<1e-12
area = sum(np.linalg.norm(np.cross(points[f[1]]-points[f[0]],points[f[2]]-points[f[0]]))/2. for f in mesh['face_sets']['all'])
assert abs(area-6.)<1e-10
vload = 2.-0.2*math.log(1.2)
plastic = 0.8*math.log(2./vload)/3.
reports = []
for frame,pressure,v,pc,ep in zip(run['frames'],[100.,120.,100.],
        [2.,vload,2.-0.16*math.log(1.2)],[100.,120.,120.],[0.,plastic,plastic]):
    strain = math.log(2./v)/3.
    displacement_error = float(np.max(np.abs(np.asarray(frame['state']['displacement_m'])+points*strain)))
    states = frame['state']['material_states']
    assert len(states)==len(mesh['tetrahedra'])
    stress_error = max(float(np.max(np.abs(np.asarray(s['effective_stress_compression_positive_kpa'])-np.asarray([pressure]*3+[0.]*3)))) for s in states)
    pc_error = max(abs(s['preconsolidation_pressure_kpa']-pc) for s in states)
    void_error = max(abs(1.+s['void_ratio']-v) for s in states)
    plastic_error = max(float(np.max(np.abs(np.asarray(s['plastic_strain_compression_positive'])-np.asarray([ep]*3+[0.]*3)))) for s in states)
    record = dict(frame=frame['name'],maximum_displacement_error_m=displacement_error,
        maximum_stress_error_kpa=stress_error,maximum_pc_error_kpa=pc_error,
        maximum_void_ratio_error=void_error,maximum_plastic_strain_error=plastic_error)
    reports.append(record)
    assert displacement_error<2e-8 and stress_error<2e-5 and pc_error<2e-5 and void_error<2e-7 and plastic_error<2e-8,record
rejected = [a for a in run['attempts'] if not a['accepted']]
assert any(a['reason']=='verification_injected_rejection_after_convergence' and a['committed_state_unchanged_on_rejection'] and a['rejected_trial_plastic_changed'] for a in rejected)
report = dict(passed=True,tetrahedra=len(mesh['tetrahedra']),nodes=len(points),
    all_nodes_and_integration_points_checked=True,analytical_closed_forms=True,
    independent_volume_m3=volume,independent_exterior_area_m2=float(area),maximum_countergravity_error_kn=counter_error,
    reports=reports,rejected_attempts=len(rejected),plastic_trial_and_committed_rollback_verified=True,
    scope=preparation['scope'],input_sha256=preparation['files_sha256'],result_sha256=sha(out/'solver-job/result.json'),
    verifier_sha256=sha(Path(__file__)),full_excavation_performance_acceptance=False,p6_complete=False)
with (out/'analytical-verification.json').open('x') as stream: json.dump(report,stream,indent=2)
print(json.dumps(report),flush=True)
