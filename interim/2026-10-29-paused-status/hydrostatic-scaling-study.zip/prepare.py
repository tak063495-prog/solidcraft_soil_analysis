"""Create an actual nonlinear MCC uniform-pressure patch, not excavation acceptance."""
from pathlib import Path
import argparse, collections, hashlib, json, math

p = Path(__file__).resolve().parent
root = p.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('subdivisions', type=int, choices=[2, 6, 12, 26])
args = parser.parse_args()
n = args.subdivisions
out = p / ('n' + str(n))
out.mkdir()
width = n + 1
index = lambda x, y, z: x + width * (y + width * z)
nodes = [[x/n, y/n, z/n] for z in range(width) for y in range(width) for x in range(width)]
tets = []
for z in range(n):
    for y in range(n):
        for x in range(n):
            c = [index(x,y,z), index(x+1,y,z), index(x+1,y+1,z), index(x,y+1,z),
                 index(x,y,z+1), index(x+1,y,z+1), index(x+1,y+1,z+1), index(x,y+1,z+1)]
            for t in [[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6],[0,5,1,6]]:
                tets.append([c[i] for i in t])
faces = collections.Counter()
oriented = {}
weights = [0.] * len(nodes)
for t in tets:
    for f in [[1,2,3],[0,3,2],[0,1,3],[0,2,1]]:
        face = [t[i] for i in f]
        key = tuple(sorted(face))
        faces[key] += 1
        oriented[key] = face
    for i in t:
        weights[i] += 1 / (24*n**3)
assert abs(sum(weights)-1.) < 1e-12
sets = {'all': list(range(len(nodes)))}
for a in range(3):
    sets['zero' + str(a)] = [i for i, q in enumerate(nodes) if q[a] == 0.]
for i in range(len(nodes)):
    sets['n'+str(i)] = [i]
mesh = dict(schema='soil-fem-mesh/2', units='m-kN-kPa', axis='z_up', crs='LOCAL', origin_m=[0.,0.,0.],
            nodes=nodes,tetrahedra=tets,material_ids=[1]*len(tets),node_sets=sets,
            face_sets={'all':[oriented[k] for k,count in faces.items() if count == 1]},
            regions=[dict(id=1,body='soil',material_id=1,bounds_m=[[0.,0.,0.],[1.,1.,1.]],volume_m3=1.,source_sha256='0'*64)],
            region_ids=[1]*len(tets))
read = lambda q: json.loads(q.read_text(encoding='utf-8-sig'))
ground = read(root/'examples/ground-geostatic-mcc-column.json')
ground['materials'] = [dict(id=1,name='NC hydrostatic MCC patch',unit_weight_kn_m3=20.,mcc=dict(
    critical_state_m=1.2,lambda_=0.2,kappa=0.04,poisson=0.3,reference_pressure_kpa=1.,
    specific_volume_ncl_at_reference=2.+0.2*math.log(100.)))]
parameters = ground['materials'][0]['mcc']
parameters['lambda'] = parameters.pop('lambda_')
ground['bodies'] = [dict(body='soil',material_id=1)]
geo = ground['initialization']['geostatic']
geo['seed'] = dict(kind='body_states',states={'soil':dict(effective_stress_compression_positive_kpa=[100.,100.,100.,0.,0.,0.],
    plastic_strain_compression_positive=[0.]*6,void_ratio=1.,preconsolidation_pressure_kpa=100.)})
geo['verification_reject_once'] = False
geo['base_loads'] = dict(nodal_loads=[dict(node_set='n'+str(i),total_force_kn=[0.,0.,20.*w]) for i,w in enumerate(weights)],
                         surface_loads=[dict(kind='pressure',face_set='all',pressure_kpa=100.)])
case = read(root/'examples/stages-geostatic-column.json')
case['schema'] = 'soil-fem-stages/1'
case['settings'].update(mcc_integration='midpoint',initial_increment=0.25,minimum_increment=1./256.,
    material_maximum_substep=5e-5,relative_force_tolerance=1e-9,relative_linear_tolerance=1e-11,
    maximum_free_dofs=100000)
case['boundary'] = dict(constraints=[dict(node_set='zero'+str(a),direction=[float(i==a) for i in range(3)],value_m=0.) for a in range(3)],
                        surface_loads=[dict(kind='pressure',face_set='all',pressure_kpa=20.)])
case['monitors'] = {}
case['monitor_sets'] = {}
case['verification_reject_once_stages'] = ['load']
case['stages'] = [dict(kind='boundary',name='load',target_factor=1.),dict(kind='boundary',name='unload',target_factor=0.)]
files = {}
for name,value in [('mesh.json',mesh),('ground.json',ground),('stages.json',case)]:
    q = out/name
    with q.open('x',encoding='utf-8') as stream: json.dump(value,stream,separators=(',',':'),allow_nan=False)
    files[name] = hashlib.sha256(q.read_bytes()).hexdigest()
with (out/'preparation.json').open('x') as stream:
    json.dump(dict(subdivisions=n,tetrahedra=len(tets),nodes=len(nodes),integration_points=len(tets),
        files_sha256=files,scope='uniform hydrostatic nonlinear MCC patch; gravity exactly counterbalanced; no CAD, excavation, water or structures',
        analytical_volumes=[2.,2.-0.2*math.log(1.2),2.-0.16*math.log(1.2)],p6_complete=False),stream,indent=2)
print(json.dumps(dict(folder=str(out),tetrahedra=len(tets),nodes=len(nodes))))
