"""Run one frozen nonlinear patch job, record OS process counters, then audit."""
from pathlib import Path
import argparse, ctypes, ctypes.wintypes as w, datetime, hashlib, json, os, subprocess, sys, time

p=Path(__file__).resolve().parent
root=p.parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('subdivisions',type=int,choices=[6,12,26])
args=parser.parse_args()
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
solver=root/'runs/mcc-midpoint-quality-20261029-v13/solver/soil-fem-3d.exe'
expected='3d42671dc8a3f6c2d2fd48cf6afb8554a6df6dc004bfdc10b328009f4dffae0a'
assert sha(solver)==expected and read(p/'n2/analytical-verification.json')['passed']
assert not (p/'pause-requested').exists()
subprocess.run([sys.executable,str(p/'prepare.py'),str(args.subdivisions)],check=True)
out=p/('n'+str(args.subdivisions));job=out/'solver-job'
binding={str(q):sha(q) for q in [p/'prepare.py',p/'verify.py',Path(__file__),solver,out/'mesh.json',out/'ground.json',out/'stages.json']}
def launch(label,command):
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=list(map(str,command))
    log=(out/(label+'.log')).open('x',encoding='utf-8')
    child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    with (out/(label+'-child.json')).open('x') as stream:
        json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
    return child,log
child,log=launch('prepare',[solver,'prepare-stages-job',out/'mesh.json',out/'ground.json',out/'stages.json',job])
assert child.wait()==0
log.close()
child,log=launch('solve',[job/'solver/soil-fem-3d.exe','run-stages-job',job])
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
k.CloseHandle.argtypes=[w.HANDLE]
k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
k.GetProcessTimes.argtypes=[w.HANDLE,*([ctypes.POINTER(w.FILETIME)]*4)]
class Counters(ctypes.Structure):
    _fields_=[('cb',w.DWORD),('faults',w.DWORD),*[(n,ctypes.c_size_t) for n in ['peak_ws','ws','peak_paged_pool','paged_pool','peak_nonpaged_pool','nonpaged_pool','commit','peak_commit','private']]]
k.K32GetProcessMemoryInfo.argtypes=[w.HANDLE,ctypes.POINTER(Counters),w.DWORD]
h=k.OpenProcess(0x1000|0x100000,False,child.pid);assert h
samples=0;peak_ws=0;peak_commit=0
try:
    image=ctypes.create_unicode_buffer(32768);size=w.DWORD(len(image))
    assert k.QueryFullProcessImageNameW(h,0,image,ctypes.byref(size))
    assert Path(image.value).resolve()==(job/'solver/soil-fem-3d.exe').resolve() and sha(Path(image.value))==expected
    times=[w.FILETIME() for _ in range(4)]
    assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
    ticks=lambda v:(v.dwHighDateTime<<32)|v.dwLowDateTime
    owner=read(out/'solve-child.json')
    assert abs(ticks(times[0])/1e7-11644473600-datetime.datetime.fromisoformat(owner['created_utc']).timestamp())<5
    with (out/'process-observations.jsonl').open('x') as stream:
        while child.poll() is None:
            memory=Counters();memory.cb=ctypes.sizeof(memory)
            assert k.K32GetProcessMemoryInfo(h,ctypes.byref(memory),memory.cb)
            assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
            peak_ws=max(peak_ws,memory.peak_ws);peak_commit=max(peak_commit,memory.peak_commit)
            try:status=read(job/'status.json')
            except FileNotFoundError:status={}
            stream.write(json.dumps(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                cpu_seconds=(ticks(times[2])+ticks(times[3]))/1e7,working_set_bytes=memory.ws,
                peak_working_set_bytes=memory.peak_ws,peak_commit_bytes=memory.peak_commit,
                status=status.get('last_progress')))+'\n');stream.flush();samples+=1
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:pass
    assert k.GetProcessTimes(h,*[ctypes.byref(x) for x in times])
    elapsed=(ticks(times[1])-ticks(times[0]))/1e7;cpu=(ticks(times[2])+ticks(times[3]))/1e7
finally:
    k.CloseHandle(h);log.close()
with (out/'process-terminal.json').open('x') as stream:
    json.dump(dict(exit_code=child.returncode,elapsed_seconds=elapsed,cpu_seconds=cpu,
        observed_peak_working_set_bytes=peak_ws,observed_peak_commit_bytes=peak_commit,samples=samples,
        solver_sha256=expected,held_handle_creation_and_image_verified=True,
        concurrent_other_validation_jobs=True,isolated_throughput_benchmark=False,p6_complete=False),stream,indent=2)
assert child.returncode==0
assert all(sha(Path(n))==v for n,v in binding.items())
subprocess.run([sys.executable,str(p/'verify.py'),str(args.subdivisions)],check=True)
with (out/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,files_sha256=binding,analytical_audit_passed=True,p6_complete=False),stream,indent=2)
print('PASS nonlinear hydrostatic '+str(args.subdivisions),flush=True)
