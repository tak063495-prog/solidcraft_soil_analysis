from pathlib import Path
import importlib.util,json,tempfile,unittest,sys
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p/'viewer-runtime/tools'));import export_solidcraft_view as view
class SourceBudget(unittest.TestCase):
 def test_only_explicit_result_reader_accepts_a_larger_source(self):
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'result.json';value=dict(material_history=list(range(100)));path.write_text(json.dumps(value),encoding='utf-8')
   # Bind small test budgets without constructing a giant test artifact.
   with self.assertRaises(ValueError):view.read(path,maximum=32)
   self.assertEqual(view.read_result(path),value)
 def test_source_limit_is_independent_of_packet_limits(self):
  old=view.MAX_SOURCE_RESULT
  try:
   view.MAX_SOURCE_RESULT=16
   with tempfile.TemporaryDirectory() as folder:
    path=Path(folder)/'source.json';path.write_text(json.dumps(dict(history=[1]*100)),encoding='utf-8')
    with self.assertRaisesRegex(ValueError,'source limit'):view.read_result(path)
    self.assertEqual(view.read(path),dict(history=[1]*100))
  finally:view.MAX_SOURCE_RESULT=old
  self.assertEqual(view.MAX_FILE,256<<20);self.assertEqual(view.MAX_TOTAL,512<<20)
 def test_nonfinite_source_numbers_remain_rejected(self):
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'bad.json'
   for raw in ['{"a":NaN}','{"a":1e999}']:
    path.write_text(raw,encoding='utf-8')
    with self.assertRaises(ValueError):view.read_result(path)
if __name__=='__main__':unittest.main()
