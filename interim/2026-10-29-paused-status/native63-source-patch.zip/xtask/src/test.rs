//! `cargo xtask test`: build the workspace's tests once, then run a bounded queue of test
//! binaries. `cargo test` runs them one after another, so one slow binary held up all the others;
//! the doc tests and any other `side` jobs run alongside on their own thread.

use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::mpsc;
use std::time::Instant;

use crate::{cargo, root};

/// A test executable from `cargo test --no-run`.
struct TestBin {
    label: String,
    exe: String,
    dir: String,
}

/// Build the tests with `cargo_args` (e.g. `--locked`), run each binary with `test_args`, and run
/// the `side` jobs one after another meanwhile. Each prints a line when it ends; a failure prints
/// its whole output.
pub fn run(cargo_args: &[&str], test_args: &[&str], side: Vec<(String, Command)>) -> Result<(), String> {
    let bins = build(cargo_args)?;
    #[cfg(windows)]
    let rust_library = rust_library_path()?;
    let configured = std::env::var("SOLIDCRAFT_TEST_JOBS").ok();
    let jobs = parallelism(configured.as_deref(), std::thread::available_parallelism().map_or(1, usize::from), bins.len())?;
    eprintln!("test: {jobs} concurrent binaries (SOLIDCRAFT_TEST_JOBS)");
    let next = AtomicUsize::new(0);
    let start = Instant::now();
    let (tx, rx) = mpsc::channel::<(String, Result<String, String>, f64)>();
    let mut failed = Vec::new();
    std::thread::scope(|scope| {
        for _ in 0..jobs {
            let tx = tx.clone();
            let bins = &bins;
            let next = &next;
            #[cfg(windows)]
            let rust_library = &rust_library;
            scope.spawn(move || {
                while let Some(b) = bins.get(next.fetch_add(1, Ordering::Relaxed)) {
                    let t0 = Instant::now();
                    let mut c = Command::new(&b.exe);
                    c.args(test_args).current_dir(&b.dir).env("CARGO_MANIFEST_DIR", &b.dir);
                    #[cfg(windows)]
                    match test_library_path(&b.exe, rust_library, std::env::var_os("PATH").as_deref()) {
                        Ok(path) => {
                            c.env("PATH", path);
                        }
                        Err(error) => {
                            let _ = tx.send((b.label.clone(), Err(error), t0.elapsed().as_secs_f64()));
                            continue;
                        }
                    }
                    let _ = tx.send((b.label.clone(), finish(c), t0.elapsed().as_secs_f64()));
                }
            });
        }
        let tx_side = tx.clone();
        scope.spawn(move || {
            for (label, c) in side {
                let t0 = Instant::now();
                let _ = tx_side.send((label, finish(c), t0.elapsed().as_secs_f64()));
            }
        });
        drop(tx);
        for (label, result, secs) in rx {
            match result {
                Ok(summary) => println!("ok    {label:<44} {secs:6.1}s  {summary}"),
                Err(output) => {
                    println!("FAIL  {label:<44} {secs:6.1}s\n{output}");
                    failed.push(label);
                }
            }
        }
    });
    println!("test: {} binaries in {:.1}s", bins.len(), start.elapsed().as_secs_f64());
    if failed.is_empty() { Ok(()) } else { Err(format!("failed: {}", failed.join(", "))) }
}

/// Cargo extends PATH for its own test launches. This runner launches their exact
/// artifacts itself, so Windows also needs the compiler's standard-library DLL
/// directory and the artifact's profile/deps directories (not just cargo's shims).
#[cfg(windows)]
fn rust_library_path() -> Result<std::path::PathBuf, String> {
    let rustc = std::env::var_os("RUSTC").unwrap_or_else(|| "rustc".into());
    let output = Command::new(rustc)
        .args(["--print", "target-libdir"])
        .current_dir(root())
        .stdin(Stdio::null())
        .output()
        .map_err(|e| format!("rustc library path: {e}"))?;
    if !output.status.success() {
        return Err(format!("rustc library path: {}: {}", output.status, String::from_utf8_lossy(&output.stderr)));
    }
    let text = String::from_utf8(output.stdout).map_err(|e| format!("rustc library path is not UTF-8: {e}"))?;
    let library = std::path::PathBuf::from(text.trim());
    if text.trim().is_empty() || !library.is_dir() {
        return Err("rustc returned a missing standard-library directory".into());
    }
    Ok(library)
}

#[cfg(windows)]
fn test_library_path(exe: &str, library: &std::path::Path, inherited: Option<&std::ffi::OsStr>) -> Result<std::ffi::OsString, String> {
    let deps = std::path::Path::new(exe).parent().ok_or_else(|| "test artifact has no parent directory".to_string())?;
    let profile = deps.parent().ok_or_else(|| "test artifact has no profile directory".to_string())?;
    let mut paths = vec![deps.to_path_buf(), profile.to_path_buf(), library.to_path_buf()];
    if let Some(inherited) = inherited {
        paths.extend(std::env::split_paths(inherited));
    }
    std::env::join_paths(paths).map_err(|e| format!("test DLL search path: {e}"))
}

fn parallelism(configured: Option<&str>, available: usize, binaries: usize) -> Result<usize, String> {
    let jobs = match configured {
        Some(value) => value
            .parse::<usize>()
            .ok()
            .filter(|n| (1..=64).contains(n))
            .ok_or_else(|| "SOLIDCRAFT_TEST_JOBS must be an integer in 1..=64".to_string())?,
        None => available.clamp(1, 4),
    };
    Ok(jobs.min(binaries.max(1)))
}

/// Run to the end: the last `test result:` line on success, all output on failure.
fn finish(mut c: Command) -> Result<String, String> {
    let out = c.stdin(Stdio::null()).output().map_err(|e| format!("failed to spawn: {e}"))?;
    let stdout = String::from_utf8_lossy(&out.stdout);
    if out.status.success() {
        Ok(stdout.lines().rev().find(|l| l.starts_with("test result:")).unwrap_or("").trim_start_matches("test result: ").to_string())
    } else {
        Err(format!("{stdout}{}\n({})", String::from_utf8_lossy(&out.stderr), out.status))
    }
}

/// `cargo test --workspace --profile ci --no-run`, and the executables it built.
fn build(cargo_args: &[&str]) -> Result<Vec<TestBin>, String> {
    let mut c = cargo();
    c.args(["test", "--workspace", "--profile", "ci", "--no-run", "--message-format=json-render-diagnostics"]).args(cargo_args);
    eprintln!("$ cargo test --workspace --profile ci --no-run");
    let out = c.stderr(Stdio::inherit()).output().map_err(|e| format!("cargo test --no-run: failed to spawn: {e}"))?;
    if !out.status.success() {
        return Err(format!("cargo test --no-run: exited with {}", out.status));
    }
    let mut bins: Vec<TestBin> = Vec::new();
    for line in String::from_utf8_lossy(&out.stdout).lines() {
        let Ok(m) = serde_json::from_str::<serde_json::Value>(line) else { continue };
        let Some(exe) = m["executable"].as_str().filter(|_| m["reason"] == "compiler-artifact" && m["profile"]["test"] == true) else {
            continue;
        };
        if bins.iter().any(|b| b.exe == exe) {
            continue;
        }
        let manifest = std::path::Path::new(m["manifest_path"].as_str().unwrap_or_default()).to_path_buf();
        let dir = manifest.parent().map(|d| d.to_path_buf()).unwrap_or_else(root);
        let pkg = dir.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
        let kind = m["target"]["kind"][0].as_str().unwrap_or("");
        let label = format!("{pkg} {kind} {}", m["target"]["name"].as_str().unwrap_or(""));
        bins.push(TestBin { label, exe: exe.to_string(), dir: dir.to_string_lossy().into_owned() });
    }
    if bins.is_empty() {
        return Err("cargo test --no-run built no test executables".into());
    }
    Ok(bins)
}

/// The doc tests (`cargo test --doc`), to run as a side job.
pub fn doc_tests(cargo_args: &[&str], test_args: &[&str]) -> (String, Command) {
    let mut c = cargo();
    c.args(["test", "--workspace", "--profile", "ci", "--doc"]).args(cargo_args).arg("--").args(test_args);
    ("doc tests".into(), c)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    #[cfg(windows)]
    fn direct_artifacts_keep_cargo_library_and_inherited_search_paths() {
        use std::path::{Path, PathBuf};
        let old = std::env::join_paths([PathBuf::from("D:/Tools with spaces"), PathBuf::from("D:/Other")]).unwrap();
        let path = test_library_path("D:/Build output/ci/deps/test.exe", Path::new("D:/Rust lib"), Some(&old)).unwrap();
        let paths: Vec<_> = std::env::split_paths(&path).collect();
        assert_eq!(paths, ["D:/Build output/ci/deps", "D:/Build output/ci", "D:/Rust lib", "D:/Tools with spaces", "D:/Other"].map(PathBuf::from));
        assert!(test_library_path("test.exe", Path::new("D:/Rust lib"), None).is_err());
    }
    #[test]
    fn binary_parallelism_is_bounded_and_invalid_overrides_fail() {
        assert_eq!(parallelism(None, 128, 500).unwrap(), 4);
        assert_eq!(parallelism(None, 1, 500).unwrap(), 1);
        assert_eq!(parallelism(Some("2"), 128, 500).unwrap(), 2);
        assert_eq!(parallelism(Some("64"), 128, 3).unwrap(), 3);
        for value in ["0", "65", "many", "-1"] {
            assert!(parallelism(Some(value), 128, 500).is_err());
        }
    }
    #[test]
    fn concurrent_binary_queue_visits_every_entry_exactly_once() {
        let next = AtomicUsize::new(0);
        let values: Vec<_> = (0..257).map(|_| AtomicUsize::new(0)).collect();
        std::thread::scope(|scope| {
            for _ in 0..4 {
                scope.spawn(|| {
                    while let Some(value) = values.get(next.fetch_add(1, Ordering::Relaxed)) {
                        value.fetch_add(1, Ordering::Relaxed);
                    }
                });
            }
        });
        assert!(values.iter().all(|v| v.load(Ordering::Relaxed) == 1));
    }
}
