//! The soil-analysis editor and immutable external-analysis capture share this registry.
use super::CommandSpec;
pub static COMMANDS: &[CommandSpec] = &[
    CommandSpec::new("analysis.soil.results.open", "Open Soil Results", crate::soil_results::open)
        .icon("settings").noundo().params("manifest: workflow/view/view-manifest.json, expected_input_sha256; validate the completed native result, source hashes and VTU audit; never run a saved design"),
    CommandSpec::new("analysis.soil.results.status", "Soil Result Viewer", crate::soil_results::status)
        .icon("settings").noundo().params("No parameters; result/frame/quantity metadata, ranges, approximation and current-model staleness; no dialog in programmatic calls"),
    CommandSpec::new("analysis.soil.results.configure", "Configure Soil Result View", crate::soil_results::configure)
        .icon("settings").noundo().params("Full transient settings: frame, quantity, displacement_reference, deformation_scale, refinement: 1..3, section: null|{normal,offset_m,slice_only}, color_range: null|[min,max], wireframe, principal_directions; no CAD mutation"),
    CommandSpec::new("analysis.soil.results.query", "Inspect Soil Result Value", crate::soil_results::query)
        .icon("settings").noundo().params("Exactly one: node, element, integration_point, primary_node plus primary_material, structural_node, beam, plate, or ray_origin_mm plus ray_direction; distinguish material GP stress, work-conjugate stress, primary pressure, cell means, raw local member actions and display interpolation; inactive members retain archived kinematics with null results"),
    CommandSpec::new("analysis.soil.results.close", "Close Soil Results", crate::soil_results::close)
        .icon("settings").noundo().params("No parameters; release the transient result without changing the design, undo state or files"),
    CommandSpec::new("analysis.soil.job.start", "Start Soil Analysis", crate::soil_jobs::start)
        .icon("settings").noundo()
        .params("directory: new job folder, expected_input_sha256, mesh_size_m, element_order: 1|2, quadrature_order: 3|4|5, cooperative?: false (legacy default); capture reviewed inputs and start only the installed native host worker"),
    CommandSpec::new("analysis.soil.job.status", "Inspect Soil Analysis Job", crate::soil_jobs::status)
        .icon("settings").noundo()
        .params("No parameters; inspect the last owned process and worker report, input staleness and verified completion; never infer process liveness from a status file"),
    CommandSpec::new("analysis.soil.job.resume", "Resume Soil Analysis", crate::soil_jobs::resume)
        .icon("settings").noundo()
        .params("directory: new output folder, previous_directory: saved native job folder, expected_input_sha256; resume bound data with the installed host solver and workflow, never executable paths from saved data"),
    CommandSpec::new("analysis.soil.job.cancel", "Stop Soil Analysis", crate::soil_jobs::cancel)
        .icon("settings").noundo()
        .params("job: identity returned by job.start/status; close the owned worker pipe, saving at an accepted increment for cooperative jobs or stopping legacy jobs; idempotent for a retained terminal job"),
    CommandSpec::new("analysis.soil.read_inputs", "Read Soil Analysis Inputs", crate::soil_fem::read_inputs)
        .icon("settings").noundo().doc_only()
        .params("ground_path, stages_path: explicitly allowed JSON files, at most 64 KiB together; read bridge-contract-valid inputs without changing a design or running a solver"),
    CommandSpec::new("analysis.soil.model", "Soil Analysis", crate::soil_fem::model)
        .icon("settings").noundo().at("SOLID", "INSPECT")
        .params("Read the saved ground/stages, persistent CAD body bindings, source fingerprints and unresolved/changed-input diagnostics; no solver is run"),
    CommandSpec::new("analysis.soil.configure", "Save Soil Analysis", crate::soil_fem::configure)
        .icon("settings")
        .params("ground, stages, bindings: [{analysis_body, cad_body}], expected_cad_sha256, expected_setup_sha256 (from analysis.soil.model); one atomic undo step; material admissibility requires the external FEM validator"),
    CommandSpec::new("analysis.soil.snapshot", "Inspect Soil Analysis Snapshot", crate::soil_fem::snapshot)
        .icon("settings").noundo()
        .params("Read an immutable input snapshot only when bindings resolve and the CAD revision has been reviewed; never infer materials from CAD appearances"),
    CommandSpec::new("analysis.soil.export", "Export Soil Analysis", crate::soil_fem::export)
        .icon("settings").noundo()
        .params("directory: new output folder, expected_input_sha256: from snapshot; export body-resolved STEP, ground/stages and source design without invoking a solver; native desktop only"),
];
