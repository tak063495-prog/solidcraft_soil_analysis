//! Transient, host-owned external FEM jobs. Neither executable paths nor process
//! ownership are read from a design. Scratch sessions have no execution host.
use crate::{Result, Session, params::bad};
use serde::Deserialize;
use serde_json::{Value, json};

const CMD: &str = "analysis.soil.job";

#[cfg(not(target_arch = "wasm32"))]
fn expected_view_schema(snapshot: &Value) -> Result<&'static str> {
    let standard = match snapshot.pointer("/snapshot/stages/schema").and_then(Value::as_str) {
        Some("soil-fem-stages/1") => Ok("soil-fem-solidcraft-view/1"),
        Some("soil-fem-projected-mcc-stages/1") => Ok("soil-fem-solidcraft-view/2"),
        _ => Err(bad(CMD, "unsupported captured construction family")),
    }?;
    let structural =
        ["beam_system", "plate_surfaces"].iter().any(|name| snapshot.pointer(&format!("/snapshot/stages/{name}")).is_some_and(Value::is_object));
    Ok(if structural { "soil-fem-solidcraft-view/3" } else { standard })
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Start {
    directory: String,
    expected_input_sha256: String,
    mesh_size_m: f64,
    element_order: u8,
    quadrature_order: u8,
    #[serde(default)]
    cooperative: bool,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Resume {
    directory: String,
    previous_directory: String,
    expected_input_sha256: String,
}

#[cfg(not(target_arch = "wasm32"))]
mod native {
    use super::*;
    use sha2::{Digest, Sha256};
    use std::{
        fs::OpenOptions,
        path::{Path, PathBuf},
        process::{Child, Command, Stdio},
    };

    fn identity(session_serial: u64) -> Result<String> {
        use std::sync::atomic::{AtomicU64, Ordering};
        static NEXT: AtomicU64 = AtomicU64::new(1);
        let serial = NEXT.try_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1)).map_err(|_| bad(CMD, "job identity exhausted"))?;
        let time = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_err(|e| bad(CMD, e.to_string()))?;
        // The process-wide counter distinguishes simultaneous starts in separate
        // document sessions even when Windows reports the same clock tick.
        Ok(format!("{}-{}-{session_serial}-{serial}", std::process::id(), time.as_nanos()))
    }

    #[derive(Clone)]
    pub(super) struct Host {
        root: PathBuf,
        python: PathBuf,
        worker: PathBuf,
        solver: Option<PathBuf>,
    }

    fn external_path(path: &Path) -> Result<PathBuf> {
        let canonical = path.canonicalize().map_err(|e| bad(CMD, e.to_string()))?;
        #[cfg(windows)]
        {
            // std::fs returns a verbatim path. PowerShell and other external
            // tools need the normal local-drive spelling, including for script
            // authorization. Do not alter execution policy or accept UNC roots.
            let text = canonical.to_str().ok_or_else(|| bad(CMD, "external FEM paths must be Unicode"))?;
            if let Some(local) = text.strip_prefix(r"\\?\") {
                if local.as_bytes().first().is_some_and(u8::is_ascii_alphabetic)
                    && local.as_bytes().get(1) == Some(&b':')
                    && local.as_bytes().get(2) == Some(&b'\\')
                {
                    return Ok(PathBuf::from(local));
                }
                return Err(bad(CMD, "external FEM requires a local-drive path"));
            }
        }
        Ok(canonical)
    }

    impl Host {
        pub(super) fn new(root: &Path) -> Result<Self> {
            let root = external_path(root)?;
            let python = root.join(if cfg!(windows) { ".venv/Scripts/python.exe" } else { ".venv/bin/python" });
            let worker = root.join("tools/native_job.py");
            for path in [&python, &worker] {
                if !path.is_file() {
                    return Err(bad(CMD, format!("FEM host file is missing: {}", path.display())));
                }
            }
            Ok(Self { root, python, worker, solver: None })
        }
    }

    pub(super) struct Owned {
        pub(super) child: Child,
        directory: PathBuf,
        input: String,
        view_schema: &'static str,
        token: String,
        worker_id: Option<String>,
        cancelled: bool,
        cooperative: bool,
    }

    impl Drop for Owned {
        fn drop(&mut self) {
            // The worker watches EOF and stops its own PowerShell/solver tree.
            // No saved PID is ever signalled by the host, including on shutdown.
            self.child.stdin.take();
        }
    }

    pub(super) fn read(path: &Path) -> Result<Value> {
        let bytes = solidcraft_io::vfs::read(&path.to_string_lossy(), 256 << 10).map_err(|e| bad(CMD, e.to_string()))?;
        serde_json::from_slice(&bytes).map_err(|e| bad(CMD, e.to_string()))
    }

    fn hash(path: &Path) -> Result<String> {
        let bytes = solidcraft_io::vfs::read(&path.to_string_lossy(), 256 << 10).map_err(|e| bad(CMD, e.to_string()))?;
        Ok(format!("{:x}", Sha256::digest(bytes)))
    }

    fn artifact_hash(path: &Path, expected_size: u64) -> Result<String> {
        use std::io::Read;
        if expected_size > 8 << 30 {
            return Err(bad(CMD, "checkpoint artifact exceeds its size limit"));
        }
        solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
        let mut file = std::fs::File::open(path).map_err(|e| bad(CMD, e.to_string()))?;
        let mut digest = Sha256::new();
        let mut total = 0_u64;
        let mut buffer = [0_u8; 65536];
        loop {
            let size = file.read(&mut buffer).map_err(|e| bad(CMD, e.to_string()))?;
            if size == 0 {
                break;
            }
            total += size as u64;
            if total > expected_size {
                return Err(bad(CMD, "checkpoint artifact size changed"));
            }
            digest.update(buffer.get(..size).ok_or_else(|| bad(CMD, "invalid checkpoint read size"))?);
        }
        if total != expected_size {
            return Err(bad(CMD, "checkpoint artifact size changed"));
        }
        Ok(format!("{:x}", digest.finalize()))
    }

    pub(super) fn saved_checkpoint(folder: &Path, input: &str, report: &Value) -> Result<()> {
        let owner = read(&folder.join("job.json"))?;
        let receipt_path = folder.join("checkpoint-receipt.json");
        let receipt = read(&receipt_path)?;
        let solver = owner.get("solver_sha256").and_then(Value::as_str).filter(|s| s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit()));
        let artifact = match receipt.get("kind").and_then(Value::as_str) {
            Some("solver_checkpoint") => "workflow/analysis/solver-job/checkpoint.json",
            Some("completed_solver_result") => "workflow/analysis/stage-results.json",
            _ => return Err(bad(CMD, "unsupported saved checkpoint kind")),
        };
        if owner.get("schema").and_then(Value::as_str) != Some("soil-fem-native-job/2")
            || report.get("schema").and_then(Value::as_str) != Some("soil-fem-native-job-status/2")
            || report.get("state").and_then(Value::as_str) != Some("checkpointed")
            || report.get("exit_code").and_then(Value::as_i64) != Some(3)
            || solver.is_none()
            || report.get("resume_available") != Some(&Value::Bool(true))
            || report.get("checkpoint_receipt").and_then(Value::as_str) != Some("checkpoint-receipt.json")
            || report.get("checkpoint_receipt_sha256").and_then(Value::as_str) != Some(&hash(&receipt_path)?)
            || receipt.get("schema").and_then(Value::as_str) != Some("soil-fem-native-checkpoint/1")
            || owner.get("job_id").and_then(Value::as_str).is_none_or(str::is_empty)
            || report.get("job_id") != owner.get("job_id")
            || receipt.get("job_id") != owner.get("job_id")
            || owner.get("input_sha256").and_then(Value::as_str) != Some(input)
            || report.get("input_sha256").and_then(Value::as_str) != Some(input)
            || receipt.get("input_sha256").and_then(Value::as_str) != Some(input)
            || receipt.get("solver_sha256") != owner.get("solver_sha256")
            || receipt.get("artifact").and_then(Value::as_str) != Some(artifact)
        {
            return Err(bad(CMD, "saved checkpoint identity or receipt changed"));
        }
        let size = receipt.get("artifact_bytes").and_then(Value::as_u64).ok_or_else(|| bad(CMD, "checkpoint size is missing"))?;
        if receipt.get("artifact_sha256").and_then(Value::as_str) != Some(&artifact_hash(&folder.join(artifact), size)?) {
            return Err(bad(CMD, "saved checkpoint artifact changed"));
        }
        Ok(())
    }

    impl Owned {
        fn report(&mut self) -> Result<Value> {
            let report = read(&self.directory.join("job/status.json"))?;
            let owner = read(&self.directory.join("job/job.json"))?;
            let id = report.get("job_id").and_then(Value::as_str).filter(|s| !s.is_empty() && s.len() <= 128);
            let state = report.get("state").and_then(Value::as_str).unwrap_or_default();
            if report.get("schema").and_then(Value::as_str) != Some(if self.cooperative { "soil-fem-native-job-status/2" } else { "soil-fem-native-job-status/1" })
                || owner.get("schema").and_then(Value::as_str) != Some(if self.cooperative { "soil-fem-native-job/2" } else { "soil-fem-native-job/1" })
                || id.is_none()
                || report.get("job_id") != owner.get("job_id")
                || self.worker_id.as_deref().is_some_and(|known| Some(known) != id)
                || report.get("input_sha256").and_then(Value::as_str) != Some(&self.input)
                || owner.get("input_sha256").and_then(Value::as_str) != Some(&self.input)
                // Windows venv launchers may own another Python process. Bind reports
                // with the launch token, while liveness always comes from Child.
                || report.get("host_token").and_then(Value::as_str) != Some(&self.token)
                || owner.get("host_token").and_then(Value::as_str) != Some(&self.token)
                || !(matches!(state, "preparing" | "running" | "cancelling" | "cancelled" | "succeeded" | "failed") || (self.cooperative && state == "checkpointed"))
            {
                return Err(bad(CMD, "worker status does not match this owned job"));
            }
            self.worker_id = id.map(str::to_string);
            Ok(report)
        }

        fn completed_result(&self, report: &Value) -> Result<String> {
            const RESULT: &str = "workflow/view/view-manifest.json";
            if report.get("result").and_then(Value::as_str) != Some(RESULT) {
                return Err(bad(CMD, "worker did not publish the expected result"));
            }
            let folder = self.directory.join("job");
            let path = folder.join(RESULT);
            let audit_path = folder.join("workflow/view-verification.json");
            let manifest = read(&path)?;
            let owner = read(&folder.join("job.json"))?;
            let audit = read(&audit_path)?;
            let digest = hash(&path)?;
            let solver = owner.get("solver_sha256").and_then(Value::as_str).filter(|s| s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit()));
            if manifest.get("schema").and_then(Value::as_str) != Some(self.view_schema)
                || solver.is_none()
                || manifest.get("complete") != Some(&Value::Bool(true))
                || manifest.get("input_sha256").and_then(Value::as_str) != Some(&self.input)
                || manifest.get("solver_binary_sha256") != owner.get("solver_sha256")
                || report.get("result_sha256").and_then(Value::as_str) != Some(&digest)
                || audit.get("passed") != Some(&Value::Bool(true))
                || audit.get("input_sha256").and_then(Value::as_str) != Some(&self.input)
                || audit.get("view_manifest_sha256").and_then(Value::as_str) != Some(&digest)
                || report.get("view_audit_sha256").and_then(Value::as_str) != Some(&hash(&audit_path)?)
            {
                return Err(bad(CMD, "result, audit or input version differs from the owned job"));
            }
            Ok(path.to_string_lossy().into_owned())
        }

        pub(super) fn observe(&mut self) -> Result<Value> {
            let exit = self.child.try_wait().map_err(|e| bad(CMD, e.to_string()))?;
            let alive = exit.is_none();
            let code = exit.and_then(|e| e.code());
            let report_path = self.directory.join("job/status.json");
            let awaiting_first_report = alive
                && solidcraft_io::vfs::check(&report_path.to_string_lossy()).is_ok()
                && std::fs::metadata(&report_path).is_err_and(|e| e.kind() == std::io::ErrorKind::NotFound);
            let observed = if awaiting_first_report { Ok(Value::Null) } else { self.report() };
            let (report, mut observation_error) = match observed {
                Ok(value) => (value, None),
                Err(error) => (Value::Null, Some(error.to_string())),
            };
            let mut result = None;
            let state = if alive {
                if self.cancelled { "cancelling" } else { "running" }
            } else if code == Some(0) && report.get("state").and_then(Value::as_str) == Some("succeeded") {
                match self.completed_result(&report) {
                    Ok(path) => {
                        result = Some(path);
                        "succeeded"
                    }
                    Err(error) => {
                        observation_error = Some(error.to_string());
                        "failed"
                    }
                }
            } else if code == Some(2) && report.get("state").and_then(Value::as_str) == Some("cancelled") {
                "cancelled"
            } else if self.cooperative && code == Some(3) {
                match saved_checkpoint(&self.directory.join("job"), &self.input, &report) {
                    Ok(()) => "checkpointed",
                    Err(error) => {
                        observation_error = Some(error.to_string());
                        "failed"
                    }
                }
            } else {
                "failed"
            };
            Ok(json!({"job":self.token,"directory":self.directory,"input_sha256":self.input,"state":state,
                "process_alive":alive,"process_exit_code":code,"worker_report":report,"observation_error":observation_error,
                "cancel_requested":self.cancelled,"result":result,
                "resume_available":state == "checkpointed",
                "stop_policy":if self.cooperative { "cooperative_staged_checkpoint" } else { "process_stop_without_new_checkpoint" }}))
        }
    }

    #[derive(Default)]
    pub(crate) struct Jobs {
        host: Option<Host>,
        job: Option<Owned>,
        serial: u64,
    }

    impl Jobs {
        pub(super) fn host(&self) -> Option<&Host> {
            self.host.as_ref()
        }

        pub(super) fn busy(&mut self) -> Result<bool> {
            self.job.as_mut().map(|j| j.child.try_wait().map(|s| s.is_none()).map_err(|e| bad(CMD, e.to_string()))).unwrap_or(Ok(false))
        }

        pub(super) fn start(&mut self, host: Host, request: &Start, input: String, view_schema: &'static str) -> Result<()> {
            self.launch(host, Path::new(&request.directory), input, Some(request), None, view_schema)
        }

        pub(super) fn resume(&mut self, host: Host, directory: &Path, previous: &Path, input: String, view_schema: &'static str) -> Result<()> {
            self.launch(host, directory, input, None, Some(previous), view_schema)
        }

        fn launch(
            &mut self,
            host: Host,
            directory: &Path,
            input: String,
            request: Option<&Start>,
            previous: Option<&Path>,
            view_schema: &'static str,
        ) -> Result<()> {
            let directory = external_path(directory)?;
            let log_path = directory.join("host-worker.log");
            let log = OpenOptions::new().write(true).create_new(true).open(&log_path).map_err(|e| bad(CMD, e.to_string()))?;
            let serial = self.serial.checked_add(1).ok_or_else(|| bad(CMD, "job counter exhausted"))?;
            let token = identity(serial)?;
            let mut command = Command::new(&host.python);
            command.arg(&host.worker);
            if let Some(request) = request {
                command.arg("run").arg(directory.join("capture")).arg(directory.join("job")).args([
                    "--mesh-size-m",
                    &request.mesh_size_m.to_string(),
                    "--order",
                    &request.element_order.to_string(),
                    "--quadrature",
                    &request.quadrature_order.to_string(),
                ]);
                if request.cooperative {
                    command.arg("--cooperative");
                }
            } else if let Some(previous) = previous {
                command.arg("resume").arg(previous.join("job")).arg(directory.join("job"));
            } else {
                return Err(bad(CMD, "missing job launch request"));
            }
            if let Some(solver) = &host.solver {
                command.arg("--solver").arg(solver);
            }
            command
                .args(["--expected-input-sha256", &input, "--watch-stdin", "--host-token", &token])
                .current_dir(&host.root)
                .env("PYTHONUTF8", "1")
                .stdin(Stdio::piped())
                .stderr(log.try_clone().map_err(|e| bad(CMD, e.to_string()))?)
                .stdout(log);
            #[cfg(windows)]
            {
                use std::os::windows::process::CommandExt;
                command.creation_flags(0x08000000); // CREATE_NO_WINDOW
            }
            let child = command.spawn().map_err(|e| bad(CMD, format!("could not start FEM worker: {e}")))?;
            self.serial = serial;
            self.job = Some(Owned {
                child,
                directory,
                input,
                view_schema,
                token,
                worker_id: None,
                cancelled: false,
                cooperative: request.is_none_or(|r| r.cooperative),
            });
            Ok(())
        }

        pub(super) fn status(&mut self) -> Result<Value> {
            let mut value = match self.job.as_mut() {
                Some(j) => j.observe()?,
                None => json!({"state":"idle"}),
            };
            value["host_available"] = json!(self.host.is_some());
            value["host_root"] = json!(self.host.as_ref().map(|h| h.root.to_string_lossy().into_owned()));
            Ok(value)
        }

        pub(super) fn cancel(&mut self, token: &str) -> Result<()> {
            let job = self.job.as_mut().filter(|j| j.token == token).ok_or_else(|| bad(CMD, "unknown job in this document session"))?;
            if job.child.try_wait().map_err(|e| bad(CMD, e.to_string()))?.is_none() {
                job.cancelled = true;
                job.child.stdin.take();
            }
            Ok(())
        }
    }

    impl Session {
        /// Override a program only through native host configuration, never a design or command.
        pub fn set_soil_job_solver(&mut self, solver: &Path) -> Result<()> {
            if self.soil_jobs.busy()? {
                return Err(bad(CMD, "cannot replace an active FEM solver"));
            }
            let solver = external_path(solver)?;
            if !solver.is_file() {
                return Err(bad(CMD, "FEM solver must be an installed file"));
            }
            let host = self.soil_jobs.host.as_mut().ok_or_else(|| bad(CMD, "configure the FEM host before its solver"))?;
            host.solver = Some(solver);
            Ok(())
        }
        /// Install only from explicit native host configuration, never design metadata.
        pub fn set_soil_job_root(&mut self, root: &Path) -> Result<()> {
            if self.soil_jobs.busy()? {
                return Err(bad(CMD, "cannot replace an active FEM host"));
            }
            self.soil_jobs.host = Some(Host::new(root)?);
            Ok(())
        }
    }

    #[cfg(test)]
    mod tests {
        use super::*;
        use std::{
            io::Read,
            time::{Duration, Instant, SystemTime, UNIX_EPOCH},
        };

        fn folder() -> PathBuf {
            static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
            let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/soil-job-tests").join(format!(
                "{}-{}-{}",
                std::process::id(),
                SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos(),
                NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
            ));
            std::fs::create_dir_all(root.join("job/workflow/view")).unwrap();
            root
        }

        fn configured() -> Session {
            let mut s = Session::default();
            s.execute("solid.box", &json!({"length":1000,"width":1000,"height":1000})).unwrap();
            let model = crate::soil_fem::inspect(&s).unwrap();
            let name = s.model.state().bodies.first().unwrap().name.clone();
            s.execute(
                "analysis.soil.configure",
                &json!({
                "ground":{"schema":"soil-fem-ground/1","units":"m-kN-kPa","initialization":{"method":"equilibrate"},"materials":[{"id":1}],"bodies":[{"body":"Clay","material_id":1}]},
                "stages":{"schema":"soil-fem-stages/1","stages":[]},"bindings":[{"analysis_body":"Clay","cad_body":name}],
                "expected_cad_sha256":model["cad_sha256"],"expected_setup_sha256":model["setup_sha256"]}),
            )
            .unwrap();
            s
        }

        fn owned(s: &mut Session, directory: PathBuf) {
            owned_mode(s, directory, false);
        }

        fn owned_mode(s: &mut Session, directory: PathBuf, cooperative: bool) {
            let frozen = crate::soil_fem::snapshot(s, &json!({})).unwrap();
            let input = frozen["input_sha256"].as_str().unwrap().to_string();
            let view_schema = expected_view_schema(&frozen).unwrap();
            let mut cmd = Command::new(std::env::current_exe().unwrap());
            cmd.args(["--exact", "soil_jobs::native::tests::job_child_protocol", "--nocapture"])
                .env("SOLIDCRAFT_SOIL_JOB_TEST_CHILD", if cooperative { "checkpoint-after-eof" } else { "wait-for-eof" })
                .stdin(Stdio::piped())
                .stdout(Stdio::null())
                .stderr(Stdio::null());
            #[cfg(windows)]
            {
                use std::os::windows::process::CommandExt;
                cmd.creation_flags(0x08000000);
            }
            let child = cmd.spawn().unwrap();
            s.soil_jobs.job =
                Some(Owned { child, directory, input, view_schema, token: "owned-token".into(), worker_id: None, cancelled: false, cooperative });
        }

        fn write(path: &Path, value: &Value) {
            std::fs::write(path, serde_json::to_vec(value).unwrap()).unwrap();
        }

        fn receipt(s: &Session) {
            let j = s.soil_jobs.job.as_ref().unwrap();
            let folder = j.directory.join("job");
            write(
                &folder.join("job.json"),
                &json!({"schema":"soil-fem-native-job/1","job_id":"worker-owned","host_token":j.token,"input_sha256":j.input,"solver_sha256":"a".repeat(64)}),
            );
            write(
                &folder.join("workflow/view/view-manifest.json"),
                &json!({"schema":j.view_schema,"complete":true,"input_sha256":j.input,"solver_binary_sha256":"a".repeat(64)}),
            );
            let manifest = hash(&folder.join("workflow/view/view-manifest.json")).unwrap();
            write(&folder.join("workflow/view-verification.json"), &json!({"passed":true,"input_sha256":j.input,"view_manifest_sha256":manifest}));
            write(
                &folder.join("status.json"),
                &json!({"schema":"soil-fem-native-job-status/1","job_id":"worker-owned","input_sha256":j.input,
                "host_token":j.token,"worker_pid":j.child.id()+1,"state":"succeeded","result":"workflow/view/view-manifest.json","result_sha256":manifest,
                "view_audit_sha256":hash(&folder.join("workflow/view-verification.json")).unwrap()}),
            );
        }

        fn finish(s: &mut Session) {
            let j = s.soil_jobs.job.as_mut().unwrap();
            j.child.stdin.take();
            let deadline = Instant::now() + Duration::from_secs(10);
            while j.child.try_wait().unwrap().is_none() && Instant::now() < deadline {
                std::thread::sleep(Duration::from_millis(20));
            }
            assert!(j.child.try_wait().unwrap().is_some(), "owned test child must finish after pipe closure");
        }

        fn saved_receipt(s: &Session) {
            let job = s.soil_jobs.job.as_ref().unwrap();
            let folder = job.directory.join("job");
            let artifact = "workflow/analysis/solver-job/checkpoint.json";
            std::fs::create_dir_all(folder.join("workflow/analysis/solver-job")).unwrap();
            let bytes = b"checkpoint data only";
            std::fs::write(folder.join(artifact), bytes).unwrap();
            write(
                &folder.join("job.json"),
                &json!({"schema":"soil-fem-native-job/2","job_id":"worker-owned","host_token":job.token,
                "input_sha256":job.input,"solver_sha256":"a".repeat(64)}),
            );
            write(
                &folder.join("checkpoint-receipt.json"),
                &json!({"schema":"soil-fem-native-checkpoint/1","job_id":"worker-owned",
                "input_sha256":job.input,"solver_sha256":"a".repeat(64),"kind":"solver_checkpoint","artifact":artifact,
                "artifact_bytes":bytes.len(),"artifact_sha256":artifact_hash(&folder.join(artifact),bytes.len() as u64).unwrap()}),
            );
            write(
                &folder.join("status.json"),
                &json!({"schema":"soil-fem-native-job-status/2","job_id":"worker-owned","host_token":job.token,
                "input_sha256":job.input,"state":"checkpointed","exit_code":3,"resume_available":true,
                "checkpoint_receipt":"checkpoint-receipt.json","checkpoint_receipt_sha256":hash(&folder.join("checkpoint-receipt.json")).unwrap()}),
            );
        }

        #[test]
        fn job_child_protocol() {
            let mode = std::env::var("SOLIDCRAFT_SOIL_JOB_TEST_CHILD");
            if !matches!(mode.as_deref(), Ok("wait-for-eof" | "checkpoint-after-eof")) {
                return;
            }
            let mut buffer = Vec::new();
            std::io::stdin().read_to_end(&mut buffer).unwrap();
            if mode.as_deref() == Ok("checkpoint-after-eof") {
                std::process::exit(3);
            }
        }

        #[test]
        fn saved_state_requires_owned_process_exit_and_matching_data_and_current_cad() {
            let mut s = configured();
            let root = folder();
            owned_mode(&mut s, root.clone(), true);
            saved_receipt(&s);
            let alive = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(alive["process_alive"], true);
            assert_eq!(alive["resume_available"], false, "a saved report cannot override a live owned process");
            finish(&mut s);
            let saved = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(saved["state"], "checkpointed", "{saved}");
            assert_eq!(saved["process_exit_code"], 3);
            assert_eq!(saved["resume_usable"], true);
            assert_eq!(saved["result_usable"], false);
            assert_eq!(saved["stop_policy"], "cooperative_staged_checkpoint");
            let original = s.model.state().bodies.first().unwrap().name.clone();
            s.execute("body.rename", &json!({"body":original,"name":"changed"})).unwrap();
            assert_eq!(s.execute("analysis.soil.job.status", &json!({})).unwrap()["resume_usable"], false);
            s.execute("edit.undo", &json!({})).unwrap();
            assert_eq!(s.execute("analysis.soil.job.status", &json!({})).unwrap()["resume_usable"], true);
            std::fs::write(root.join("job/workflow/analysis/solver-job/checkpoint.json"), b"changed").unwrap();
            let invalid = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(invalid["state"], "failed");
            assert_eq!(invalid["resume_available"], false);
        }

        #[test]
        fn resume_checks_current_input_and_saved_artifact_before_creating_output_and_refuses_program_parameters() {
            let mut s = configured();
            let root = folder();
            owned_mode(&mut s, root.clone(), true);
            saved_receipt(&s);
            finish(&mut s);
            s.soil_jobs.host = Some(Host { root: root.clone(), python: PathBuf::from("unused"), worker: PathBuf::from("unused"), solver: None });
            let input = s.soil_jobs.job.as_ref().unwrap().input.clone();
            let output = root.join("refused-resume");
            let mut params = json!({"directory":output,"previous_directory":root,"expected_input_sha256":input});
            params["solver"] = json!("a program supplied by saved data");
            assert!(s.execute("analysis.soil.job.resume", &params).is_err());
            params.as_object_mut().unwrap().remove("solver");
            params["expected_input_sha256"] = json!("wrong");
            assert!(s.execute("analysis.soil.job.resume", &params).is_err());
            assert!(!output.exists());
            params["expected_input_sha256"] = json!(input);
            std::fs::write(root.join("job/workflow/analysis/solver-job/checkpoint.json"), b"changed").unwrap();
            let error = s.execute("analysis.soil.job.resume", &params).unwrap_err().to_string();
            assert!(error.contains("artifact"), "{error}");
            assert!(!output.exists());
        }

        #[test]
        fn external_paths_have_the_local_spelling_expected_by_native_tools() {
            let root = folder();
            let path = external_path(&root).unwrap();
            assert!(path.is_absolute() && path.is_dir());
            #[cfg(windows)]
            assert!(!path.to_string_lossy().starts_with(r"\\?\"));
        }

        #[test]
        fn simultaneous_sessions_have_distinct_process_wide_job_identities() {
            let tokens: Vec<_> = std::thread::scope(|scope| {
                let tasks: Vec<_> = (0..32).map(|_| scope.spawn(|| identity(1).unwrap())).collect();
                tasks.into_iter().map(|t| t.join().unwrap()).collect()
            });
            let serials: std::collections::BTreeSet<_> = tokens.iter().map(|s| s.rsplit('-').next().unwrap()).collect();
            assert_eq!(serials.len(), tokens.len());
        }

        #[test]
        fn only_explicit_host_configuration_can_launch_and_scratch_has_no_host() {
            let mut s = configured();
            let root = folder();
            let out = root.join("refused");
            s.doc_mut().metadata.set("org.solidcraft.test.fem-host", json!({"root":root,"program":"anything"})).unwrap();
            let p = json!({"directory":out,"expected_input_sha256":"wrong","mesh_size_m":1.,"element_order":2,"quadrature_order":3});
            assert!(s.execute("analysis.soil.job.start", &p).is_err());
            assert!(!out.exists());
            // A trusted test host is installed directly; design fields never install one.
            s.soil_jobs.host = Some(Host { root: root.clone(), python: PathBuf::from("unused"), worker: PathBuf::from("unused"), solver: None });
            let mut scratch = s.scratch();
            assert!(scratch.soil_jobs.host().is_none());
            assert!(scratch.execute("analysis.soil.job.start", &p).is_err());
            assert!(!out.exists());
            s.replace_design(Session::default());
            assert_eq!(s.soil_jobs.host().unwrap().root, root);
        }

        #[test]
        fn compact_plate_declaration_requires_structural_view_family() {
            for family in ["soil-fem-stages/1", "soil-fem-projected-mcc-stages/1"] {
                let snapshot = json!({"snapshot":{"stages":{"schema":family,"plate_surfaces":{"schema":"soil-fem-plate-surfaces/3","surfaces":[]}}}});
                assert_eq!(expected_view_schema(&snapshot).unwrap(), "soil-fem-solidcraft-view/3");
                for malformed in [Value::Null, json!([]), json!("plates")] {
                    let mut invalid = snapshot.clone();
                    invalid["snapshot"]["stages"]["plate_surfaces"] = malformed;
                    let standard = if family == "soil-fem-stages/1" { "soil-fem-solidcraft-view/1" } else { "soil-fem-solidcraft-view/2" };
                    assert_eq!(expected_view_schema(&invalid).unwrap(), standard);
                }
            }
        }

        #[test]
        fn completed_view_family_is_bound_to_launch_snapshot_even_after_receipt_resealing() {
            assert!(expected_view_schema(&json!({})).is_err());
            assert!(expected_view_schema(&json!({"snapshot":{"stages":{"schema":"unknown"}}})).is_err());
            for projected in [false, true] {
                let mut s = configured();
                if projected {
                    let model = crate::soil_fem::inspect(&s).unwrap();
                    let mut saved = model["configuration"].clone();
                    saved["ground"]["materials"][0]["mcc"] = json!({});
                    saved["stages"]["schema"] = json!("soil-fem-projected-mcc-stages/1");
                    saved["stages"]["settings"] = json!({"kinematics":"side_rollers"});
                    s.execute(
                        "analysis.soil.configure",
                        &json!({"ground":saved["ground"],"stages":saved["stages"],
                        "bindings":[{"analysis_body":saved["bindings"][0]["analysis_body"],"cad_body":saved["bindings"][0]["cad_body"]}],
                        "expected_cad_sha256":model["cad_sha256"],"expected_setup_sha256":model["setup_sha256"]}),
                    )
                    .unwrap();
                }
                let root = folder();
                owned(&mut s, root.clone());
                assert_eq!(
                    s.soil_jobs.job.as_ref().unwrap().view_schema,
                    if projected { "soil-fem-solidcraft-view/2" } else { "soil-fem-solidcraft-view/1" }
                );
                receipt(&s);
                finish(&mut s);
                assert_eq!(s.execute("analysis.soil.job.status", &json!({})).unwrap()["result_usable"], true);
                let manifest_path = root.join("job/workflow/view/view-manifest.json");
                let audit_path = root.join("job/workflow/view-verification.json");
                let status_path = root.join("job/status.json");
                let mut manifest = read(&manifest_path).unwrap();
                manifest["schema"] = json!(if projected { "soil-fem-solidcraft-view/1" } else { "soil-fem-solidcraft-view/2" });
                write(&manifest_path, &manifest);
                let digest = hash(&manifest_path).unwrap();
                let mut audit = read(&audit_path).unwrap();
                audit["view_manifest_sha256"] = json!(digest);
                write(&audit_path, &audit);
                let mut status = read(&status_path).unwrap();
                status["result_sha256"] = json!(digest);
                status["view_audit_sha256"] = json!(hash(&audit_path).unwrap());
                write(&status_path, &status);
                let rejected = s.execute("analysis.soil.job.status", &json!({})).unwrap();
                assert_eq!(rejected["state"], "failed");
                assert_eq!(rejected["result_usable"], false);
                assert!(rejected["observation_error"].as_str().unwrap().contains("version differs"));
            }
        }

        #[test]
        fn process_handle_is_authoritative_and_status_identity_is_checked() {
            let mut s = configured();
            let root = folder();
            owned(&mut s, root.clone());
            let waiting = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(waiting["process_alive"], true);
            assert!(waiting["worker_report"].is_null());
            assert!(waiting["observation_error"].is_null(), "a live worker may not have written its first report yet");
            receipt(&s);
            let before = s.doc.to_json();
            let undo = s.undo.len();
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(v["state"], "running");
            assert_eq!(v["result_usable"], false);
            assert!(v["result"].is_null());
            assert_eq!(s.doc.to_json(), before);
            assert_eq!(s.undo.len(), undo);
            let path = root.join("job/status.json");
            let mut report = read(&path).unwrap();
            report["host_token"] = json!("foreign-host");
            write(&path, &report);
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert!(v["observation_error"].as_str().unwrap().contains("owned job"));
            assert!(s.execute("analysis.soil.job.cancel", &json!({"job":"foreign"})).is_err());
            let v = s.execute("analysis.soil.job.cancel", &json!({"job":"owned-token"})).unwrap();
            assert_eq!(v["cancel_requested"], true);
            finish(&mut s);
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(v["state"], "failed");
            assert_eq!(v["result_usable"], false);
        }

        #[test]
        fn completion_requires_matching_artifacts_and_cad_edits_invalidate_results() {
            let mut s = configured();
            let root = folder();
            owned(&mut s, root.clone());
            receipt(&s);
            finish(&mut s);
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(v["state"], "succeeded", "{v}");
            assert_eq!(v["result_usable"], true);
            let original = s.model.state().bodies.first().unwrap().name.clone();
            s.execute("body.rename", &json!({"body":original,"name":"changed"})).unwrap();
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(v["stale"], true);
            assert_eq!(v["result_usable"], false);
            s.execute("edit.undo", &json!({})).unwrap();
            assert_eq!(s.execute("analysis.soil.job.status", &json!({})).unwrap()["result_usable"], true);
            write(&root.join("job/workflow/view/view-manifest.json"), &json!({"complete":true,"input_sha256":"foreign"}));
            let v = s.execute("analysis.soil.job.status", &json!({})).unwrap();
            assert_eq!(v["state"], "failed");
            assert_eq!(v["result_usable"], false);
        }

        #[test]
        fn replacing_design_retains_owned_job_but_never_adopts_a_scratch_job() {
            let mut s = configured();
            owned(&mut s, folder());
            receipt(&s);
            let doc = s.doc.to_json();
            let mut computed = s.scratch();
            assert!(computed.soil_jobs.job.is_none());
            computed.doc_mut().name = "computed edit".into();
            s.accept_computed(computed);
            assert!(s.soil_jobs.job.is_some());
            s.replace_design(Session::default());
            assert!(s.soil_jobs.job.is_some());
            assert_ne!(s.doc.to_json(), doc);
            assert_eq!(s.execute("analysis.soil.job.status", &json!({})).unwrap()["stale"], true);
            finish(&mut s);
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
pub(crate) use native::Jobs;
#[cfg(target_arch = "wasm32")]
#[derive(Default)]
pub(crate) struct Jobs;

pub fn start(s: &mut Session, params: &Value) -> Result<Value> {
    let request: Start = serde_json::from_value(params.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    if request.directory.is_empty()
        || request.directory.len() > 4096
        || !request.mesh_size_m.is_finite()
        || request.mesh_size_m <= 0.
        || !matches!(request.element_order, 1 | 2)
        || !matches!(request.quadrature_order, 3..=5)
    {
        return Err(bad(CMD, "invalid output directory or mesh settings"));
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        let host = s
            .soil_jobs
            .host()
            .cloned()
            .ok_or_else(|| bad(CMD, "FEM host is unavailable; set SOLIDCRAFT_SOIL_FEM_ROOT before starting the native app"))?;
        if s.soil_jobs.busy()? {
            return Err(bad(CMD, "an FEM job is already running in this session"));
        }
        let frozen = crate::soil_fem::snapshot(s, &Value::Null)?;
        if frozen.get("input_sha256").and_then(Value::as_str) != Some(&request.expected_input_sha256) {
            return Err(bad(CMD, "analysis inputs changed before job start"));
        }
        let view_schema = expected_view_schema(&frozen)?;
        if frozen.pointer("/snapshot/stages/schema").and_then(Value::as_str) == Some("soil-fem-projected-mcc-stages/1") && request.element_order != 2
        {
            return Err(bad(CMD, "projected MCC requires Tet10 (element order 2)"));
        }
        solidcraft_io::vfs::check(&request.directory).map_err(|e| bad(CMD, e.to_string()))?;
        std::fs::create_dir(&request.directory).map_err(|e| bad(CMD, format!("new job folder required: {e}")))?;
        let capture = std::path::Path::new(&request.directory).join("capture");
        crate::soil_fem::export(s, &json!({"directory":capture,"expected_input_sha256":request.expected_input_sha256}))?;
        s.soil_jobs.start(host, &request, request.expected_input_sha256.clone(), view_schema)?;
        status(s, &json!({}))
    }
    #[cfg(target_arch = "wasm32")]
    {
        let _ = (s, request.expected_input_sha256);
        Err(bad(CMD, "external FEM jobs require the native desktop application"))
    }
}

pub fn status(s: &mut Session, params: &Value) -> Result<Value> {
    if params.as_object().is_none_or(|p| !p.is_empty()) {
        return Err(bad(CMD, "status takes an empty object"));
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        let mut value = s.soil_jobs.status()?;
        if let Some(input) = value.get("input_sha256").and_then(Value::as_str).map(str::to_string) {
            let current = crate::soil_fem::snapshot(s, &Value::Null);
            let sha = current.as_ref().ok().and_then(|v| v.get("input_sha256")).and_then(Value::as_str);
            let stale = sha != Some(&input);
            value["current_input_sha256"] = json!(sha);
            value["stale"] = json!(stale);
            value["result_usable"] = json!(!stale && value.get("state").and_then(Value::as_str) == Some("succeeded"));
            value["resume_usable"] = json!(!stale && value.get("resume_available") == Some(&Value::Bool(true)));
            value["current_input_error"] = json!(current.err().map(|e| e.to_string()));
        }
        Ok(value)
    }
    #[cfg(target_arch = "wasm32")]
    {
        let _ = s;
        Ok(json!({"state":"unavailable","host_available":false}))
    }
}

pub fn resume(s: &mut Session, params: &Value) -> Result<Value> {
    let request: Resume = serde_json::from_value(params.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    if request.directory.is_empty()
        || request.directory.len() > 4096
        || request.previous_directory.is_empty()
        || request.previous_directory.len() > 4096
    {
        return Err(bad(CMD, "new output and saved job folders are required"));
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        let host = s.soil_jobs.host().cloned().ok_or_else(|| bad(CMD, "FEM host is unavailable"))?;
        if s.soil_jobs.busy()? {
            return Err(bad(CMD, "an FEM job is already running in this session"));
        }
        let frozen = crate::soil_fem::snapshot(s, &Value::Null)?;
        if frozen.get("input_sha256").and_then(Value::as_str) != Some(&request.expected_input_sha256) {
            return Err(bad(CMD, "analysis inputs changed before job resume"));
        }
        let view_schema = expected_view_schema(&frozen)?;
        solidcraft_io::vfs::check(&request.previous_directory).map_err(|e| bad(CMD, e.to_string()))?;
        let previous = std::path::Path::new(&request.previous_directory);
        let saved = previous.join("job");
        let report = native::read(&saved.join("status.json"))?;
        native::saved_checkpoint(&saved, &request.expected_input_sha256, &report)?;
        solidcraft_io::vfs::check(&request.directory).map_err(|e| bad(CMD, e.to_string()))?;
        std::fs::create_dir(&request.directory).map_err(|e| bad(CMD, format!("new resume folder required: {e}")))?;
        s.soil_jobs.resume(host, std::path::Path::new(&request.directory), previous, request.expected_input_sha256, view_schema)?;
        status(s, &json!({}))
    }
    #[cfg(target_arch = "wasm32")]
    {
        let _ = (s, request.expected_input_sha256);
        Err(bad(CMD, "external FEM jobs require the native desktop application"))
    }
}

pub fn cancel(s: &mut Session, params: &Value) -> Result<Value> {
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Cancel {
        job: String,
    }
    let request: Cancel = serde_json::from_value(params.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    if request.job.is_empty() || request.job.len() > 128 {
        return Err(bad(CMD, "invalid job identity"));
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        s.soil_jobs.cancel(&request.job)?;
        status(s, &json!({}))
    }
    #[cfg(target_arch = "wasm32")]
    {
        let _ = s;
        Err(bad(CMD, "external FEM jobs require the native desktop application"))
    }
}
