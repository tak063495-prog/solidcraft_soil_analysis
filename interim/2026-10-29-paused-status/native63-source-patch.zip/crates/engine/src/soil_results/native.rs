use super::geometry;
use crate::{
    Result, Session,
    geom::{Aabb3, Vec3},
    params::bad,
};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Component, Path, PathBuf},
    sync::Arc,
};

const CMD: &str = "analysis.soil.results";
const MAX_FILE: usize = 256 << 20;
const MAX_TOTAL: u64 = 512 << 20;
// Authoritative histories are streamed; display packet/file budgets stay fixed.
const MAX_SOURCE_RESULT: usize = 1 << 30;
// Conservative DOM accounting includes collection/key overhead, independently
// of the unchanged256MiB encoded display-file and512MiB packet caps.
const MAX_RETAINED_SOURCE: usize = 512 << 20;
const MAX_NODES: usize = 1_000_000;
const MAX_CELLS: usize = 300_000;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Quantity {
    VerticalDisplacement,
    DisplacementMagnitude,
    EffectiveStressZz,
    MeanEffectiveStress,
    MajorEffectiveStress,
    PrimaryMeanEffectiveStress,
    WorkEffectiveStressZz,
    MaterialVolumeStrain,
    KinematicVolumeStrain,
    VoidRatio,
    PreconsolidationPressure,
    VolumetricPlasticStrain,
    BeamAxialForce,
    BeamMomentY,
    BeamMomentZ,
    PlateMembraneXx,
    PlateMembraneYy,
    PlateMembraneXy,
    PlateBendingXx,
    PlateBendingYy,
    PlateBendingXy,
}
impl Quantity {
    pub fn unit(&self) -> &'static str {
        match self {
            Self::VerticalDisplacement | Self::DisplacementMagnitude => "mm",
            Self::VoidRatio | Self::VolumetricPlasticStrain | Self::MaterialVolumeStrain | Self::KinematicVolumeStrain => "1",
            Self::BeamAxialForce => "kN",
            Self::BeamMomentY | Self::BeamMomentZ => "kN m",
            Self::PlateMembraneXx | Self::PlateMembraneYy | Self::PlateMembraneXy => "kN/m",
            Self::PlateBendingXx | Self::PlateBendingYy | Self::PlateBendingXy => "kN m/m",
            _ => "kPa",
        }
    }
    pub fn nodal(&self) -> bool {
        matches!(self, Self::VerticalDisplacement | Self::DisplacementMagnitude)
    }
    pub fn primary(&self) -> bool {
        matches!(self, Self::PrimaryMeanEffectiveStress | Self::MaterialVolumeStrain)
    }
    pub fn structural(&self) -> bool {
        matches!(
            self,
            Self::BeamAxialForce
                | Self::BeamMomentY
                | Self::BeamMomentZ
                | Self::PlateMembraneXx
                | Self::PlateMembraneYy
                | Self::PlateMembraneXy
                | Self::PlateBendingXx
                | Self::PlateBendingYy
                | Self::PlateBendingXy
        )
    }
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum DisplacementReference {
    Display,
    Stage,
    Seed,
}
impl DisplacementReference {
    pub fn field(&self) -> &'static str {
        match self {
            Self::Display => "displacement_m",
            Self::Stage => "stage_displacement_increment_m",
            Self::Seed => "total_displacement_from_seed_m",
        }
    }
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct Section {
    pub normal: [f64; 3],
    pub offset_m: f64,
    pub slice_only: bool,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct Settings {
    pub frame: usize,
    pub quantity: Quantity,
    pub displacement_reference: DisplacementReference,
    pub deformation_scale: f64,
    pub refinement: u8,
    pub section: Option<Section>,
    pub color_range: Option<[f64; 2]>,
    pub wireframe: bool,
    pub principal_directions: bool,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            frame: 0,
            quantity: Quantity::VerticalDisplacement,
            displacement_reference: DisplacementReference::Display,
            deformation_scale: 1.,
            refinement: 1,
            section: None,
            color_range: None,
            wireframe: false,
            principal_directions: false,
        }
    }
}
impl Settings {
    fn validate(&self) -> Result<()> {
        if !self.deformation_scale.is_finite() || !(0.0..=1e6).contains(&self.deformation_scale) || !(1..=3).contains(&self.refinement) {
            return Err(bad(CMD, "invalid deformation scale or display refinement (1..3)"));
        }
        if self.color_range.is_some_and(|r| !r.iter().all(|v| v.is_finite()) || r[0] >= r[1]) {
            return Err(bad(CMD, "color range must be finite and increasing"));
        }
        if let Some(s) = &self.section {
            let n = Vec3::from(s.normal);
            if !n.is_finite() || !s.offset_m.is_finite() || n.len() < 1e-12 || n.len() > 1e12 {
                return Err(bad(CMD, "invalid reference-coordinate section plane"));
            }
        }
        Ok(())
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Manifest {
    schema: String,
    complete: bool,
    pub input_sha256: String,
    cad_sha256: String,
    exporter_binary_sha256: String,
    solver_binary_sha256: String,
    geometry: String,
    pub frames: Vec<FrameEntry>,
    files_sha256: BTreeMap<String, String>,
    job_sources_sha256: BTreeMap<String, String>,
    semantics: Value,
    omissions: Vec<String>,
    scope: String,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FrameEntry {
    pub index: usize,
    pub name: String,
    pub frame: String,
    pub integration_points: String,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Geometry {
    schema: String,
    length_unit: String,
    axis: String,
    pub nodes_m: Vec<[f64; 3]>,
    pub cells: Vec<Vec<usize>>,
    cell_kind: String,
    regions: Value,
    pub node_sets: BTreeMap<String, Vec<usize>>,
    crs: String,
    origin_m: [f64; 3],
}
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Face {
    pub element_index: usize,
    pub nodes: Vec<usize>,
}
#[derive(Deserialize)]
pub(super) struct CellFields {
    pub effective_stress_compression_positive_kpa: Vec<[f64; 6]>,
    pub plastic_strain_compression_positive: Vec<[f64; 6]>,
    pub void_ratio: Vec<Option<f64>>,
    #[serde(default)]
    pub preconsolidation_pressure_kpa: Vec<Option<f64>>,
    pub material_id: Vec<u32>,
    pub region_id: Vec<i64>,
    pub material_model: Vec<u32>,
    #[serde(flatten)]
    pub(super) other: BTreeMap<String, Vec<Value>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Frame {
    pub(super) schema: String,
    pub index: usize,
    pub name: String,
    pub active_element_ids: Vec<usize>,
    pub active_node_ids: Vec<usize>,
    pub boundary_faces: Vec<Face>,
    pub node_fields: BTreeMap<String, Vec<[f64; 3]>>,
    pub cell_fields: CellFields,
    monitors: Value,
    relative_force_residual: f64,
    maximum_normalized_yield: f64,
    #[serde(default)]
    pub mixed_primary: Option<super::projected::Primary>,
    #[serde(default)]
    pub field_semantics: Value,
    #[serde(default)]
    pub mixed_equation_audit: Value,
    #[serde(default)]
    pub(super) structures: Option<super::structures::Fields>,
}
#[derive(Deserialize)]
pub(super) struct PointFields {
    effective_stress_compression_positive_kpa: Vec<[f64; 6]>,
    plastic_strain_compression_positive: Vec<[f64; 6]>,
    void_ratio: Vec<Option<f64>>,
    #[serde(default)]
    preconsolidation_pressure_kpa: Vec<Option<f64>>,
    material_model: Vec<u32>,
    material_id: Vec<u32>,
    #[serde(flatten)]
    pub(super) other: BTreeMap<String, Vec<Value>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Points {
    schema: String,
    frame_index: usize,
    pub(super) integration_point_ids: Vec<usize>,
    element_ids: Vec<usize>,
    positions_m: Vec<[f64; 3]>,
    weights_m3: Vec<f64>,
    pub(super) fields: PointFields,
}

#[derive(Clone, Copy, Debug)]
pub struct Vertex {
    pub position_mm: Vec3,
    pub scalar: Option<f64>,
}
#[derive(Clone, Debug)]
pub struct Triangle {
    pub vertices: [Vertex; 3],
    pub element_id: usize,
    pub section: bool,
}
#[derive(Clone, Debug)]
pub struct Glyph {
    pub a_mm: Vec3,
    pub b_mm: Vec3,
}
#[derive(Clone, Debug)]
pub struct MemberLine {
    pub a_mm: Vec3,
    pub b_mm: Vec3,
    pub scalar: f64,
    pub element_id: usize,
}
#[derive(Clone, Debug)]
pub struct Scene {
    pub key: String,
    pub triangles: Vec<Triangle>,
    pub glyphs: Vec<Glyph>,
    pub member_lines: Vec<MemberLine>,
    pub structural_hits: BTreeMap<usize, Value>,
    pub bounds: Aabb3,
    pub data_range: [f64; 2],
    pub color_range: [f64; 2],
    pub render_origin_m: Vec3,
    pub unavailable_cells: usize,
    pub reference_section_area_m2: f64,
    pub approximation: &'static str,
}
impl Scene {
    /// Availability is independent of a section hiding all active geometry.
    pub fn quantity_available(&self, quantity: &Quantity) -> bool {
        !quantity.structural() || !self.structural_hits.is_empty()
    }
    pub fn has_visible_geometry(&self) -> bool {
        !self.triangles.is_empty() || !self.member_lines.is_empty()
    }
}

struct Loaded {
    root: PathBuf,
    manifest: Arc<Manifest>,
    manifest_sha: String,
    geometry: Arc<Geometry>,
    frame: Arc<Frame>,
    source_run: Arc<Value>,
    source_mesh: Arc<Value>,
    layout: Arc<Vec<PointMeta>>,
    scene: Arc<Scene>,
    settings: Settings,
}

#[derive(Deserialize)]
pub(super) struct PointMeta {
    pub element_index: usize,
    pub position_m: [f64; 3],
    pub weight_m3: f64,
}
#[derive(Default)]
pub(crate) struct Results {
    loaded: Option<Arc<Loaded>>,
}

fn sha(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn is_sha(s: &str) -> bool {
    s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit())
}
fn safe_name(s: &str) -> bool {
    !s.is_empty() && s.len() <= 512 && !s.contains('\\') && !s.contains(':') && Path::new(s).components().all(|c| matches!(c, Component::Normal(_)))
}
fn read(root: &Path, name: &str, max: usize) -> Result<Vec<u8>> {
    if !safe_name(name) {
        return Err(bad(CMD, "invalid result-relative path"));
    }
    let path = root.join(name);
    solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
    let resolved = path.canonicalize().map_err(|e| bad(CMD, e.to_string()))?;
    let canonical_root = root.canonicalize().map_err(|e| bad(CMD, e.to_string()))?;
    if !resolved.starts_with(&canonical_root) {
        return Err(bad(CMD, "result path escapes its workflow folder"));
    }
    solidcraft_io::vfs::read(&path.to_string_lossy(), max).map_err(|e| bad(CMD, e.to_string()))
}
fn json_file<T: serde::de::DeserializeOwned>(root: &Path, name: &str, max: usize) -> Result<T> {
    serde_json::from_slice(&read(root, name, max)?).map_err(|e| bad(CMD, e.to_string()))
}
fn hashed<T: serde::de::DeserializeOwned>(root: &Path, name: &str, hashes: &BTreeMap<String, String>) -> Result<T> {
    let expected = hashes.get(name).filter(|s| is_sha(s)).ok_or_else(|| bad(CMD, "missing result-file fingerprint"))?;
    let bytes = read(root, &format!("view/{name}"), MAX_FILE)?;
    if sha(&bytes) != *expected {
        return Err(bad(CMD, format!("result file changed: {name}")));
    }
    serde_json::from_slice(&bytes).map_err(|e| bad(CMD, e.to_string()))
}
fn unique_sorted(ids: &[usize], cap: usize) -> bool {
    ids.len() <= cap && ids.windows(2).all(|p| p[0] < p[1])
}
fn validate_geometry(g: &Geometry) -> Result<()> {
    let n = g.nodes_m.len();
    let count = if g.cell_kind == "tetra10" {
        10
    } else if g.cell_kind == "tetra4" {
        4
    } else {
        0
    };
    if g.schema != "soil-fem-view-geometry/1"
        || g.length_unit != "m"
        || g.axis != "Z-up"
        || n == 0
        || n > MAX_NODES
        || g.cells.is_empty()
        || g.cells.len() > MAX_CELLS
        || count == 0
        || !g.origin_m.iter().all(|v| v.is_finite())
        || g.crs.is_empty()
        || g.crs.len() > 256
        || g.nodes_m.iter().flatten().any(|v| !v.is_finite() || v.abs() > 1e9)
        || g.cells.iter().any(|c| c.len() != count || c.iter().any(|i| *i >= n) || c.iter().collect::<BTreeSet<_>>().len() != count)
        || g.node_sets.len() > 256
        || g.node_sets.iter().any(|(name, ids)| name.len() > 256 || ids.len() > n || ids.iter().any(|i| *i >= n))
    {
        return Err(bad(CMD, "invalid or oversized prepared result geometry"));
    }
    Ok(())
}
fn validate_frame(g: &Geometry, f: &Frame, entry: &FrameEntry) -> Result<()> {
    let count = f.active_element_ids.len();
    let nodes = f.active_node_ids.len();
    let c = &f.cell_fields;
    if f.schema
        != if f.structures.is_some() {
            "soil-fem-view-frame/3"
        } else if f.mixed_primary.is_some() {
            "soil-fem-view-frame/2"
        } else {
            "soil-fem-view-frame/1"
        }
        || f.index != entry.index
        || f.name != entry.name
        || count == 0
        || !unique_sorted(&f.active_element_ids, g.cells.len())
        || !unique_sorted(&f.active_node_ids, g.nodes_m.len())
        || f.active_element_ids.iter().any(|i| *i >= g.cells.len())
        || f.active_node_ids.iter().any(|i| *i >= g.nodes_m.len())
        || !f.relative_force_residual.is_finite()
        || !f.maximum_normalized_yield.is_finite()
        || f.node_fields.len() != 4
        || ["displacement_m", "stage_displacement_increment_m", "total_displacement_from_seed_m", "display_reference_displacement_m"]
            .iter()
            .any(|name| f.node_fields.get(*name).is_none_or(|v| v.len() != nodes || v.iter().flatten().any(|x| !x.is_finite() || x.abs() > 1e100)))
        || [
            c.effective_stress_compression_positive_kpa.len(),
            c.plastic_strain_compression_positive.len(),
            c.void_ratio.len(),
            c.material_id.len(),
            c.region_id.len(),
            c.material_model.len(),
        ]
        .iter()
        .any(|n| *n != count)
        || (!c.preconsolidation_pressure_kpa.is_empty() && c.preconsolidation_pressure_kpa.len() != count)
        || c.other.len() > 32
        || c.other.iter().any(|(key, v)| {
            v.len() != count
                || (f.mixed_primary.is_none() && super::projected::tensor(key))
                || v.iter().any(|x| !super::projected::valid_extra(key, x))
        })
        || c.effective_stress_compression_positive_kpa
            .iter()
            .chain(&c.plastic_strain_compression_positive)
            .flatten()
            .any(|x| !x.is_finite() || x.abs() > 1e100)
        || c.void_ratio.iter().chain(&c.preconsolidation_pressure_kpa).flatten().any(|x| !x.is_finite())
    {
        return Err(bad(CMD, "invalid result frame fields or active identities"));
    }
    let mut used = BTreeSet::new();
    for id in &f.active_element_ids {
        if let Some(cell) = g.cells.get(*id) {
            used.extend(cell.iter().copied());
        }
    }
    if used.into_iter().collect::<Vec<_>>() != f.active_node_ids {
        return Err(bad(CMD, "active nodes differ from active element connectivity"));
    }
    geometry::check_boundary(g, f)
}

fn source_json(root: &Path, name: &str, m: &Manifest) -> Result<Value> {
    let bytes = read(root, name, MAX_FILE)?;
    if m.job_sources_sha256.get(name) != Some(&sha(&bytes)) {
        return Err(bad(CMD, "authoritative source changed during result loading"));
    }
    serde_json::from_slice(&bytes).map_err(|e| bad(CMD, e.to_string()))
}
fn source_run_for_frame(root: &Path, m: &Manifest, frame: usize) -> Result<Value> {
    let name = "analysis/stage-results.json";
    let path = root.join(name);
    solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
    let resolved = path.canonicalize().map_err(|e| bad(CMD, e.to_string()))?;
    let canonical_root = root.canonicalize().map_err(|e| bad(CMD, e.to_string()))?;
    if !resolved.starts_with(canonical_root) {
        return Err(bad(CMD, "result source escapes its workflow folder"));
    }
    let file = std::fs::File::open(resolved).map_err(|e| bad(CMD, e.to_string()))?;
    if file.metadata().map_err(|e| bad(CMD, e.to_string()))?.len() > MAX_SOURCE_RESULT as u64 {
        return Err(bad(CMD, "authoritative result exceeds source byte budget"));
    }
    let (value, digest) = super::source_stream::selected(file, frame, MAX_SOURCE_RESULT, MAX_RETAINED_SOURCE).map_err(|e| bad(CMD, e))?;
    if m.job_sources_sha256.get(name) != Some(&digest) {
        return Err(bad(CMD, "authoritative source changed during streamed result loading"));
    }
    Ok(value)
}
fn vector(value: Option<&Value>, id: usize) -> Result<Vec3> {
    let Some(value) = value else {
        return Ok(Vec3::ZERO);
    };
    let values: [f64; 3] =
        serde_json::from_value(value.get(id).cloned().ok_or_else(|| bad(CMD, "missing source vector"))?).map_err(|e| bad(CMD, e.to_string()))?;
    if values.iter().any(|x| !x.is_finite() || x.abs() > 1e100) {
        return Err(bad(CMD, "invalid source vector"));
    }
    Ok(Vec3::from(values))
}
fn present(value: Option<&Value>) -> Option<&Value> {
    value.filter(|v| v.as_array().is_some_and(|a| !a.is_empty()))
}
pub(super) fn close_number(a: f64, b: f64, scale: f64) -> bool {
    a.is_finite() && b.is_finite() && (a - b).abs() <= 512. * f64::EPSILON * scale.max(a.abs() + b.abs()).max(1e-300)
}
fn source_state(run: &Value, index: usize) -> Result<&Value> {
    run.get("frames").and_then(|f| f.get(index)).and_then(|f| f.get("state")).ok_or_else(|| bad(CMD, "missing authoritative source frame"))
}
fn source_layout(g: &Geometry, run: &Value) -> Result<Vec<PointMeta>> {
    let layout = if let Some(layout) = run.get("integration_points").filter(|v| !v.is_null()) {
        serde_json::from_value::<Vec<PointMeta>>(layout.clone()).map_err(|e| bad(CMD, e.to_string()))?
    } else {
        if run.get("schema").and_then(Value::as_str) != Some("soil-fem-stage-result/1") || g.cell_kind != "tetra4" {
            return Err(bad(CMD, "source integration layout is missing"));
        }
        let mut points = Vec::new();
        for (element, cell) in g.cells.iter().enumerate() {
            let p: Vec<_> = cell
                .iter()
                .map(|id| g.nodes_m.get(*id).copied().map(Vec3::from).ok_or_else(|| bad(CMD, "missing cell corner")))
                .collect::<Result<_>>()?;
            let [a, b, c, d]: [Vec3; 4] = p.try_into().map_err(|_| bad(CMD, "legacy cell arity"))?;
            points.push(PointMeta {
                element_index: element,
                position_m: ((a + b + c + d) * 0.25).into(),
                weight_m3: (b - a).dot((c - a).cross(d - a)) / 6.,
            });
        }
        points
    };
    if layout.is_empty()
        || layout.len() > 5_000_000
        || layout.iter().any(|p| {
            p.element_index >= g.cells.len()
                || !p.weight_m3.is_finite()
                || p.weight_m3 <= 0.
                || p.weight_m3 > 1e100
                || p.position_m.iter().any(|x| !x.is_finite())
        })
    {
        return Err(bad(CMD, "invalid source integration layout"));
    }
    Ok(layout)
}
fn model_code(state: &Value) -> u32 {
    if state.get("preconsolidation_pressure_kpa").is_some() {
        0
    } else if state.get("cap_pressure_kpa").is_some() {
        2
    } else {
        1
    }
}
fn mean_field(states: &[Value], layout: &[PointMeta], ids: &[usize], key: &str, component: Option<usize>) -> Result<Option<f64>> {
    let mut sum = 0.;
    let mut total = 0.;
    for id in ids {
        let p = layout.get(*id).ok_or_else(|| bad(CMD, "source point id out of range"))?;
        let value = states.get(*id).and_then(|s| s.get(key));
        let value = component.map_or(value, |c| value.and_then(|v| v.get(c)));
        let Some(value) = value.and_then(Value::as_f64) else {
            return Ok(None);
        };
        if !value.is_finite() || value.abs() > 1e100 {
            return Err(bad(CMD, "invalid source material field"));
        }
        sum += p.weight_m3 * value;
        total += p.weight_m3;
    }
    if !sum.is_finite() || !total.is_finite() || total <= 0. {
        return Err(bad(CMD, "invalid source cell integration weights"));
    }
    Ok(Some(sum / total))
}
fn validate_against_source(g: &Geometry, f: &Frame, run: &Value, mesh: &Value, layout: &[PointMeta]) -> Result<()> {
    super::projected::validate(g, f, run, mesh, layout)?;
    super::structures::validate(g, f, run, mesh)?;
    let state = source_state(run, f.index)?;
    let mask = state
        .get("active_elements")
        .and_then(Value::as_array)
        .filter(|a| a.len() == g.cells.len())
        .ok_or_else(|| bad(CMD, "missing source active mask"))?;
    let active: Vec<_> = mask.iter().enumerate().filter_map(|(i, v)| (v.as_bool() == Some(true)).then_some(i)).collect();
    if mask.iter().any(|v| !v.is_boolean()) || active != f.active_element_ids {
        return Err(bad(CMD, "display active mask differs from authoritative run"));
    }
    let source_frame = run.get("frames").and_then(|v| v.get(f.index)).ok_or_else(|| bad(CMD, "missing source frame"))?;
    if source_frame.get("name").and_then(Value::as_str) != Some(&f.name) {
        return Err(bad(CMD, "display frame name differs from authoritative run"));
    }
    let u = state
        .get("displacement_m")
        .filter(|v| v.as_array().is_some_and(|a| a.len() == g.nodes_m.len()))
        .ok_or_else(|| bad(CMD, "source displacement count differs from mesh"))?;
    let reference = present(state.get("display_reference_displacement_m")).or(present(run.get("reference_displacement_m")));
    let previous = if f.index > 0 && run.pointer(&format!("/case/stages/{}/kind", f.index - 1)).and_then(Value::as_str) == Some("birth") {
        run.get("transition_audits")
            .and_then(Value::as_array)
            .and_then(|a| a.iter().find(|a| a.get("stage").and_then(Value::as_str) == Some(&f.name)))
            .and_then(|a| a.pointer("/prepared_state/displacement_m"))
            .ok_or_else(|| bad(CMD, "missing BIRTH prepared displacement reference"))?
    } else {
        source_state(run, f.index.saturating_sub(1))?.get("displacement_m").ok_or_else(|| bad(CMD, "missing previous source displacement"))?
    };
    for (row, id) in f.active_node_ids.iter().enumerate() {
        let value = vector(Some(u), *id)?;
        let reference = vector(reference, *id)?;
        let previous = vector(Some(previous), *id)?;
        for (name, expected) in [
            ("displacement_m", value - reference),
            ("total_displacement_from_seed_m", value),
            ("stage_displacement_increment_m", value - previous),
            ("display_reference_displacement_m", reference),
        ] {
            let actual =
                f.node_fields.get(name).and_then(|a| a.get(row)).copied().map(Vec3::from).ok_or_else(|| bad(CMD, "missing display vector"))?;
            if !close_number((actual - expected).len(), 0., value.len() + reference.len() + previous.len()) {
                return Err(bad(CMD, format!("display {name} differs from authoritative nodal values")));
            }
        }
    }
    let states = state
        .get("material_states")
        .and_then(Value::as_array)
        .filter(|a| a.len() == layout.len())
        .ok_or_else(|| bad(CMD, "source material history length mismatch"))?;
    let mut groups = vec![Vec::new(); g.cells.len()];
    for (id, p) in layout.iter().enumerate() {
        if let Some(v) = groups.get_mut(p.element_index) {
            v.push(id);
        }
    }
    let materials = present(state.get("element_material_ids")).or(mesh.get("material_ids")).ok_or_else(|| bad(CMD, "source material ids missing"))?;
    for (row, element) in f.active_element_ids.iter().enumerate() {
        let ids = groups.get(*element).filter(|v| !v.is_empty()).ok_or_else(|| bad(CMD, "active cell has no source integration points"))?;
        let first = ids.first().and_then(|i| states.get(*i)).ok_or_else(|| bad(CMD, "missing cell material state"))?;
        let c = &f.cell_fields;
        if c.material_id.get(row).copied().map(u64::from) != materials.get(*element).and_then(Value::as_u64)
            || c.region_id.get(row).copied() != mesh.get("region_ids").and_then(|v| v.get(*element)).and_then(Value::as_i64)
            || c.material_model.get(row).copied() != Some(model_code(first))
            || ids.iter().any(|i| states.get(*i).is_none_or(|s| model_code(s) != model_code(first)))
        {
            return Err(bad(CMD, "display material identities differ from source"));
        }
        for (key, actual) in [
            ("effective_stress_compression_positive_kpa", c.effective_stress_compression_positive_kpa.get(row)),
            ("plastic_strain_compression_positive", c.plastic_strain_compression_positive.get(row)),
        ] {
            let actual = actual.ok_or_else(|| bad(CMD, "missing cell tensor"))?;
            for (component, value) in actual.iter().enumerate() {
                let expected = mean_field(states, layout, ids, key, Some(component))?.ok_or_else(|| bad(CMD, "missing source tensor component"))?;
                let scale = ids
                    .iter()
                    .filter_map(|i| states.get(*i).and_then(|s| s.get(key)).and_then(|v| v.get(component)).and_then(Value::as_f64))
                    .fold(0.0f64, |a, b| a.max(b.abs()));
                if !close_number(*value, expected, scale * ids.len() as f64) {
                    return Err(bad(CMD, "display cell mean differs from source integration points"));
                }
            }
        }
        for (key, actual) in [
            ("void_ratio", c.void_ratio.get(row).copied().flatten()),
            ("preconsolidation_pressure_kpa", c.preconsolidation_pressure_kpa.get(row).copied().flatten()),
        ]
        .into_iter()
        .chain(c.other.iter().map(|(key, values)| (key.as_str(), values.get(row).and_then(Value::as_f64))))
        {
            if super::projected::is_projected(run) && super::projected::derived(key) {
                continue;
            }
            let expected = mean_field(states, layout, ids, key, None)?;
            if actual.zip(expected).is_none_or(|(a, b)| !close_number(a, b, b.abs() * ids.len() as f64)) && !(actual.is_none() && expected.is_none())
            {
                return Err(bad(CMD, "display cell scalar differs from source integration points"));
            }
        }
    }
    Ok(())
}

fn load(path: &str, expected: &str) -> Result<Loaded> {
    if path.is_empty() || path.len() > 4096 {
        return Err(bad(CMD, "invalid result manifest path"));
    }
    solidcraft_io::vfs::check(path).map_err(|e| bad(CMD, e.to_string()))?;
    let supplied = Path::new(path);
    if supplied.file_name().and_then(|v| v.to_str()) != Some("view-manifest.json")
        || supplied.parent().and_then(Path::file_name).and_then(|v| v.to_str()) != Some("view")
    {
        return Err(bad(CMD, "select a workflow/view/view-manifest.json"));
    }
    let canonical = supplied
        .parent()
        .and_then(Path::parent)
        .ok_or_else(|| bad(CMD, "missing workflow folder"))?
        .canonicalize()
        .map_err(|e| bad(CMD, e.to_string()))?;
    let root = if cfg!(windows) {
        let text = canonical.to_str().ok_or_else(|| bad(CMD, "result paths must be Unicode"))?;
        if let Some(local) = text.strip_prefix(r"\\?\") {
            if local.as_bytes().get(1) != Some(&b':') {
                return Err(bad(CMD, "result workflows require a local drive"));
            }
            PathBuf::from(local)
        } else {
            canonical
        }
    } else {
        canonical
    };
    let bytes = read(&root, "view/view-manifest.json", 256 << 10)?;
    let manifest_sha = sha(&bytes);
    let m: Manifest = serde_json::from_slice(&bytes).map_err(|e| bad(CMD, e.to_string()))?;
    if !matches!(m.schema.as_str(), "soil-fem-solidcraft-view/1" | "soil-fem-solidcraft-view/2" | "soil-fem-solidcraft-view/3")
        || !m.complete
        || m.input_sha256 != expected
        || !is_sha(&m.cad_sha256)
        || !is_sha(&m.exporter_binary_sha256)
        || !is_sha(&m.solver_binary_sha256)
        || m.geometry != "geometry.json"
        || m.frames.is_empty()
        || m.frames.len() > 257
        || m.files_sha256.len() != 1 + 2 * m.frames.len()
        || m.job_sources_sha256.len() > 1024
        || m.semantics.get("length_unit").and_then(Value::as_str) != Some("m")
        || m.semantics.get("stress_unit").and_then(Value::as_str) != Some("kPa")
        || m.semantics.get("stress_sign").and_then(Value::as_str) != Some("compression positive")
        || m.semantics.get("stress_components") != Some(&json!(["xx", "yy", "zz", "xy", "yz", "xz"]))
    {
        return Err(bad(CMD, "incomplete, unsupported or different-input result manifest"));
    }
    let audit: Value = json_file(&root, "view-verification.json", 256 << 10)?;
    if audit.get("passed") != Some(&json!(true))
        || audit.get("input_sha256").and_then(Value::as_str) != Some(expected)
        || audit.get("view_manifest_sha256").and_then(Value::as_str) != Some(&manifest_sha)
    {
        return Err(bad(CMD, "view/VTU audit differs from the selected result"));
    }
    let accepted: Value = json_file(&root, "analysis/accepted-stage-run.json", 256 << 10)?;
    if accepted.get("schema").and_then(Value::as_str) != Some("soil-fem-accepted-staged-run/1")
        || accepted.get("solver_binary_sha256").and_then(Value::as_str) != Some(&m.solver_binary_sha256)
    {
        return Err(bad(CMD, "accepted mechanical run differs from the viewer result"));
    }
    let mut total = 0u64;
    let mut expected_names = BTreeSet::from(["geometry.json".to_string()]);
    for (i, e) in m.frames.iter().enumerate() {
        if e.index != i || e.frame != format!("frame-{i:03}.json") || e.integration_points != format!("points-{i:03}.json") || e.name.len() > 256 {
            return Err(bad(CMD, "invalid result frame inventory"));
        }
        expected_names.insert(e.frame.clone());
        expected_names.insert(e.integration_points.clone());
    }
    if expected_names != m.files_sha256.keys().cloned().collect() {
        return Err(bad(CMD, "result file inventory differs from frame list"));
    }
    for (name, digest) in &m.files_sha256 {
        if !is_sha(digest) {
            return Err(bad(CMD, "invalid result SHA256"));
        }
        let path = root.join("view").join(name);
        solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
        let meta = std::fs::metadata(&path).map_err(|e| bad(CMD, e.to_string()))?;
        if !meta.is_file() {
            return Err(bad(CMD, "result inventory contains a non-file"));
        }
        let length = meta.len();
        total = total.saturating_add(length);
        if length > MAX_FILE as u64 || total > MAX_TOTAL {
            return Err(bad(CMD, "result packet exceeds its file/total budget"));
        }
    }
    // Source paths are relative to this workflow only; absolute paths in historical
    // accepted-run receipts are never followed. Hash data, never execute files.
    for (name, digest) in &m.job_sources_sha256 {
        if !safe_name(name) || !is_sha(digest) {
            return Err(bad(CMD, "invalid workflow source inventory"));
        }
        // Hash this complete source during selected-frame parsing below. Do not
        // allocate the full history merely to verify its immutable fingerprint.
        if name == "analysis/stage-results.json" {
            continue;
        }
        let bytes = read(&root, name, MAX_FILE)?;
        if sha(&bytes) != *digest {
            return Err(bad(CMD, format!("workflow source changed: {name}")));
        }
    }
    for required in [
        "analysis/ground/mesh.json",
        "analysis/stage-results.json",
        "analysis/accepted-stage-run.json",
        "analysis/solver/soil-fem-3d.exe",
        "analysis/ground/snapshot-canonical.json",
        "analysis/ground/native-capture.json",
    ] {
        if !m.job_sources_sha256.contains_key(required) {
            return Err(bad(CMD, "missing authoritative workflow source"));
        }
    }
    let geometry: Geometry = hashed(&root, &m.geometry, &m.files_sha256)?;
    validate_geometry(&geometry)?;
    if m.job_sources_sha256.get("analysis/ground/snapshot-canonical.json") != Some(&m.input_sha256) {
        return Err(bad(CMD, "source input snapshot differs from the current CAD/input version"));
    }
    let snapshot = source_json(&root, "analysis/ground/snapshot-canonical.json", &m)?;
    let capture = source_json(&root, "analysis/ground/native-capture.json", &m)?;
    if snapshot.get("cad_sha256").and_then(Value::as_str) != Some(&m.cad_sha256)
        || capture.get("input_sha256").and_then(Value::as_str) != Some(&m.input_sha256)
        || capture.get("exporter_binary_sha256").and_then(Value::as_str) != Some(&m.exporter_binary_sha256)
    {
        return Err(bad(CMD, "native capture and CAD/input snapshot linkage differs"));
    }
    let source_mesh = source_json(&root, "analysis/ground/mesh.json", &m)?;
    let source_run = source_run_for_frame(&root, &m, 0)?;
    if !super::projected::is_projected(&source_run)
        && source_run
            .get("schema")
            .and_then(Value::as_str)
            .and_then(|s| s.strip_prefix("soil-fem-stage-result/"))
            .and_then(|s| s.parse::<u8>().ok())
            .is_none_or(|n| !(1..=14).contains(&n))
    {
        return Err(bad(CMD, "unsupported authoritative result schema"));
    }
    let mesh_nodes: Vec<[f64; 3]> = serde_json::from_value(source_mesh.get("nodes").cloned().ok_or_else(|| bad(CMD, "source mesh nodes missing"))?)
        .map_err(|e| bad(CMD, e.to_string()))?;
    let mesh_cells: Vec<Vec<usize>> = serde_json::from_value(
        present(source_mesh.get("tetrahedra10")).or(source_mesh.get("tetrahedra")).cloned().ok_or_else(|| bad(CMD, "source mesh cells missing"))?,
    )
    .map_err(|e| bad(CMD, e.to_string()))?;
    let source_sets: BTreeMap<String, Vec<usize>> =
        serde_json::from_value(source_mesh.get("node_sets").cloned().unwrap_or_else(|| json!({}))).map_err(|e| bad(CMD, e.to_string()))?;
    let source_origin: [f64; 3] =
        serde_json::from_value(source_mesh.get("origin_m").cloned().unwrap_or_else(|| json!([0., 0., 0.]))).map_err(|e| bad(CMD, e.to_string()))?;
    if geometry.nodes_m != mesh_nodes
        || geometry.cells != mesh_cells
        || geometry.node_sets != source_sets
        || Some(&geometry.regions) != source_mesh.get("regions")
        || Some(geometry.crs.as_str()) != source_mesh.get("crs").and_then(Value::as_str)
        || geometry.origin_m != source_origin
        || source_run.get("complete") != Some(&json!(true))
    {
        return Err(bad(CMD, "display geometry differs from authoritative prepared mesh"));
    }
    let structural = source_run.pointer("/case/beam_system").is_some_and(Value::is_object);
    let expected = if structural {
        "soil-fem-solidcraft-view/3"
    } else if super::projected::is_projected(&source_run) {
        "soil-fem-solidcraft-view/2"
    } else {
        "soil-fem-solidcraft-view/1"
    };
    if m.schema != expected || (structural && m.semantics.get("source_result_schema") != source_run.get("schema")) {
        return Err(bad(CMD, "display/source result family differs"));
    }
    let layout = source_layout(&geometry, &source_run)?;
    let first = m.frames.first().ok_or_else(|| bad(CMD, "no frames"))?;
    let frame: Frame = hashed(&root, &first.frame, &m.files_sha256)?;
    validate_frame(&geometry, &frame, first)?;
    validate_against_source(&geometry, &frame, &source_run, &source_mesh, &layout)?;
    let settings = Settings::default();
    let scene = Arc::new(geometry::build(&geometry, &frame, &settings, &manifest_sha)?);
    Ok(Loaded {
        root,
        manifest: Arc::new(m),
        manifest_sha,
        geometry: Arc::new(geometry),
        frame: Arc::new(frame),
        source_run: Arc::new(source_run),
        source_mesh: Arc::new(source_mesh),
        layout: Arc::new(layout),
        scene,
        settings,
    })
}

fn current(s: &mut Session, input: &str) -> Result<()> {
    let snap = crate::soil_fem::snapshot(s, &json!({}))?;
    if snap.get("input_sha256").and_then(Value::as_str) != Some(input) {
        return Err(bad(CMD, "CAD or analysis inputs changed; loaded result is stale"));
    }
    Ok(())
}
pub fn open(s: &mut Session, p: &Value) -> Result<Value> {
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Request {
        manifest: String,
        expected_input_sha256: String,
    }
    let request: Request = serde_json::from_value(p.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    current(s, &request.expected_input_sha256)?;
    let loaded = load(&request.manifest, &request.expected_input_sha256)?;
    current(s, &loaded.manifest.input_sha256)?;
    s.soil_results.loaded = Some(Arc::new(loaded));
    status(s, &json!({}))
}
pub fn configure(s: &mut Session, p: &Value) -> Result<Value> {
    let settings: Settings = serde_json::from_value(p.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    settings.validate()?;
    let loaded = s.soil_results.loaded.clone().ok_or_else(|| bad(CMD, "no loaded soil results"))?;
    current(s, &loaded.manifest.input_sha256)?;
    let entry = loaded.manifest.frames.get(settings.frame).ok_or_else(|| bad(CMD, "frame index out of range"))?;
    let source_run = if settings.frame == loaded.settings.frame {
        loaded.source_run.clone()
    } else {
        Arc::new(source_run_for_frame(&loaded.root, &loaded.manifest, settings.frame)?)
    };
    let frame = if settings.frame == loaded.settings.frame {
        loaded.frame.clone()
    } else {
        let frame: Frame = hashed(&loaded.root, &entry.frame, &loaded.manifest.files_sha256)?;
        validate_frame(&loaded.geometry, &frame, entry)?;
        validate_against_source(&loaded.geometry, &frame, &source_run, &loaded.source_mesh, &loaded.layout)?;
        Arc::new(frame)
    };
    let scene = Arc::new(geometry::build(&loaded.geometry, &frame, &settings, &loaded.manifest_sha)?);
    // Replace only after validation succeeds; geometry remains immutable/shared.
    s.soil_results.loaded = Some(Arc::new(Loaded {
        root: loaded.root.clone(),
        manifest: loaded.manifest.clone(),
        manifest_sha: loaded.manifest_sha.clone(),
        geometry: loaded.geometry.clone(),
        source_run,
        source_mesh: loaded.source_mesh.clone(),
        layout: loaded.layout.clone(),
        frame,
        scene,
        settings,
    }));
    status(s, &json!({}))
}
pub fn status(s: &mut Session, p: &Value) -> Result<Value> {
    if p.as_object().is_none_or(|m| !m.is_empty()) {
        return Err(bad(CMD, "status takes an empty object"));
    }
    let Some(loaded) = s.soil_results.loaded.clone() else {
        return Ok(json!({"loaded":false}));
    };
    let applicability = current(s, &loaded.manifest.input_sha256);
    let scene = &loaded.scene;
    let quantity_available = scene.quantity_available(&loaded.settings.quantity);
    let mut value = json!({"loaded":true,"stale":applicability.is_err(),"input_error":applicability.err().map(|e|e.to_string()),
        "input_sha256":loaded.manifest.input_sha256,"manifest_sha256":loaded.manifest_sha,"frames":loaded.manifest.frames,"settings":loaded.settings,
        "frame_name":loaded.frame.name,"node_count":loaded.geometry.nodes_m.len(),"active_nodes":loaded.frame.active_node_ids.len(),"active_elements":loaded.frame.active_element_ids.len(),
        "triangles":scene.triangles.len(),"section_triangles":scene.triangles.iter().filter(|t|t.section).count(),"glyphs":scene.glyphs.len(),
        "member_display_segments":scene.member_lines.len(),
        "structural_nodes":loaded.frame.structures.as_ref().map(|d|d.nodes.ids.len()),
        "defined_beams":loaded.frame.structures.as_ref().map(|d|d.members.len()),
        "defined_plates":loaded.frame.structures.as_ref().map(|d|d.plates.len()),
        "active_beams":loaded.frame.structures.as_ref().map(|d|d.members.iter().filter(|m|m.active).count()),
        "active_plates":loaded.frame.structures.as_ref().map(|d|d.plates.iter().filter(|m|m.active).count()),
        "reference_section_area_m2":scene.reference_section_area_m2,
        "data_range":quantity_available.then_some(scene.data_range),"color_range":quantity_available.then_some(scene.color_range),"unit":loaded.settings.quantity.unit(),"unavailable_cells":scene.unavailable_cells,
        "bounds_mm":if scene.bounds.is_empty(){None}else{Some(scene.bounds)},"render_origin_m":scene.render_origin_m,"crs":loaded.geometry.crs,"origin_m":loaded.geometry.origin_m,
        "region_count":loaded.geometry.regions.as_array().map(Vec::len),"monitor_count":loaded.frame.monitors.as_object().map(|m|m.len()),"export_scope":loaded.manifest.scope,
        "quantity_location":if loaded.settings.quantity.structural(){"beam sections in local axes; raw plate DKT samples on equal-area regions; no cross-member averaging"}else if loaded.settings.quantity.primary(){"P1 interpolation of material-split corner values; no cross-material averaging"}else if loaded.settings.quantity.nodal(){"quadratic/linear interpolation of stored nodal values"}else{"constant per original cell; integration-weighted mean; no nodal smoothing"},
        "result_family":loaded.source_run.get("schema"),"field_semantics":loaded.frame.field_semantics,"primary_rows":loaded.frame.mixed_primary.as_ref().map(|p|p.original_node_ids.len()),
        "section_coordinates":"reference mesh in m; deformation applied after section intersection","approximation":scene.approximation,
        "relative_force_residual":loaded.frame.relative_force_residual,"maximum_normalized_yield":loaded.frame.maximum_normalized_yield,
        "omissions":loaded.manifest.omissions});
    value["quantity_available"] = json!(quantity_available);
    Ok(value)
}
pub fn close(s: &mut Session, p: &Value) -> Result<Value> {
    if p.as_object().is_none_or(|m| !m.is_empty()) {
        return Err(bad(CMD, "close takes an empty object"));
    }
    s.soil_results.loaded = None;
    Ok(json!({"loaded":false}))
}

impl Session {
    pub fn soil_result_scene(&mut self) -> Result<Option<Arc<Scene>>> {
        let Some(loaded) = self.soil_results.loaded.clone() else {
            return Ok(None);
        };
        current(self, &loaded.manifest.input_sha256)?;
        Ok(Some(loaded.scene.clone()))
    }
    pub fn soil_result_settings(&self) -> Option<Settings> {
        self.soil_results.loaded.as_ref().map(|l| l.settings.clone())
    }
}

fn contextual(l: &Loaded, mut value: Value) -> Value {
    if let Some(fields) = value.as_object_mut() {
        fields.insert("frame_index".into(), json!(l.settings.frame));
        fields.insert("frame_name".into(), json!(l.frame.name));
        fields.insert("input_sha256".into(), json!(l.manifest.input_sha256));
        fields.insert("manifest_sha256".into(), json!(l.manifest_sha));
        fields.insert("deformation_scale".into(), json!(l.settings.deformation_scale));
        fields.insert("displacement_reference".into(), json!(l.settings.displacement_reference));
    }
    value
}

pub fn query(s: &mut Session, p: &Value) -> Result<Value> {
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Request {
        node: Option<usize>,
        element: Option<usize>,
        integration_point: Option<usize>,
        primary_node: Option<usize>,
        primary_material: Option<u32>,
        structural_node: Option<usize>,
        beam: Option<usize>,
        plate: Option<usize>,
        ray_origin_mm: Option<[f64; 3]>,
        ray_direction: Option<[f64; 3]>,
    }
    let q: Request = serde_json::from_value(p.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    let l = s.soil_results.loaded.clone().ok_or_else(|| bad(CMD, "no loaded soil results"))?;
    current(s, &l.manifest.input_sha256)?;
    let choices = usize::from(q.node.is_some())
        + usize::from(q.element.is_some())
        + usize::from(q.integration_point.is_some())
        + usize::from(q.primary_node.is_some() || q.primary_material.is_some())
        + usize::from(q.structural_node.is_some())
        + usize::from(q.beam.is_some())
        + usize::from(q.plate.is_some())
        + usize::from(q.ray_origin_mm.is_some() || q.ray_direction.is_some());
    if choices != 1 {
        return Err(bad(CMD, "choose exactly one node, element, integration point or complete ray"));
    }
    if q.structural_node.is_some() || q.beam.is_some() || q.plate.is_some() {
        let data = l.frame.structures.as_ref().ok_or_else(|| bad(CMD, "this frame has no structural result data"))?;
        if let Some(index) = q.structural_node {
            let id = data.nodes.ids.get(index).ok_or_else(|| bad(CMD, "structural node index is outside the model"))?;
            return Ok(contextual(
                &l,
                json!({"structural_node":index,"id":id,"position_m":data.nodes.positions_m.get(index),
                "displacement_from_cad_m":data.nodes.displacement_m.get(index),"rotation_rad":data.nodes.rotation_rad.get(index),
                "active":data.nodes.active.get(index),"soil_node":data.nodes.soil_node_ids.get(index),"semantics":data.semantics}),
            ));
        }
        let (family, index, entries) = if let Some(index) = q.beam {
            ("beam", index, &data.members)
        } else {
            ("plate", q.plate.ok_or_else(|| bad(CMD, "missing structural query index"))?, &data.plates)
        };
        let entry = entries.get(index).ok_or_else(|| bad(CMD, "structural member index is outside the model"))?;
        return Ok(contextual(
            &l,
            json!({"family":family,"index":index,"member":entry,"semantics":data.semantics,
            "location":"raw structural report in its own local axes; installation reference and inactive archived state retained"}),
        ));
    }
    if q.primary_node.is_some() || q.primary_material.is_some() {
        let node = q.primary_node.ok_or_else(|| bad(CMD, "primary node and material are both required"))?;
        let material = q.primary_material.ok_or_else(|| bad(CMD, "primary node and material are both required"))?;
        let primary = l.frame.mixed_primary.as_ref().ok_or_else(|| bad(CMD, "this result has no material-split primary field"))?;
        let row = primary
            .original_node_ids
            .iter()
            .zip(&primary.material_ids)
            .position(|(n, m)| *n == node && *m == material)
            .ok_or_else(|| bad(CMD, "primary pair is not active"))?;
        return Ok(contextual(
            &l,
            json!({"primary_node":node,"material_id":material,"position_m":primary.positions_m.get(row),
            "mean_effective_stress_compression_positive_kpa":primary.mean_effective_stress_compression_positive_kpa.get(row),
            "cumulative_material_volume_strain_compression_positive":primary.cumulative_material_volume_strain_compression_positive.get(row),
            "frozen_compatibility_offset_m3":primary.frozen_compatibility_offset_m3.get(row),"location":"stored material-split P1 primary row; no averaging"}),
        ));
    }
    if let Some(node) = q.node {
        let row = l.frame.active_node_ids.binary_search(&node).map_err(|_| bad(CMD, "node is not active in this frame"))?;
        let values: BTreeMap<_, _> = l.frame.node_fields.iter().map(|(k, v)| (k, v.get(row))).collect();
        return Ok(contextual(&l, json!({"node":node,"position_m":l.geometry.nodes_m.get(node),"stored_node_fields":values,"unit":"m"})));
    }
    if let Some(element) = q.element {
        let row = l.frame.active_element_ids.binary_search(&element).map_err(|_| bad(CMD, "element is not active in this frame"))?;
        let f = &l.frame.cell_fields;
        let stress = f.effective_stress_compression_positive_kpa.get(row).copied().ok_or_else(|| bad(CMD, "missing cell stress"))?;
        let principal = geometry::principal(stress);
        let mixed: BTreeMap<_, _> = f.other.iter().filter(|(k, _)| super::projected::derived(k)).map(|(k, v)| (k, v.get(row))).collect();
        return Ok(contextual(
            &l,
            json!({"element":element,"effective_stress_compression_positive_kpa":stress,"plastic_strain_compression_positive":f.plastic_strain_compression_positive.get(row),
            "void_ratio":f.void_ratio.get(row),"preconsolidation_pressure_kpa":f.preconsolidation_pressure_kpa.get(row),"material_id":f.material_id.get(row),"material_model":f.material_model.get(row),
            "principal_effective_stresses_kpa":principal.values,"major_axis":principal.axis,"mixed_fields":mixed,"location":"integration-weighted original-cell means; no nodal smoothing"}),
        ));
    }
    if let Some(id) = q.integration_point {
        let entry = l.manifest.frames.get(l.settings.frame).ok_or_else(|| bad(CMD, "missing frame"))?;
        let points: Points = hashed(&l.root, &entry.integration_points, &l.manifest.files_sha256)?;
        let count = points.integration_point_ids.len();
        let f = &points.fields;
        if points.schema
            != if l.frame.structures.is_some() {
                "soil-fem-view-integration-points/3"
            } else if super::projected::is_projected(&l.source_run) {
                "soil-fem-view-integration-points/2"
            } else {
                "soil-fem-view-integration-points/1"
            }
            || points.frame_index != l.settings.frame
            || !unique_sorted(&points.integration_point_ids, 5_000_000)
            || [
                points.element_ids.len(),
                points.positions_m.len(),
                points.weights_m3.len(),
                f.effective_stress_compression_positive_kpa.len(),
                f.plastic_strain_compression_positive.len(),
                f.void_ratio.len(),
                f.material_model.len(),
                f.material_id.len(),
            ]
            .iter()
            .any(|n| *n != count)
            || (!f.preconsolidation_pressure_kpa.is_empty() && f.preconsolidation_pressure_kpa.len() != count)
            || f.other.len() > 32
            || f.other.values().any(|v| v.len() != count)
            || points.positions_m.iter().flatten().any(|x| !x.is_finite())
            || points.weights_m3.iter().any(|x| !x.is_finite() || *x <= 0.)
            || points.element_ids.iter().any(|id| l.frame.active_element_ids.binary_search(id).is_err())
            || f.effective_stress_compression_positive_kpa.iter().chain(&f.plastic_strain_compression_positive).flatten().any(|v| !v.is_finite())
        {
            return Err(bad(CMD, "invalid raw integration-point fields"));
        }
        validate_points(&l, &points)?;
        let row = points.integration_point_ids.binary_search(&id).map_err(|_| bad(CMD, "integration point is not active in this frame"))?;
        let mixed: BTreeMap<_, _> = f.other.iter().filter(|(k, _)| super::projected::derived(k)).map(|(k, v)| (k, v.get(row))).collect();
        return Ok(contextual(
            &l,
            json!({"integration_point":id,"element":points.element_ids.get(row),"position_m":points.positions_m.get(row),"weight_m3":points.weights_m3.get(row),
            "effective_stress_compression_positive_kpa":f.effective_stress_compression_positive_kpa.get(row),"plastic_strain_compression_positive":f.plastic_strain_compression_positive.get(row),
            "void_ratio":f.void_ratio.get(row),"preconsolidation_pressure_kpa":f.preconsolidation_pressure_kpa.get(row),"material_id":f.material_id.get(row),"stored_model_code":f.material_model.get(row),"mixed_fields":mixed,"location":"raw stored integration point; no averaging"}),
        ));
    }
    let origin = Vec3::from(q.ray_origin_mm.ok_or_else(|| bad(CMD, "ray origin is required"))?);
    let direction = Vec3::from(q.ray_direction.ok_or_else(|| bad(CMD, "ray direction is required"))?);
    if !origin.is_finite() || !direction.is_finite() {
        return Err(bad(CMD, "non-finite ray"));
    }
    let direction = direction.normalized().ok_or_else(|| bad(CMD, "zero ray direction"))?;
    Ok(contextual(&l, geometry::pick(&l.scene, origin, direction)))
}

fn validate_points(l: &Loaded, p: &Points) -> Result<()> {
    super::projected::validate_points(&l.geometry, &l.frame, &l.source_run, &l.source_mesh, &l.layout, p)?;
    let expected: Vec<_> =
        l.layout.iter().enumerate().filter_map(|(id, m)| l.frame.active_element_ids.binary_search(&m.element_index).is_ok().then_some(id)).collect();
    if expected != p.integration_point_ids {
        return Err(bad(CMD, "raw point inventory differs from source integration layout"));
    }
    let state = source_state(&l.source_run, l.settings.frame)?;
    let states = state.get("material_states").and_then(Value::as_array).ok_or_else(|| bad(CMD, "missing authoritative material points"))?;
    let material_ids = present(state.get("element_material_ids"))
        .or(l.source_mesh.get("material_ids"))
        .ok_or_else(|| bad(CMD, "missing source material identities"))?;
    for (row, id) in p.integration_point_ids.iter().enumerate() {
        let meta = l.layout.get(*id).ok_or_else(|| bad(CMD, "point outside source layout"))?;
        let original = states.get(*id).ok_or_else(|| bad(CMD, "missing source material history"))?;
        let fields = &p.fields;
        let position = p.positions_m.get(row).copied().map(Vec3::from).ok_or_else(|| bad(CMD, "missing raw point position"))?;
        let expected = Vec3::from(meta.position_m);
        if p.element_ids.get(row).copied() != Some(meta.element_index)
            || !close_number(position.dist(expected), 0., expected.len())
            || p.weights_m3.get(row).is_none_or(|w| !close_number(*w, meta.weight_m3, meta.weight_m3))
            || fields.material_model.get(row).copied() != Some(model_code(original))
            || fields.material_id.get(row).copied().map(u64::from) != material_ids.get(meta.element_index).and_then(Value::as_u64)
        {
            return Err(bad(CMD, "raw point geometry/identity differs from authoritative source"));
        }
        for (key, actual) in [
            ("effective_stress_compression_positive_kpa", fields.effective_stress_compression_positive_kpa.get(row)),
            ("plastic_strain_compression_positive", fields.plastic_strain_compression_positive.get(row)),
        ] {
            let expected: [f64; 6] = serde_json::from_value(original.get(key).cloned().ok_or_else(|| bad(CMD, "missing source point tensor"))?)
                .map_err(|e| bad(CMD, e.to_string()))?;
            if actual.is_none_or(|v| v.iter().zip(expected).any(|(a, b)| !close_number(*a, b, b.abs()))) {
                return Err(bad(CMD, "raw point tensor differs from source"));
            }
        }
        for (key, actual) in [
            ("void_ratio", fields.void_ratio.get(row).copied().flatten()),
            ("preconsolidation_pressure_kpa", fields.preconsolidation_pressure_kpa.get(row).copied().flatten()),
        ]
        .into_iter()
        .chain(fields.other.iter().map(|(key, v)| (key.as_str(), v.get(row).and_then(Value::as_f64))))
        {
            if super::projected::is_projected(&l.source_run) && super::projected::derived(key) {
                continue;
            }
            let expected = original.get(key).and_then(Value::as_f64);
            if actual.zip(expected).is_none_or(|(a, b)| !close_number(a, b, b.abs())) && !(actual.is_none() && expected.is_none()) {
                return Err(bad(CMD, "raw point scalar differs from source"));
            }
        }
    }
    Ok(())
}

#[cfg(test)]
#[path = "tests.rs"]
mod tests;
