//! Synthetic protocol fixtures test reader invariants, not mechanical accuracy.
use super::*;
use std::sync::atomic::{AtomicU64, Ordering};

#[test]
fn projected_fields_reconstruct_tet10_strain_primary_pairs_and_linear_pressure_without_averaging() {
    let nodes = json!([
        [0., 0., 0.],
        [1., 0., 0.],
        [0., 1., 0.],
        [0., 0., 1.],
        [0.5, 0., 0.],
        [0.5, 0.5, 0.],
        [0., 0.5, 0.],
        [0., 0., 0.5],
        [0.5, 0., 0.5],
        [0., 0.5, 0.5]
    ]);
    let xyz: Vec<[f64; 3]> = serde_json::from_value(nodes.clone()).unwrap();
    let displacement: Vec<_> = xyz.iter().map(|p| [-0.01 * p[0], -0.02 * p[1], -0.03 * p[2]]).collect();
    let cell = json!([[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]);
    let g:Geometry=serde_json::from_value(json!({"schema":"soil-fem-view-geometry/1","length_unit":"m","axis":"Z-up","nodes_m":nodes,"cells":cell,"cell_kind":"tetra10","regions":[],"node_sets":{},"crs":"LOCAL","origin_m":[0.,0.,0.]})).unwrap();
    let pressure: Vec<_> = (0..4).map(|i| json!({"node_index":i,"material_id":1,"compression_positive_kpa":10.*(i+1) as f64})).collect();
    let volume: Vec<_> = (0..4).map(|i| json!({"node_index":i,"material_id":1,"compression_positive":0.01*(i+1) as f64})).collect();
    let offsets: Vec<_> = (0..4).map(|i| json!({"node_index":i,"material_id":1,"integral_m3":0.})).collect();
    let source = json!({"schema":"soil-fem-projected-mcc-stage-result/1","integration_points":[{"natural_coordinates":[0.25,0.25,0.25]}],"frames":[{"state":{
        "displacement_m":displacement,"material_states":[{"effective_stress_compression_positive_kpa":[25.,15.,20.,2.,3.,4.]}],
        "mixed_mcc":{"pressure_dofs":pressure,"cumulative_volume_strain_compression_positive":[0.025],"reference_void_ratio":[0.8],"last_increment_partitions":[1],
        "projected_volume":{"volume_dofs":volume,"compatibility_offsets":offsets}}}}]});
    let kinematic = [0.01, 0.02, 0.03, 0., 0., 0.];
    let material = [0.01 + (0.025 - 0.06) / 3., 0.02 + (0.025 - 0.06) / 3., 0.03 + (0.025 - 0.06) / 3., 0., 0., 0.];
    let fields = json!({"effective_stress_compression_positive_kpa":[[25.,15.,20.,2.,3.,4.]],"plastic_strain_compression_positive":vec![[0.;6]],"void_ratio":[0.8],"preconsolidation_pressure_kpa":[100.],"material_id":[1],"region_id":[1],"material_model":[0],
        "primary_mean_effective_stress_compression_positive_kpa":[25.],"material_mean_effective_stress_compression_positive_kpa":[20.],"cumulative_material_volume_strain_compression_positive":[0.025],"cumulative_kinematic_volume_strain_compression_positive":[0.06],"material_minus_kinematic_volume_strain":[-0.035],"reference_void_ratio":[0.8],"last_material_partition_count":[1],
        "work_conjugate_effective_stress_compression_positive_kpa":[[30.,20.,25.,2.,3.,4.]],"cumulative_material_engineering_strain_compression_positive":[material],"cumulative_kinematic_engineering_strain_compression_positive":[kinematic]});
    let value = json!({"schema":"soil-fem-view-frame/2","index":0,"name":"analytic transport fixture","active_element_ids":[0],"active_node_ids":(0..10).collect::<Vec<_>>(),
        "boundary_faces":[{"element_index":0,"nodes":[1,2,3,5,9,8]},{"element_index":0,"nodes":[0,3,2,7,9,6]},{"element_index":0,"nodes":[0,1,3,4,8,7]},{"element_index":0,"nodes":[0,2,1,6,5,4]}],
        "node_fields":{"displacement_m":displacement,"stage_displacement_increment_m":displacement,"total_displacement_from_seed_m":displacement,"display_reference_displacement_m":vec![[0.;3];10]},
        "cell_fields":fields,"monitors":{},"relative_force_residual":0.,"maximum_normalized_yield":0.,
        "mixed_primary":{"original_node_ids":[0,1,2,3],"material_ids":[1,1,1,1],"positions_m":xyz[..4],"mean_effective_stress_compression_positive_kpa":[10.,20.,30.,40.],"cumulative_material_volume_strain_compression_positive":[0.01,0.02,0.03,0.04],"frozen_compatibility_offset_m3":[0.,0.,0.,0.]},
        "field_semantics":{"equilibrium_stress":"work_conjugate_effective_stress_compression_positive_kpa"},"mixed_equation_audit":{}});
    let mut f: Frame = serde_json::from_value(value).unwrap();
    let layout = vec![PointMeta { element_index: 0, position_m: [0.25; 3], weight_m3: 1. / 6. }];
    let mesh = json!({"material_ids":[1]});
    super::super::projected::validate(&g, &f, &source, &mesh, &layout).unwrap();
    let scene = geometry::build(&g, &f, &Settings { quantity: Quantity::PrimaryMeanEffectiveStress, ..Default::default() }, "analytic").unwrap();
    assert_eq!(scene.data_range, [10., 40.]);
    assert_eq!(scene.unavailable_cells, 0);
    assert!(scene.triangles.iter().flat_map(|t| t.vertices.iter()).any(|v| v.scalar == Some(10.)));
    assert!(scene.triangles.iter().flat_map(|t| t.vertices.iter()).any(|v| v.scalar == Some(40.)));
    f.mixed_primary.as_mut().unwrap().mean_effective_stress_compression_positive_kpa[0] += 1.;
    assert!(super::super::projected::validate(&g, &f, &source, &mesh, &layout).is_err());
    f.mixed_primary.as_mut().unwrap().mean_effective_stress_compression_positive_kpa[0] -= 1.;
    f.cell_fields.other.get_mut("work_conjugate_effective_stress_compression_positive_kpa").unwrap()[0][0] = json!(100.);
    assert!(super::super::projected::validate(&g, &f, &source, &mesh, &layout).is_err());
}

fn write(root: &Path, name: &str, value: &Value) -> String {
    let path = root.join(name);
    std::fs::create_dir_all(path.parent().unwrap()).unwrap();
    let bytes = serde_json::to_vec(value).unwrap();
    std::fs::write(path, &bytes).unwrap();
    sha(&bytes)
}
fn session() -> Session {
    let mut s = Session::default();
    s.execute("solid.box", &json!({"length":1000,"width":1000,"height":1000})).unwrap();
    let model = crate::soil_fem::inspect(&s).unwrap();
    let name = s.model.state().bodies.first().unwrap().name.clone();
    s.execute("analysis.soil.configure",&json!({"ground":{"schema":"soil-fem-ground/1","units":"m-kN-kPa","initialization":{"method":"equilibrate"},"materials":[{"id":1}],"bodies":[{"body":"Clay","material_id":1}]},
        "stages":{"schema":"soil-fem-stages/1","stages":[]},"bindings":[{"analysis_body":"Clay","cad_body":name}],"expected_cad_sha256":model["cad_sha256"],"expected_setup_sha256":model["setup_sha256"]})).unwrap();
    s
}
fn fixture(s: &mut Session, mcc: bool) -> (PathBuf, String) {
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/soil-result-tests").join(format!(
        "{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    std::fs::create_dir_all(&root).unwrap();
    let frozen = crate::soil_fem::snapshot(s, &json!({})).unwrap();
    let input = frozen["input_sha256"].as_str().unwrap().to_string();
    let nodes = json!([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]);
    let cells = json!([[0, 1, 2, 3]]);
    let regions = json!([{"id":1,"body":"Clay"}]);
    let mesh = json!({"nodes":nodes,"tetrahedra":cells,"material_ids":[1],"region_ids":[1],"regions":regions,"node_sets":{"base":[0,1,2]},"crs":"LOCAL","origin_m":[0.,0.,0.]});
    let geometry = json!({"schema":"soil-fem-view-geometry/1","length_unit":"m","axis":"Z-up","nodes_m":nodes,"cells":cells,"cell_kind":"tetra4","regions":regions,"node_sets":{"base":[0,1,2]},"crs":"LOCAL","origin_m":[0.,0.,0.]});
    let faces = json!([{"element_index":0,"nodes":[1,2,3]},{"element_index":0,"nodes":[0,3,2]},{"element_index":0,"nodes":[0,1,3]},{"element_index":0,"nodes":[0,2,1]}]);
    let mut frames = Vec::new();
    let mut files = BTreeMap::new();
    let mut records = Vec::new();
    files.insert("geometry.json".into(), write(&root, "view/geometry.json", &geometry));
    for index in 0..2 {
        let name = if index == 0 { "initial" } else { "preload" };
        let u = if index == 0 { json!(vec![[0.; 3]; 4]) } else { json!([[0., 0., 0.], [0., 0., 0.], [0., 0., 0.], [0., 0., -0.002]]) };
        let stress = if index == 0 { json!([10., 10., 10., 0., 0., 0.]) } else { json!([10., 10., 14., 0., 0., 0.]) };
        let e = if index == 0 { 0.8 } else { 0.79 };
        let pc = if index == 0 { 20. } else { 24. };
        let mut point = json!({"effective_stress_compression_positive_kpa":stress,"plastic_strain_compression_positive":vec![0.;6],"void_ratio":e});
        if mcc {
            point["preconsolidation_pressure_kpa"] = json!(pc);
        }
        let state = json!({"active_elements":[true],"displacement_m":u,"material_states":[point]});
        frames.push(json!({"name":name,"state":state}));
        let mut fields = json!({"effective_stress_compression_positive_kpa":[stress],"plastic_strain_compression_positive":vec![[0.;6]],"void_ratio":[e],"material_id":[1],"region_id":[1],"material_model":[if mcc {0}else{1}]});
        if mcc {
            fields["preconsolidation_pressure_kpa"] = json!([pc]);
        }
        let display = json!({"schema":"soil-fem-view-frame/1","index":index,"name":name,"active_element_ids":[0],"active_node_ids":[0,1,2,3],"boundary_faces":faces,
            "node_fields":{"displacement_m":u,"stage_displacement_increment_m":u,"total_displacement_from_seed_m":u,"display_reference_displacement_m":vec![[0.;3];4]},"cell_fields":fields,"monitors":{},"relative_force_residual":0.,"maximum_normalized_yield":0.});
        let mut point_fields = display["cell_fields"].clone();
        point_fields.as_object_mut().unwrap().remove("region_id");
        let points = json!({"schema":"soil-fem-view-integration-points/1","frame_index":index,"integration_point_ids":[0],"element_ids":[0],"positions_m":[[0.25,0.25,0.25]],"weights_m3":[1./6.],"fields":point_fields});
        let file = format!("frame-{index:03}.json");
        let point_file = format!("points-{index:03}.json");
        files.insert(file.clone(), write(&root, &format!("view/{file}"), &display));
        files.insert(point_file.clone(), write(&root, &format!("view/{point_file}"), &points));
        records.push(json!({"index":index,"name":name,"frame":file,"integration_points":point_file}));
    }
    let run = json!({"schema":"soil-fem-stage-result/1","complete":true,"frames":frames,"case":{"stages":[{"kind":"load"}]}});
    let mut sources: BTreeMap<String, String> = BTreeMap::new();
    sources.insert("analysis/ground/mesh.json".into(), write(&root, "analysis/ground/mesh.json", &mesh));
    sources.insert("analysis/stage-results.json".into(), write(&root, "analysis/stage-results.json", &run));
    sources.insert("analysis/ground/snapshot-canonical.json".into(), write(&root, "analysis/ground/snapshot-canonical.json", &frozen["snapshot"]));
    assert_eq!(sources["analysis/ground/snapshot-canonical.json"], input);
    let exporter = "b".repeat(64);
    sources.insert(
        "analysis/ground/native-capture.json".into(),
        write(&root, "analysis/ground/native-capture.json", &json!({"input_sha256":input,"exporter_binary_sha256":exporter})),
    );
    // A synthetic byte string is only hashed. The reader must never execute it.
    std::fs::create_dir_all(root.join("analysis/solver")).unwrap();
    std::fs::write(root.join("analysis/solver/soil-fem-3d.exe"), b"synthetic, never executable").unwrap();
    let solver = sha(b"synthetic, never executable");
    sources.insert("analysis/solver/soil-fem-3d.exe".into(), solver.clone());
    sources.insert(
        "analysis/accepted-stage-run.json".into(),
        write(&root, "analysis/accepted-stage-run.json", &json!({"schema":"soil-fem-accepted-staged-run/1","solver_binary_sha256":solver})),
    );
    let manifest = json!({"schema":"soil-fem-solidcraft-view/1","complete":true,"input_sha256":input,"cad_sha256":frozen["snapshot"]["cad_sha256"],"exporter_binary_sha256":exporter,"solver_binary_sha256":solver,"geometry":"geometry.json","frames":records,"files_sha256":files,"job_sources_sha256":sources,
        "semantics":{"length_unit":"m","stress_unit":"kPa","stress_sign":"compression positive","stress_components":["xx","yy","zz","xy","yz","xz"]},"omissions":[],"scope":"synthetic reader-invariant fixture, not a mechanical validation"});
    let fingerprint = write(&root, "view/view-manifest.json", &manifest);
    write(&root, "view-verification.json", &json!({"passed":true,"input_sha256":input,"view_manifest_sha256":fingerprint}));
    (root, input)
}
fn open_fixture(s: &mut Session, root: &Path, input: &str) -> Value {
    s.execute("analysis.soil.results.open", &json!({"manifest":root.join("view/view-manifest.json"),"expected_input_sha256":input})).unwrap()
}
fn reseal(root: &Path, file: &str, value: &Value) {
    let mut m: Value = json_file(root, "view/view-manifest.json", 256 << 10).unwrap();
    m["files_sha256"][file] = json!(write(root, &format!("view/{file}"), value));
    let hash = write(root, "view/view-manifest.json", &m);
    write(root, "view-verification.json", &json!({"passed":true,"input_sha256":m["input_sha256"],"view_manifest_sha256":hash}));
}
#[test]
fn load_stage_query_and_close_are_transient_and_keep_raw_values_distinct() {
    let mut s = session();
    let (root, input) = fixture(&mut s, true);
    let doc = s.doc.to_json();
    let undo = s.undo.len();
    let info = open_fixture(&mut s, &root, &input);
    assert_eq!(info["active_elements"], 1);
    let settings = Settings { frame: 1, deformation_scale: 25., ..Default::default() };
    s.execute("analysis.soil.results.configure", &serde_json::to_value(settings).unwrap()).unwrap();
    let value = s.execute("analysis.soil.results.query", &json!({"node":3})).unwrap();
    assert_eq!(value["stored_node_fields"]["displacement_m"][2], -0.002);
    assert_eq!(value["frame_index"], 1);
    assert_eq!(value["input_sha256"], input);
    assert_eq!(value["deformation_scale"], 25.);
    let value = s.execute("analysis.soil.results.query", &json!({"integration_point":0})).unwrap();
    assert_eq!(value["weight_m3"], 1. / 6.);
    assert_eq!(value["effective_stress_compression_positive_kpa"][2], 14.);
    let value = s.execute("analysis.soil.results.query", &json!({"element":0})).unwrap();
    assert_eq!(value["preconsolidation_pressure_kpa"], 24.);
    assert_eq!(s.doc.to_json(), doc);
    assert_eq!(s.undo.len(), undo);
    assert!(s.scratch().soil_result_settings().is_none());
    s.execute("analysis.soil.results.close", &json!({})).unwrap();
    assert!(s.soil_result_scene().unwrap().is_none());
    assert_eq!(s.doc.to_json(), doc);
}
#[test]
fn cad_edit_hides_scene_and_undo_restores_exact_input_applicability() {
    let mut s = session();
    let (root, input) = fixture(&mut s, true);
    open_fixture(&mut s, &root, &input);
    let key = s.soil_result_scene().unwrap().unwrap().key.clone();
    let body = s.model.state().bodies.first().unwrap().name.clone();
    s.execute("body.rename", &json!({"body":body,"name":"changed"})).unwrap();
    assert_eq!(s.execute("analysis.soil.results.status", &json!({})).unwrap()["stale"], true);
    assert!(s.soil_result_scene().is_err());
    assert!(s.execute("analysis.soil.results.query", &json!({"node":0})).is_err());
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(s.soil_result_scene().unwrap().unwrap().key, key);
    s.replace_design(Session::default());
    assert_eq!(s.execute("analysis.soil.results.status", &json!({})).unwrap()["stale"], true);
}
#[test]
fn resealed_geometry_and_nodal_changes_still_fail_authoritative_comparison() {
    for kind in ["geometry", "node", "cell"] {
        let mut s = session();
        let (root, input) = fixture(&mut s, true);
        open_fixture(&mut s, &root, &input);
        let previous = s.soil_result_scene().unwrap().unwrap().key.clone();
        let file = if kind == "geometry" { "geometry.json" } else { "frame-000.json" };
        let mut value: Value = json_file(&root, &format!("view/{file}"), MAX_FILE).unwrap();
        if kind == "geometry" {
            value["nodes_m"][0][0] = json!(0.123);
        } else if kind == "node" {
            value["node_fields"]["displacement_m"][0][2] = json!(0.123);
        } else {
            value["cell_fields"]["effective_stress_compression_positive_kpa"][0][2] = json!(12.);
        }
        reseal(&root, file, &value);
        assert!(
            s.execute("analysis.soil.results.open", &json!({"manifest":root.join("view/view-manifest.json"),"expected_input_sha256":input})).is_err(),
            "{kind}"
        );
        assert_eq!(s.soil_result_scene().unwrap().unwrap().key, previous, "failed open must preserve the already validated in-memory scene");
    }
}
#[test]
fn raw_point_resealing_is_checked_against_source_history() {
    let mut s = session();
    let (root, input) = fixture(&mut s, true);
    let mut points: Value = json_file(&root, "view/points-000.json", MAX_FILE).unwrap();
    points["fields"]["void_ratio"][0] = json!(0.4);
    reseal(&root, "points-000.json", &points);
    open_fixture(&mut s, &root, &input);
    assert!(s.execute("analysis.soil.results.query", &json!({"integration_point":0})).is_err());
}
#[test]
fn unavailable_model_fields_and_failed_configuration_do_not_change_the_display() {
    let mut s = session();
    let (root, input) = fixture(&mut s, false);
    open_fixture(&mut s, &root, &input);
    let original = s.soil_result_settings().unwrap();
    let settings = Settings { quantity: Quantity::PreconsolidationPressure, ..Default::default() };
    assert!(s.execute("analysis.soil.results.configure", &serde_json::to_value(settings).unwrap()).is_err());
    assert_eq!(s.soil_result_settings().unwrap(), original);
    let gp = s.execute("analysis.soil.results.query", &json!({"integration_point":0})).unwrap();
    assert!(gp["preconsolidation_pressure_kpa"].is_null());
    assert!(s.execute("analysis.soil.results.configure", &json!({"frame":usize::MAX})).is_err());
}
#[test]
fn foreign_input_and_frame_inventory_paths_are_rejected_before_adoption() {
    let mut s = session();
    let (root, input) = fixture(&mut s, true);
    assert!(
        s.execute("analysis.soil.results.open", &json!({"manifest":root.join("view/view-manifest.json"),"expected_input_sha256":"0".repeat(64)}))
            .is_err()
    );
    let mut m: Value = json_file(&root, "view/view-manifest.json", 256 << 10).unwrap();
    m["frames"][0]["frame"] = json!("../outside.json");
    let hash = write(&root, "view/view-manifest.json", &m);
    write(&root, "view-verification.json", &json!({"passed":true,"input_sha256":input,"view_manifest_sha256":hash}));
    assert!(
        s.execute("analysis.soil.results.open", &json!({"manifest":root.join("view/view-manifest.json"),"expected_input_sha256":input})).is_err()
    );
    assert!(s.soil_result_settings().is_none());
}

/// Execute explicitly against the public 10 x 10 x 8 m two-layer, 4 x 4 x 2 m
/// excavated fixture. This consumes the existing solved job without rerunning it.
#[test]
#[ignore = "requires SOIL_RESULT_ACCEPTANCE_WORKFLOW and SOIL_RESULT_ACCEPTANCE_REPORT"]
fn completed_native_excavation_has_independent_section_and_raw_value_checks() {
    let root = PathBuf::from(std::env::var("SOIL_RESULT_ACCEPTANCE_WORKFLOW").unwrap());
    let manifest: Value = json_file(&root, "view/view-manifest.json", 256 << 10).unwrap();
    let input = manifest["input_sha256"].as_str().unwrap();
    let source = std::fs::read_to_string(root.join("analysis/ground/source.solidcraft.json")).unwrap();
    let doc = solidcraft_doc::Document::from_json(&source).unwrap();
    let mut s = Session::new(doc);
    let original = s.doc.to_json();
    let undo = s.undo.len();
    let opened = open_fixture(&mut s, &root, input);
    assert_eq!(opened["node_count"], 550);
    assert_eq!(opened["frames"].as_array().unwrap().len(), 2);
    let mut observations = Vec::new();
    for refinement in [1, 2] {
        let settings = Settings {
            frame: 1,
            refinement,
            deformation_scale: 0.,
            principal_directions: true,
            section: Some(Section { normal: [1., 0., 0.], offset_m: 5., slice_only: true }),
            ..Default::default()
        };
        let status = s.execute("analysis.soil.results.configure", &serde_json::to_value(&settings).unwrap()).unwrap();
        assert_eq!(status["active_elements"], 264);
        let scene = s.soil_result_scene().unwrap().unwrap();
        assert!(!scene.glyphs.is_empty());
        for glyph in &scene.glyphs {
            let anchor = (glyph.a_mm + glyph.b_mm) / 2000. + scene.render_origin_m;
            assert!((anchor.x - 5.).abs() < 1e-10, "slice axes must be anchored on the cut plane");
        }
        let mut area = 0.;
        let mut first_moment = Vec3::ZERO;
        for t in &scene.triangles {
            assert!(t.section);
            let points = t.vertices.map(|v| v.position_mm / 1000. + scene.render_origin_m);
            let [a, b, c] = points;
            assert!(points.iter().all(|p| (p.x - 5.).abs() < 1e-11));
            let weight = (b - a).cross(c - a).len() * 0.5;
            area += weight;
            first_moment += (a + b + c) * (weight / 3.);
        }
        let center = first_moment / area;
        // Full section is 10*8, less the 4*2 excavation centered at y=5,z=7.
        assert!((area - 72.).abs() < 1e-9, "area={area}");
        assert!((center.y - 5.).abs() < 1e-10);
        assert!((center.z - 11. / 3.).abs() < 1e-10);
        assert!((scene.reference_section_area_m2 - area).abs() < 1e-10);
        observations.push(json!({"refinement":refinement,"reference_area_m2":area,"centroid_m":center,"status":status}));
    }
    let loaded = s.soil_results.loaded.as_ref().unwrap().clone();
    let node = loaded.frame.active_node_ids[0];
    let element = loaded.frame.active_element_ids[0];
    let point = loaded.layout.iter().position(|p| p.element_index == element).unwrap();
    let node_query = s.execute("analysis.soil.results.query", &json!({"node":node})).unwrap();
    let point_query = s.execute("analysis.soil.results.query", &json!({"integration_point":point})).unwrap();
    let mean_query = s.execute("analysis.soil.results.query", &json!({"element":element})).unwrap();
    assert_eq!(point_query["element"], element);
    assert_eq!(point_query["frame_name"], "excavate_pit");
    assert_eq!(node_query["input_sha256"], input);
    assert_eq!(s.doc.to_json(), original);
    assert_eq!(s.undo.len(), undo);
    let report = json!({"schema":"soil-fem-native-result-reader-acceptance/1","passed":true,"actual_completed_native_job":true,
        "input_sha256":input,"manifest_sha256":loaded.manifest_sha,"sections":observations,"node_query":node_query,
        "element_query":mean_query,"integration_point_query":point_query,"design_and_undo_unchanged":true,
        "scope":"Engine result loading and section/raw-value verification only; no GPU or GUI claim"});
    let report_path = PathBuf::from(std::env::var("SOIL_RESULT_ACCEPTANCE_REPORT").unwrap());
    let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(report_path).unwrap();
    use std::io::Write;
    file.write_all(&serde_json::to_vec_pretty(&report).unwrap()).unwrap();
}

fn structural_fixture() -> (Geometry, Frame, Value, Value) {
    let xyz = json!([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]);
    let mesh = json!({"nodes":xyz,"node_sets":{"a":[0],"b":[1],"c":[2]}});
    let g: Geometry = serde_json::from_value(json!({"schema":"soil-fem-view-geometry/1","length_unit":"m","axis":"Z-up",
        "nodes_m":xyz,"cells":[[0,1,2,3]],"cell_kind":"tetra4","regions":[],"node_sets":mesh["node_sets"],"crs":"LOCAL","origin_m":[0.,0.,0.]}))
    .unwrap();
    let axes = json!([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]);
    let beam = json!({"id":"beam","length_m":1.,"local_axes":axes,"local_end_actions":vec![0.;12],
        "local_end_relative_rotation_rad":vec![[0.;3];2],"section_forces_at_start_mid_end":[[9.,0.,0.,0.,2.,3.],[8.,0.,0.,0.,4.,5.],[7.,0.,0.,0.,6.,7.]]});
    let samples: Vec<_> = (0..3)
        .map(|i| {
            json!({"barycentric":std::array::from_fn::<_,3,_>(|j|if i==j {2./3.}else{1./6.}),
        "membrane_strain":vec![0.;3],"curvature_per_m":vec![0.;3],"membrane_force_kn_m":[10.,20.,30.],
        "bending_moment_kn":[1.+i as f64,4.,5.],"drilling_mismatch_rad":0.})
        })
        .collect();
    let plate = json!({"id":"plate","area_m2":0.5,"local_axes":axes,"samples":samples,"membrane_energy_kn_m":1.,"bending_energy_kn_m":2.,"drilling_penalty_energy_kn_m":0.});
    let nodes = json!({"ids":["a","b","c"],"positions_m":[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]],"soil_node_ids":[0,1,2],
        "displacement_m":[[0.,0.,0.],[0.,0.,-0.1],[0.,0.,-0.2]],"rotation_rad":vec![[0.;3];3],"active":vec![true;3]});
    let resultants = json!({"external_force_kn":vec![0.;3],"external_moment_origin_kn_m":vec![0.;3],"support_force_kn":vec![0.;3],"support_moment_origin_kn_m":vec![0.;3]});
    let data = json!({"schema":"soil-fem-view-structures/1","nodes":nodes,
        "members":[{"id":"beam","nodes":[0,1],"section_id":"b","active":true,"reference_global_kinematics":vec![0.;12],"result":beam}],
        "plates":[{"id":"plate","nodes":[0,1,2],"section_id":"p","active":true,"reference_global_kinematics":vec![0.;18],"result":plate,"thickness_m":0.1}],
        "global_resultants":resultants,"semantics":super::super::structures::semantics()});
    let f:Frame=serde_json::from_value(json!({"schema":"soil-fem-view-frame/3","index":0,"name":"loaded","active_element_ids":[0],"active_node_ids":[0,1,2,3],
        "boundary_faces":[],"node_fields":{},"cell_fields":{"effective_stress_compression_positive_kpa":[[100.,100.,100.,0.,0.,0.]],
            "plastic_strain_compression_positive":[vec![0.;6]],"void_ratio":[1.],"preconsolidation_pressure_kpa":[200.],"material_id":[1],"region_id":[1],"material_model":[0]},
        "monitors":{},"relative_force_residual":0.,"maximum_normalized_yield":-0.1,"structures":data})).unwrap();
    let definitions: Vec<_> = ["a", "b", "c"].into_iter().map(|id| json!({"id":id,"soil_node_set":id})).collect();
    let mut report = resultants.clone();
    report["members"] = json!([beam]);
    report["plates"] = json!([plate]);
    report["node_active"] = nodes["active"].clone();
    let run = json!({"schema":"soil-fem-stage-result/14","case":{"beam_system":{"nodes":definitions,
        "members":[{"id":"beam","nodes":["a","b"],"section_id":"b"}],"plates":[{"id":"plate","nodes":["a","b","c"],"section_id":"p"}],
        "plate_sections":[{"id":"p","thickness_m":0.1}]}},"frames":[{"beam_results":report,
        "state":{"displacement_m":[[0.,0.,0.],[0.,0.,-0.1],[0.,0.,-0.2],[0.,0.,0.]],"beams":{"active_members":[true],"active_plates":[true],"node_displacement_m":nodes["displacement_m"],"node_rotation_rad":nodes["rotation_rad"],
        "reference_global_kinematics":[vec![0.;12]],"plate_reference_global_kinematics":[vec![0.;18]]}}}]});
    (g, f, run, mesh)
}

#[test]
fn structural_frame_is_bound_to_source_axes_samples_references_and_connectivity() {
    let (g, mut f, mut run, mesh) = structural_fixture();
    super::super::structures::validate(&g, &f, &run, &mesh).unwrap();
    f.structures.as_mut().unwrap().plates[0].result.as_mut().unwrap()["samples"][0]["bending_moment_kn"][0] = json!(1.01);
    assert!(super::super::structures::validate(&g, &f, &run, &mesh).is_err());
    let (_, mut f, _, _) = structural_fixture();
    f.structures.as_mut().unwrap().members[0].reference_global_kinematics[0] = 0.1;
    assert!(super::super::structures::validate(&g, &f, &run, &mesh).is_err());
    let (_, mut f, _, _) = structural_fixture();
    f.structures.as_mut().unwrap().nodes.soil_node_ids[0] = Some(3);
    assert!(super::super::structures::validate(&g, &f, &run, &mesh).is_err());
    let (_, f, _, _) = structural_fixture();
    run["frames"][0]["beam_results"]["plates"][0]["local_axes"] = json!(vec![[0.; 3]; 3]);
    assert!(super::super::structures::validate(&g, &f, &run, &mesh).is_err());
}

#[test]
fn structural_scene_keeps_raw_plate_regions_units_references_and_beam_section_extrema() {
    let (g, f, _, _) = structural_fixture();
    let beam = geometry::build(&g, &f, &Settings { quantity: Quantity::BeamMomentY, deformation_scale: 2., ..Default::default() }, "loaded").unwrap();
    assert_eq!(beam.member_lines.len(), 16);
    assert!(beam.triangles.is_empty());
    assert!(beam.has_visible_geometry());
    assert!(beam.quantity_available(&Quantity::BeamMomentY));
    assert_eq!(beam.data_range, [2., 6.]);
    assert_eq!(Quantity::BeamAxialForce.unit(), "kN");
    assert_eq!(Quantity::BeamMomentY.unit(), "kN m");
    assert_eq!(Quantity::PlateBendingXx.unit(), "kN m/m");
    assert_eq!(Quantity::PlateMembraneXx.unit(), "kN/m");
    assert!((beam.member_lines.last().unwrap().b_mm.z + 700.).abs() < 1e-10);
    let plate =
        geometry::build(&g, &f, &Settings { quantity: Quantity::PlateBendingXx, deformation_scale: 0., ..Default::default() }, "loaded").unwrap();
    assert_eq!(plate.triangles.len(), 6);
    assert_eq!(plate.data_range, [1., 3.]);
    let values: Vec<_> = plate.triangles.iter().map(|t| t.vertices[0].scalar.unwrap()).collect();
    assert_eq!(values, vec![1., 1., 2., 2., 3., 3.]);
    // Soil display basis is intentionally absent from the structural map: both
    // settings retain CAD member displacement, never subtract a soil RESET.
    let second = geometry::build(
        &g,
        &f,
        &Settings {
            quantity: Quantity::BeamMomentY,
            deformation_scale: 2.,
            displacement_reference: DisplacementReference::Stage,
            ..Default::default()
        },
        "loaded",
    )
    .unwrap();
    assert_eq!(beam.member_lines.last().unwrap().b_mm, second.member_lines.last().unwrap().b_mm);
}

#[test]
fn structural_sections_use_reference_geometry_and_removed_members_leave_no_stale_triangles_or_lines() {
    let (g, mut f, _, _) = structural_fixture();
    let settings = Settings {
        quantity: Quantity::PlateBendingXx,
        deformation_scale: 0.,
        section: Some(Section { normal: [0., 0., 1.], offset_m: 0., slice_only: true }),
        ..Default::default()
    };
    let coplanar = geometry::build(&g, &f, &settings, "loaded").unwrap();
    assert_eq!(coplanar.triangles.len(), 6);
    assert!((coplanar.reference_section_area_m2 - 0.5).abs() < 1e-12);
    let cut = geometry::build(
        &g,
        &f,
        &Settings { section: Some(Section { normal: [1., 0., 0.], offset_m: 0.5, slice_only: true }), ..settings.clone() },
        "loaded",
    )
    .unwrap();
    assert!(cut.triangles.is_empty());
    assert!(!cut.member_lines.is_empty());
    assert!(cut.has_visible_geometry());
    assert!(cut.quantity_available(&Quantity::PlateBendingXx));
    assert!(cut.member_lines.iter().all(|line| line.a_mm.x.abs() < 1e-10 && line.b_mm.x.abs() < 1e-10));
    let hit = geometry::pick(&cut, Vec3::from([0., -250., 0.]), Vec3::from([0., 0., -1.]));
    assert_eq!(hit["plate"], 0);
    assert_eq!(hit["plate_id"], "plate");
    assert!(hit.get("element").is_none());
    let data = f.structures.as_mut().unwrap();
    data.nodes.active.fill(false);
    for entry in data.members.iter_mut().chain(&mut data.plates) {
        entry.active = false;
        entry.result = None;
    }
    let removed = geometry::build(&g, &f, &Settings { frame: 1, ..settings }, "removed").unwrap();
    assert!(removed.triangles.is_empty() && removed.member_lines.is_empty());
    assert!(!removed.has_visible_geometry());
    assert!(!removed.quantity_available(&Quantity::PlateBendingXx));
    assert_ne!(removed.key, coplanar.key);
    assert_eq!(f.structures.as_ref().unwrap().nodes.displacement_m[1], [0., 0., -0.1]);
}
