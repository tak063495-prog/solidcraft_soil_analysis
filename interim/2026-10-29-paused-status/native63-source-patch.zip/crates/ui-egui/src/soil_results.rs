//! Native FEM result workspace. Scientific quantities and section geometry belong
//! to L4; this adapter uses the shared GPU pipelines, theme and navigation.
use crate::{
    SolveApp,
    gpu::{Frame, GpuScene, SceneSlot, ViewportCallback},
    theme::Tokens,
    ui_kit,
};
use egui::{Color32, Sense};
use serde_json::{Value, json};
use solidcraft_engine::{
    geom::Aabb3,
    render::Camera,
    soil_results::{DisplacementReference, Quantity, Scene, Section, Settings},
};
use std::{
    hash::{Hash, Hasher},
    sync::{Arc, Mutex},
};

pub struct Viewer {
    saved_camera: Camera,
    controls: bool,
    settings: Settings,
    info: Value,
    error: Option<String>,
    query: Option<Value>,
    query_id: usize,
    query_material: u32,
    query_kind: u8,
    slot: SceneSlot,
    key: Option<u64>,
    source_key: Option<String>,
    revision: u64,
}
pub fn active(app: &SolveApp) -> bool {
    app.soil_result_viewer.is_some()
}
pub fn bounds(app: &mut SolveApp) -> Option<Aabb3> {
    app.session.soil_result_scene().ok().flatten().map(|s| s.bounds).filter(|b| !b.is_empty())
}
pub fn open_viewer(app: &mut SolveApp) {
    let Some(settings) = app.session.soil_result_settings() else {
        pick(app);
        return;
    };
    if let Some(view) = app.soil_result_viewer.as_mut() {
        view.controls = true;
        view.settings = settings;
        view.info = Value::Null;
        view.key = None;
        view.query = None;
        view.error = None;
        return;
    }
    let info = match app.run("analysis.soil.results.status", json!({})) {
        Ok(info) => info,
        Err(error) => {
            app.set_status(error, true);
            return;
        }
    };
    app.soil_result_viewer = Some(Viewer {
        saved_camera: app.cam,
        controls: true,
        settings,
        info,
        error: None,
        query: None,
        query_id: 0,
        query_material: 1,
        query_kind: 0,
        slot: Arc::new(Mutex::new(None)),
        key: None,
        source_key: None,
        revision: app.session.revision,
    });
    app.cam = Camera::default();
    app.cam.fov = if app.perspective_view() { 0.6 } else { 0.0 };
    app.cancel_view_animation();
    if let Some(bounds) = bounds(app) {
        app.fit_bounds(bounds);
    }
}
pub fn pick(app: &mut SolveApp) {
    app.pick_file("Completed soil result manifest", &["json"], |app, path| {
        let Some(path) = path else {
            return;
        };
        let result = (|| -> Result<(), String> {
            let snapshot = app.run("analysis.soil.snapshot", json!({}))?;
            app.run("analysis.soil.results.open", json!({"manifest":path,"expected_input_sha256":snapshot.get("input_sha256")}))?;
            if let Some(mut settings) = app.session.soil_result_settings() {
                let info = app.run("analysis.soil.results.status", json!({}))?;
                settings.frame = info.get("frames").and_then(Value::as_array).map_or(0, |a| a.len().saturating_sub(1));
                app.run("analysis.soil.results.configure", serde_json::to_value(settings).map_err(|e| e.to_string())?)?;
            }
            open_viewer(app);
            Ok(())
        })();
        if let Err(error) = result {
            app.set_status(error, true);
        }
    });
}
fn ramp(t: f64) -> Color32 {
    Tokens::get().analysis_scalar_color(t)
}
fn gpu(scene: &Scene, settings: &Settings) -> Result<GpuScene, String> {
    const MAX_BYTES: usize = 192 << 20;
    let triangle_bytes = scene.triangles.len().checked_mul(3 * crate::gpu::TRI_SIZE).ok_or("display GPU size overflow")?;
    let line_count = if settings.wireframe { scene.triangles.len().saturating_mul(3) } else { 0 };
    let line_bytes = line_count.saturating_add(scene.glyphs.len()).saturating_add(scene.member_lines.len()).saturating_mul(crate::gpu::LINE_SIZE);
    if triangle_bytes.saturating_add(line_bytes) > MAX_BYTES {
        return Err("FEM display exceeds the 192 MiB GPU budget; reduce refinement or disable edges".into());
    }
    let mut out = GpuScene::default();
    out.tris.try_reserve(triangle_bytes).map_err(|_| "FEM GPU vertex allocation failed")?;
    let [low, high] = scene.color_range;
    let unavailable = Tokens::get().text_dim;
    for triangle in &scene.triangles {
        for vertex in triangle.vertices {
            let color = vertex.scalar.map_or(unavailable, |v| ramp((v - low) / (high - low)));
            out.tri(vertex.position_mm.to_f32(), [0.; 3], color.to_array());
        }
        if settings.wireframe {
            for (a, b) in [(0, 1), (1, 2), (2, 0)] {
                out.line(
                    triangle.vertices[a].position_mm.to_f32(),
                    triangle.vertices[b].position_mm.to_f32(),
                    Tokens::get().body_edge.to_array(),
                    0.6,
                    false,
                );
            }
        }
    }
    for glyph in &scene.glyphs {
        out.line(glyph.a_mm.to_f32(), glyph.b_mm.to_f32(), Tokens::get().text.to_array(), 1.4, false);
    }
    for line in &scene.member_lines {
        let color = ramp((line.scalar - low) / (high - low));
        out.line(line.a_mm.to_f32(), line.b_mm.to_f32(), color.to_array(), 2., false);
    }
    Ok(out)
}
fn legend(ui: &egui::Ui, rect: egui::Rect, scene: &Scene, settings: &Settings) {
    let t = Tokens::get();
    let width = 200.;
    let height = t.space_12;
    let left = rect.right() - width - t.space_24;
    let top = rect.bottom() - height - 3. * t.space_24;
    let painter = ui.painter();
    for i in 0..64 {
        let x = left + width * i as f32 / 64.;
        painter.rect_filled(egui::Rect::from_min_size(egui::pos2(x, top), egui::vec2(width / 64. + 0.5, height)), 0., ramp(f64::from(i) / 63.));
    }
    for (value, x, align) in [
        (scene.color_range[0], left, egui::Align2::LEFT_TOP),
        ((scene.color_range[0] + scene.color_range[1]) * 0.5, left + width * 0.5, egui::Align2::CENTER_TOP),
        (scene.color_range[1], left + width, egui::Align2::RIGHT_TOP),
    ] {
        painter.text(egui::pos2(x, top + height + t.space_4), align, format!("{value:.4e}"), egui::FontId::proportional(t.font_small), t.text);
    }
    painter.text(
        egui::pos2(left + width, top + height + t.space_24),
        egui::Align2::RIGHT_TOP,
        format!("{} ({})", quantity_label(&settings.quantity), settings.quantity.unit()),
        egui::FontId::proportional(t.font_body),
        t.text,
    );
}
pub fn show_workspace(app: &mut SolveApp, ui: &mut egui::Ui) {
    if app.soil_result_viewer.is_none() {
        return;
    }
    let rect = ui.max_rect();
    app.cam.fov = if app.perspective_view() { 0.6 } else { 0.0 };
    app.viewport.rect = Some(rect);
    crate::viewport::refresh_layout(app, ui.ctx().pixels_per_point());
    let response = ui.interact(rect, ui.id().with("soil_results_canvas"), Sense::click_and_drag());
    crate::navigation::handle(app, ui, rect, &response, crate::navigation::NavCaps::RENDER);
    let Some(mut viewer) = app.soil_result_viewer.take() else {
        return;
    };
    ui.painter().rect_filled(rect, 0., Tokens::get().viewport_top);
    let result = (|| -> Result<(), String> {
        let scene = app.session.soil_result_scene().map_err(|e| e.to_string())?.ok_or("No soil results are loaded")?;
        if app.viewport.gpu.is_none() {
            return Err("A GPU viewport is required for this FEM result view".into());
        }
        let settings = app.session.soil_result_settings().ok_or("No soil result settings")?;
        let mut hash = std::collections::hash_map::DefaultHasher::new();
        "soil-results".hash(&mut hash);
        scene.key.hash(&mut hash);
        for color in Tokens::get().analysis.curvature {
            for component in color {
                component.to_bits().hash(&mut hash);
            }
        }
        for color in [Tokens::get().text_dim, Tokens::get().body_edge, Tokens::get().text] {
            color.to_array().hash(&mut hash);
        }
        let key = hash.finish();
        if viewer.key != Some(key) {
            let data = gpu(&scene, &settings)?;
            let mut slot = viewer.slot.lock().map_err(|_| "FEM scene upload lock is unavailable")?;
            *slot = Some(data);
            viewer.key = Some(key);
        }
        let ppp = ui.ctx().pixels_per_point();
        let mut camera = app.cam;
        camera.fov = if app.perspective_view() { 0.6 } else { 0.0 };
        let radius = scene.bounds.diagonal().max(10.) + scene.bounds.center().dist(camera.target);
        let eye = camera.eye();
        let slot = viewer.slot.clone();
        ui.painter().add(egui_wgpu::Callback::new_paint_callback(
            rect,
            ViewportCallback(Frame {
                product: true,
                key,
                slot: slot.clone(),
                sketch_key: 0,
                sketch_slot: slot.clone(),
                hl_key: 0,
                hl_slot: slot.clone(),
                pv_key: 0,
                pv_slot: slot,
                pv_hide: false,
                view_proj: camera.view_proj(f64::from(rect.width() / rect.height().max(1.)), radius).to_f32(),
                back: camera.back().to_f32(),
                size_px: [rect.width() * ppp, rect.height() * ppp],
                clip: [0.; 4],
                cap: [0.; 4],
                images: Vec::new(),
                analysis: [0.; 8],
                analysis_colors: [0.; 36],
                access: None,
                outline: false,
                eye: [eye.x as f32, eye.y as f32, eye.z as f32, if camera.fov > 0. { 1. } else { 0. }],
                ao_radius: 0.,
                ssaa: 1.,
            }),
        ));
        // Upload even an empty scene above: removal/empty cuts must replace
        // the previous GPU frame rather than retaining stale member geometry.
        if scene.quantity_available(&settings.quantity) {
            legend(ui, crate::shell::workspace_content(app, rect), &scene, &settings);
        }
        if !scene.has_visible_geometry() {
            let message = if scene.quantity_available(&settings.quantity) {
                "The reference section has no visible intersection on its retained side"
            } else {
                "No active members for this quantity in this stage"
            };
            ui.painter().text(
                rect.center(),
                egui::Align2::CENTER_CENTER,
                message,
                egui::FontId::proportional(Tokens::get().font_body),
                Tokens::get().text_dim,
            );
        }
        if response.clicked()
            && let Some(point) = response.interact_pointer_pos()
        {
            let (origin, direction) = crate::viewport::projection(app, rect).ray(point);
            match app.run("analysis.soil.results.query", json!({"ray_origin_mm":origin,"ray_direction":direction})) {
                Ok(value) => {
                    viewer.query = Some(value);
                    viewer.controls = true;
                }
                Err(error) => viewer.error = Some(error),
            }
        }
        Ok(())
    })();
    if let Err(error) = result {
        ui.painter().text(
            rect.center(),
            egui::Align2::CENTER_CENTER,
            error,
            egui::FontId::proportional(Tokens::get().font_heading),
            Tokens::get().form_error,
        );
    }
    crate::viewport::axis_view(app, ui, rect);
    app.soil_result_viewer = Some(viewer);
}

pub fn show_controls(app: &mut SolveApp, ctx: &egui::Context) {
    let Some(mut viewer) = app.soil_result_viewer.take() else {
        return;
    };
    let Some(current_settings) = app.session.soil_result_settings() else {
        app.cam = viewer.saved_camera;
        app.cancel_view_animation();
        return;
    };
    if viewer.settings != current_settings {
        viewer.settings = current_settings;
        viewer.info = Value::Null;
        viewer.query = None;
    }
    let source_key = app.session.soil_result_scene().ok().flatten().map(|scene| scene.key.clone());
    if viewer.source_key != source_key {
        viewer.source_key = source_key;
        viewer.info = Value::Null;
        viewer.query = None;
    }
    if viewer.revision != app.session.revision || viewer.info.is_null() {
        viewer.query = None;
        match app.run("analysis.soil.results.status", json!({})) {
            Ok(info) => viewer.info = info,
            Err(error) => viewer.error = Some(error),
        }
        viewer.revision = app.session.revision;
    }
    if !viewer.controls {
        app.soil_result_viewer = Some(viewer);
        return;
    }
    let stale = viewer.info.get("stale").and_then(Value::as_bool) == Some(true);
    let mut changed = false;
    let mut fit = false;
    let mut inspect = false;
    let mut load = false;
    let title = crate::i18n::tr_label("Soil Result Viewer");
    let (hidden,action)=ui_kit::Window::new(egui::Id::new("soil_results_controls"),"settings",title).cards(1.65).fields()
        .placed(egui::Align2::LEFT_TOP,egui::pos2(270.,170.)).actions("","Return to CAD",None).show(ctx,true,|ui| {
            ui.horizontal(|ui|{load=ui_kit::button(ui,crate::i18n::tr_label("Open Soil Results"),ui_kit::Button::Normal).clicked();fit=ui_kit::button(ui,crate::i18n::tr_label("Fit results"),ui_kit::Button::Normal).clicked();});
            if stale {ui_kit::text(ui,"CAD or analysis inputs changed. Result geometry is hidden until the matching input is restored.",ui_kit::Text::Report("soil_results_stale",true));}
            ui.add_enabled_ui(!stale,|ui| {
                ui_kit::row(ui,"Stage",|ui|{ui_kit::dropdown_menu(ui,"soil_result_frame",viewer.info.get("frame_name").and_then(Value::as_str).unwrap_or("Stage"),|ui| {
                    for frame in viewer.info.get("frames").and_then(Value::as_array).into_iter().flatten() {
                        if let (Some(index),Some(name))=(frame.get("index").and_then(Value::as_u64),frame.get("name").and_then(Value::as_str)) {changed|=choose(ui,&mut viewer.settings.frame,index as usize,name);}
                    }
                });});
                ui_kit::row(ui,"Quantity",|ui|{ui_kit::dropdown_menu(ui,"soil_result_quantity",crate::i18n::tr_label(quantity_label(&viewer.settings.quantity)),|ui| {
                    for (quantity,label) in [(Quantity::VerticalDisplacement,"Vertical displacement"),(Quantity::DisplacementMagnitude,"Displacement magnitude"),(Quantity::EffectiveStressZz,"Material effective stress zz"),(Quantity::MeanEffectiveStress,"Material mean effective stress p"),(Quantity::MajorEffectiveStress,"Major material effective stress"),(Quantity::VoidRatio,"Void ratio"),(Quantity::PreconsolidationPressure,"Preconsolidation pressure pc"),(Quantity::VolumetricPlasticStrain,"Volumetric plastic strain"),(Quantity::PrimaryMeanEffectiveStress,"Primary mean effective stress (P1)"),(Quantity::WorkEffectiveStressZz,"Work-conjugate effective zz (cell mean)"),(Quantity::MaterialVolumeStrain,"Material volume strain (P1)"),(Quantity::KinematicVolumeStrain,"Kinematic volume strain (cell mean)")] {changed|=choose(ui,&mut viewer.settings.quantity,quantity,label);}
                    if viewer.info.get("defined_beams").and_then(Value::as_u64).is_some_and(|n|n>0) {
                        for quantity in [Quantity::BeamAxialForce,Quantity::BeamMomentY,Quantity::BeamMomentZ] {
                            let label=quantity_label(&quantity);changed|=choose(ui,&mut viewer.settings.quantity,quantity,label);
                        }
                    }
                    if viewer.info.get("defined_plates").and_then(Value::as_u64).is_some_and(|n|n>0) {
                        for quantity in [Quantity::PlateMembraneXx,Quantity::PlateMembraneYy,Quantity::PlateMembraneXy,Quantity::PlateBendingXx,Quantity::PlateBendingYy,Quantity::PlateBendingXy] {
                            let label=quantity_label(&quantity);changed|=choose(ui,&mut viewer.settings.quantity,quantity,label);
                        }
                    }
                });});
                if viewer.settings.quantity.structural() {
                    ui_kit::row(ui,"Displacement basis",|ui|{ui.label("Member CAD reference");});
                } else {
                ui_kit::row(ui,"Displacement basis",|ui|{ui_kit::dropdown_menu(ui,"soil_result_reference",crate::i18n::tr_label(match viewer.settings.displacement_reference {DisplacementReference::Display=>"Display reference",DisplacementReference::Stage=>"Stage increment",DisplacementReference::Seed=>"Total from seed"}),|ui| {
                    for (basis,label) in [(DisplacementReference::Display,"Display reference"),(DisplacementReference::Stage,"Stage increment"),(DisplacementReference::Seed,"Total from seed")] {changed|=choose(ui,&mut viewer.settings.displacement_reference,basis,label);}
                });});
                }
                ui_kit::row(ui,"Deformation scale",|ui|{changed|=ui_kit::number_field(ui,&mut viewer.settings.deformation_scale,0.0..=1e6,1.,"").changed();});
                if !viewer.settings.quantity.structural() {ui_kit::row(ui,"Display refinement",|ui|{for level in 1..=3 {changed|=choose(ui,&mut viewer.settings.refinement,level,format!("{}",1u32<<level));}});}
                let mut manual_range=viewer.settings.color_range.is_some();
                if ui_kit::checkbox(ui,crate::i18n::tr_label("Fixed legend range"),&mut manual_range).changed() {
                    viewer.settings.color_range=manual_range.then(|| viewer.info.get("color_range").and_then(Value::as_array).and_then(|a| Some([a.first()?.as_f64()?,a.get(1)?.as_f64()?])).unwrap_or([-1.,1.]));
                    changed=true;
                }
                if let Some(range)=viewer.settings.color_range.as_mut() {
                    ui_kit::row(ui,"Legend limits",|ui|{for limit in range {changed|=ui_kit::number_field(ui,limit,f64::MIN..=f64::MAX,0.1,"").changed();}});
                }
                let mut section=viewer.settings.section.is_some();
                if ui_kit::checkbox(ui,crate::i18n::tr_label("Reference-coordinate section"),&mut section).changed() {viewer.settings.section=section.then_some(Section {normal:[1.,0.,0.],offset_m:0.,slice_only:true});changed=true;}
                if let Some(section)=viewer.settings.section.as_mut() {
                    ui_kit::row(ui,"Plane normal",|ui|{for n in &mut section.normal {changed|=ui_kit::number_field(ui,n,f64::MIN..=f64::MAX,0.1,"").changed();}});
                    ui_kit::row(ui,"Plane offset (m)",|ui|{changed|=ui_kit::number_field(ui,&mut section.offset_m,f64::MIN..=f64::MAX,0.1,"").changed();});
                    changed|=ui_kit::checkbox(ui,crate::i18n::tr_label("Section only (off: keep negative side)"),&mut section.slice_only).changed();
                }
                changed|=ui_kit::checkbox(ui,crate::i18n::tr_label("Display triangle edges"),&mut viewer.settings.wireframe).changed();
                if !viewer.settings.quantity.structural() {changed|=ui_kit::checkbox(ui,crate::i18n::tr_label("Major axis of mean effective tensor"),&mut viewer.settings.principal_directions).changed();}
            });
            if let Some(range)=viewer.info.get("data_range").and_then(Value::as_array)
                && let (Some(low),Some(high))=(range.first().and_then(Value::as_f64),range.get(1).and_then(Value::as_f64)) {
                ui.label(format!("Range: {low:.5e} to {high:.5e} {}",viewer.settings.quantity.unit()));
            }
            ui_kit::text(ui,if viewer.settings.quantity.structural(){"Beam section actions use local axes. Plates display raw DKT samples on three equal-area regions without averaging across plates. Member displacement is from CAD, independent of soil display RESET. Inactive members are hidden; read their archived values by index."}else if viewer.settings.quantity.primary(){"Material-specific P1 interpolation of stored corner values. Material boundaries retain separate values. Compression is positive."}else if viewer.settings.quantity.nodal(){"Nodal displacement interpolation. Z is up: settlement negative, heave positive."}else{"Original-cell integration-weighted means. Stress is compression positive; no smoothing to nodes. Null values are unavailable."},ui_kit::Text::Note("soil_result_values"));
            ui_kit::text(ui,"Curved Tet10 surfaces and sections use refined planar display triangles. Section planes use reference coordinates; deformation is applied afterwards.",ui_kit::Text::Note("soil_result_approximation"));
            if viewer.settings.quantity.structural() {
                ui_kit::text(ui,"Structural display geometry uses straight beam ends and flat plate triangles with linear nodal displacement. Beam colors interpolate start/mid/end section values over 16 display segments. No active members produces an empty layer.",ui_kit::Text::Note("soil_result_structural_approximation"));
            }
            ui.horizontal(|ui| {ui_kit::dropdown_menu(ui,"soil_query_kind",["Node","Element mean","Raw integration point","Primary node + material","Structural node","Beam index","Plate index"].get(viewer.query_kind as usize).copied().unwrap_or("Node"),|ui| {
                for (kind,label) in [(0,"Node"),(1,"Element mean"),(2,"Raw integration point"),(3,"Primary node + material")] {choose(ui,&mut viewer.query_kind,kind,label);}
                if viewer.info.get("structural_nodes").and_then(Value::as_u64).is_some() {choose(ui,&mut viewer.query_kind,4,"Structural node");}
                if viewer.info.get("defined_beams").and_then(Value::as_u64).is_some_and(|n|n>0) {choose(ui,&mut viewer.query_kind,5,"Beam index");}
                if viewer.info.get("defined_plates").and_then(Value::as_u64).is_some_and(|n|n>0) {choose(ui,&mut viewer.query_kind,6,"Plate index");}
            });
                ui_kit::number_field(ui,&mut viewer.query_id,0..=usize::MAX,1.,"");
                if viewer.query_kind==3 {ui.label("Material");ui_kit::number_field(ui,&mut viewer.query_material,1..=u32::MAX,1.,"");}
                inspect=ui_kit::button(ui,"Read stored value",ui_kit::Button::Enabled(!stale)).clicked();});
            if let Some(value)=&viewer.query {ui_kit::section(ui,"soil_selected_value","Selected value",true,|ui| {ui.add(egui::Label::new(serde_json::to_string_pretty(value).unwrap_or_default()).wrap());});}
            if let Some(error)=&viewer.error {ui_kit::text(ui,error,ui_kit::Text::Report("soil_result_error",true));}
            ui_kit::text(ui,"Close this header to hide controls; Soil Result Viewer reopens them. Return to CAD releases this result.",ui_kit::Text::Note("soil_result_close"));
        });
    if hidden {
        viewer.controls = false;
    }
    if action == ui_kit::Action::Cancel {
        let _ = app.run("analysis.soil.results.close", json!({}));
        app.cam = viewer.saved_camera;
        app.cancel_view_animation();
        return;
    }
    if changed {
        match serde_json::to_value(&viewer.settings).map_err(|e| e.to_string()).and_then(|p| app.run("analysis.soil.results.configure", p)) {
            Ok(info) => {
                viewer.info = info;
                viewer.error = None;
                viewer.query = None;
            }
            Err(error) => {
                viewer.error = Some(error);
                if let Some(settings) = app.session.soil_result_settings() {
                    viewer.settings = settings;
                }
            }
        }
    }
    if inspect {
        let params = match viewer.query_kind {
            0 => json!({"node":viewer.query_id}),
            1 => json!({"element":viewer.query_id}),
            3 => json!({"primary_node":viewer.query_id,"primary_material":viewer.query_material}),
            4 => json!({"structural_node":viewer.query_id}),
            5 => json!({"beam":viewer.query_id}),
            6 => json!({"plate":viewer.query_id}),
            _ => json!({"integration_point":viewer.query_id}),
        };
        match app.run("analysis.soil.results.query", params) {
            Ok(value) => {
                viewer.query = Some(value);
                viewer.error = None;
            }
            Err(error) => viewer.error = Some(error),
        }
    }
    app.soil_result_viewer = Some(viewer);
    if fit {
        app.animate_fit_all();
    }
    if load {
        pick(app);
    }
}

fn quantity_label(quantity: &Quantity) -> &'static str {
    match quantity {
        Quantity::VerticalDisplacement => "Vertical displacement",
        Quantity::DisplacementMagnitude => "Displacement magnitude",
        Quantity::EffectiveStressZz => "Material effective stress zz",
        Quantity::MeanEffectiveStress => "Material mean effective stress p",
        Quantity::MajorEffectiveStress => "Major material effective stress",
        Quantity::PrimaryMeanEffectiveStress => "Primary mean effective stress (P1)",
        Quantity::WorkEffectiveStressZz => "Work-conjugate effective zz (cell mean)",
        Quantity::MaterialVolumeStrain => "Material volume strain (P1)",
        Quantity::KinematicVolumeStrain => "Kinematic volume strain (cell mean)",
        Quantity::VoidRatio => "Void ratio",
        Quantity::PreconsolidationPressure => "Preconsolidation pressure pc",
        Quantity::VolumetricPlasticStrain => "Volumetric plastic strain",
        Quantity::BeamAxialForce => "Beam axial force N",
        Quantity::BeamMomentY => "Beam moment My (local)",
        Quantity::BeamMomentZ => "Beam moment Mz (local)",
        Quantity::PlateMembraneXx => "Plate membrane Nxx (local)",
        Quantity::PlateMembraneYy => "Plate membrane Nyy (local)",
        Quantity::PlateMembraneXy => "Plate membrane Nxy (local)",
        Quantity::PlateBendingXx => "Plate bending Mxx (local)",
        Quantity::PlateBendingYy => "Plate bending Myy (local)",
        Quantity::PlateBendingXy => "Plate bending Mxy (local)",
    }
}

fn choose<T: PartialEq>(ui: &mut egui::Ui, value: &mut T, next: T, label: impl AsRef<str>) -> bool {
    let label = label.as_ref();
    if ui_kit::list_picker(ui, label, crate::i18n::tr_label(label), *value == next).clicked() && *value != next {
        *value = next;
        return true;
    }
    false
}
