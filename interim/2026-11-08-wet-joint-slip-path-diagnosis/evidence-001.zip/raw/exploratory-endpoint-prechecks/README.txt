Preliminary endpoint measurements only; no extra numerical solves. Final comparison schema and all pairs are in raw/measurements.json.
