from pathlib import Path
import hashlib,json,re,zipfile,sys,shutil
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'interim/2026-11-11-joint-crack-tip'
RUNS=Path(__file__).resolve().parent

def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
rust=(RUNS/'rust-tests-final.log').read_text()
results=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',rust)]
assert results and sum(r[0] for r in results)==428 and all(r[1:]==(0,0,0,0) for r in results)
python_counts=[]
for name,expected in [('python-tests-final.log',480),('python-tools-final.log',2)]:
 text=(RUNS/name).read_text();counts=re.findall(r'Ran (\d+) tests? in [\d.]+s',text)
 assert counts and int(counts[-1])==expected and re.search(r'^OK\s*$',text,re.M) and not re.search(r'^(FAILED|ERROR:|FAIL:)|\bskipped=',text,re.M)
 python_counts.append(expected)
source=read(RUNS/'source-snapshot.json')
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in source.items())
solver_hash=hashlib.sha256((ROOT/'target/release/soil-fem-3d').read_bytes()).hexdigest()
assert read(OUT/'environment.json')['solver_sha256']==solver_hash
canonical={p.name:read(p) for p in OUT.glob('measurements-*.json')}
assert canonical and all(v.get('passed') is True for v in canonical.values())
assert read(OUT/'input-gate-numerical-preservation.json')['passed']
validation=dict(schema='soil-fem-joint-crack-tip-validation/1',passed=True,base_commit='3fb0f78b31e2f27ea391422086366ada99724400',linux=dict(fmt=True,clippy_all_targets_warnings_denied=True,release_build=True,rust_tests=428,python_tests=480,python_tools_tests=2,failures=0,errors=0,ignored=0,skipped=0,filtered=0),exit_codes=dict(fmt=0,clippy=0,build=0,rust=0,python=0,python_tools=0),source_files=len(source),source_stable_through_final_checks=True,solver_sha256=solver_hash,windows_ci='not certified by this Linux record',logs=dict(fmt='fmt-last.log',clippy='clippy-last.log',build='build-last.log',rust='rust-tests-final.log',python='python-tests-final.log',tools='python-tools-final.log'),earlier_failures_and_cancelled_executions_excluded=True)
write(OUT/'validation.json',validation)
acceptance=dict(schema='soil-fem-joint-crack-tip-acceptance-summary/1',passed=True,scope=dict(topology='explicit matching Tet10 faces and owning elements, including same body; shared declared three-node front only',dry='elastic bulk MC; compressed stick, open, reversed frictional slip; independent all nodes and all material/contact GPs',wet='fully submerged elastic MC closed stick; CONTINUOUS, SOIL, PRESCRIBED; hydrostatic, steady Darcy, one-side removal'),gates=dict(shared_jump_coefficients_cancel_exactly=True,virtual_work_force_and_moment=True,tangent_relative_tolerance=1e-7,opening_hinge_unrestrained_modes=1,independent_elastic_relative_tolerance=1e-7,reassembly_tolerance=1e-10,nonlinear_tolerance=1e-8,linear_tolerance=1e-10,constraint_tolerance_m=1e-10,head_tolerance_m=1e-8,construction_rejection_clean_path_and_separate_cli_restart=True,rehash_tip_face_owner_tampering_rejected=True,network_wide_branch_and_ambiguous_matching_rejected=True,local_h_comparisons_recorded=True,legacy_dry_and_wet_entire_run_exact_except_time_and_solver_sha=True,linux_all_tests_passed=True),p6_complete=False,general_spatial_convergence_accepted=False,remaining=['low preload NC full removal','wet JOINT plastic sliding full-history convergence','general plastic/crack-tip CAD verification','Richards wet JOINT','JOINT plus BIRTH','crack propagation','element-interior termination','accurate tip singularity representation','large calculations and GUI/GPU on user PC'],evidence_json=sorted(canonical),solver_sha256=solver_hash)
write(OUT/'acceptance.json',acceptance)
for name in ['fmt-last.log','clippy-last.log','build-last.log','rust-tests-final.log','python-tests-final.log','python-tools-final.log','python-test-inventory-final.json']:
 shutil.copyfile(RUNS/name,OUT/name)
# Keep every failed/cancelled input and result. Intermediate successful repeats
# retain measurements/logs; the complete final and pre-gate comparison runs stay.
full_dirs={'release-cases','final-cases','legacy-comparison','attempt-01','attempt-02','attempt-03','water-soil-01'}
files=[]
for p in sorted(RUNS.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(RUNS)
 if len(rel.parts)==1 or rel.parts[0] in full_dirs or p.suffix=='.log' or p.name.startswith('measurements'):
  files.append(p)
archive=OUT/'evidence.zip';temp=OUT/'evidence-final.tmp.zip'
with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(RUNS).as_posix())
entries={}
with zipfile.ZipFile(temp) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for name in z.namelist():
  data=z.read(name);original=RUNS/name;assert data==original.read_bytes()
  entries[name]=dict(size=len(data),sha256=hashlib.sha256(data).hexdigest())
assert temp.stat().st_size<100*1024*1024
if archive.exists():archive.unlink()
temp.rename(archive)
write(OUT/'evidence-manifest.json',dict(schema='soil-fem-joint-crack-tip-evidence/1',archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,all_entries_read_back_and_sha_verified=True,entries=entries,selection='All final release runs, all pre-gate comparison runs, old-version comparison, all failures/cancelled logs and available failed inputs/results; other intermediate successful repeats retain measurements/logs.'))
print(json.dumps(dict(validation=validation,evidence_entries=len(entries),evidence_bytes=archive.stat().st_size),indent=2))
