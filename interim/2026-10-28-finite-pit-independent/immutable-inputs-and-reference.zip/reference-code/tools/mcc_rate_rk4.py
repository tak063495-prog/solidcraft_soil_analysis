"""Prototype: reuse identical RK4 trials only within one immutable step start."""
import numpy as np
from functools import lru_cache

def advance_rk4(self,state,displacement,force_rate,count,progress=None):
    if type(count) is not int or count<2:raise ValueError('at least two RK4 steps required')
    terms=self.constitutive_terms
    t=0.;state=state.copy();u=displacement.copy();plastic=np.zeros(len(state),dtype=bool)
    maximum_drift=0.;events=0;accepted=0;minimum_step=1.;step=1/count
    while t<1-1e-13:
        plastic=self.select(state,force_rate,plastic)
        u1,k1,potential0,_=self.rate(state,force_rate,plastic)
        @lru_cache(maxsize=3)
        def trial(h):
            if h==0.:return state,np.zeros_like(u),terms(state,self.parameters)[0],potential0
            u2,k2,_,_=self.rate(state+k1*h/2,force_rate,plastic)
            u3,k3,_,_=self.rate(state+k2*h/2,force_rate,plastic)
            u4,k4,_,_=self.rate(state+k3*h,force_rate,plastic)
            candidate=state+(k1+2*k2+2*k3+k4)*(h/6)
            du=(u1+2*u2+2*u3+u4)*(h/6)
            fy=terms(candidate,self.parameters)[0]
            _,_,ld,_=self.rate(candidate,force_rate,plastic)
            return candidate,du,fy,ld
        h=min(step,1-t);candidate,du,yf,potential=trial(h)
        crossed=(~plastic)&(yf>1e-9)&(potential>1e-12);unloaded=plastic&(potential<-1e-11);next_plastic=plastic.copy()
        if np.any(crossed)|np.any(unloaded):
            from scipy.optimize import brentq
            def margin(length):
                local,_,fy,ld=trial(length)
                score=np.full(len(local),-np.inf)
                score[~plastic]=np.minimum(fy[~plastic]-1e-9,ld[~plastic]-1e-12)
                score[plastic]=-ld[plastic]-1e-11
                return float(np.max(score))
            left=margin(0.);right=margin(h)
            if not left<=0<right:raise ValueError('independent RK4 event bracket is inconsistent')
            h=brentq(margin,0.,h,xtol=min(1e-12,h/2**28),rtol=4*np.finfo(float).eps,maxiter=80)
            candidate,du,yf,ld=trial(h)
            next_plastic|=(~plastic)&(yf>=0.999e-9);next_plastic&=ld>=-0.999e-11
            events+=1
        actual_yield=yf
        drift=float(np.max(np.maximum(actual_yield,0.)))
        if np.any(next_plastic):drift=max(drift,float(np.max(np.abs(actual_yield[next_plastic]))))
        if drift>2e-6:
            step=h/2
            if step<1e-9:raise ValueError('independent RK4 yield drift cannot be controlled without a projection')
            continue
        if h<1e-11:raise ValueError('independent RK4 event integration stalled')
        state=candidate;u+=du;plastic=next_plastic;t+=h;accepted+=1;minimum_step=min(minimum_step,h);maximum_drift=max(maximum_drift,drift)
        if progress is not None and accepted%100==0:progress(t,accepted,events)
    return state,u,dict(integration_method='rk4',event_localizer='brentq_continuous_original_margins',trial_cache='immutable_step_start_lru3',accepted_steps=accepted,events=events,
        maximum_normalized_yield_drift=maximum_drift,minimum_progress_step=minimum_step,
        rate_assemblies=self.calls,independent_pcg_iterations=self.linear_iterations,dense_fallbacks=self.dense_fallbacks)
