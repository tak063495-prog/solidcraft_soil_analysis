import argparse,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from verify_joint_ext_combos import read,dump,solve,exact,without_clock
from plate6_study import inputs as plate_inputs
p=argparse.ArgumentParser();p.add_argument('--solver',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--baseline',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
profiles=[('dry','joint-column-tet10-mesh.json','ground-joint-mc.json','stages-joint-column.json'),('wet','joint-water-column-tet10-mesh.json','ground-joint-water-mc.json','stages-joint-water-column.json'),('tip','joint-crack-tip-mesh.json','ground-joint-crack-tip.json','stages-joint-crack-tip.json')]
cases={n:[read(ROOT/'examples'/v) for v in files] for n,*files in profiles}
m,g,c,_=plate_inputs();cases['mindlin-tri6']=[m,g,c]
report=dict(passed=False,solver_sha256=hashlib.sha256(a.solver.read_bytes()).hexdigest(),profiles=[])
for name,(mesh,ground,case) in cases.items():
 run,_=solve(a.solver,a.output/name,mesh,ground,case)
 if a.baseline:
  baseline=read(a.baseline/name/'run.json')
  def comparable(r):
   r=without_clock(r);r['provenance'].pop('solver_binary_sha256');return exact(r)
  assert comparable(run)==comparable(baseline),name
 report['profiles'].append(dict(name=name,complete=True,exact_except_clock_and_executable_sha=a.baseline is not None))
report['passed']=True;dump(a.output/'legacy.json',report);print(json.dumps(report,indent=2))
