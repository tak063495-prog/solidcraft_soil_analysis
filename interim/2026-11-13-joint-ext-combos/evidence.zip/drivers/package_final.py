from pathlib import Path
import zipfile,hashlib,json,shutil
import numpy as np
out=Path('interim/2026-11-13-joint-ext-combos');final=Path('work/final-3');entries={};handles={}
assert json.loads((final/'measurements.json').read_text())['passed']
assert json.loads((final/'independent.json').read_text())['passed']
try:
 for p in sorted(final.rglob('*')):
  if not p.is_file():continue
  name=p.relative_to(final).as_posix();base=p.name
  restart=base.startswith(('checkpoint-','resumed-','tampered-','rehashed-','resume-','tamper-','rehash-'))
  archive='evidence.zip'
  if restart:archive='restart-'+('tip-a' if name.startswith('tip-history-transfer_force/') else 'tip-b' if name.startswith('tip-history-stress_free/') else 'wet')+'.zip'
  if archive not in handles:handles[archive]=zipfile.ZipFile(out/archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)
  handles[archive].write(p,name);entries.setdefault(archive,{})[name]=hashlib.sha256(p.read_bytes()).hexdigest()
finally:
 for h in handles.values():h.close()
archive='legacy-evidence.zip';entries[archive]={}
with zipfile.ZipFile(out/archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for prefix,source in [('baseline',Path('work/legacy-baseline')),('current',Path('work/legacy-fixed')),('baseline-source',Path('work/baseline'))]:
  for p in sorted(source.rglob('*')):
   if p.is_file():
    name=prefix+'/'+p.relative_to(source).as_posix();z.write(p,name);entries[archive][name]=hashlib.sha256(p.read_bytes()).hexdigest()
 for p,name in [(Path('work/legacy.py'),'drivers/legacy.py'),(Path('work/baseline-source-proof.json'),'baseline-source-proof.json')]:
  z.write(p,name);entries[archive][name]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,name in [(final/'measurements.json','measurements.json'),(final/'independent.json','independent.json'),(Path('work/legacy-fixed/legacy.json'),'legacy.json'),(Path('work/baseline-source-proof.json'),'baseline-source-proof.json')]:shutil.copy2(p,out/name)
for archive,files in entries.items():
 with zipfile.ZipFile(out/archive) as z:
  assert z.testzip() is None
  for name,expected in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected
 print(archive,len(files),(out/archive).stat().st_size)
(out/'evidence-manifest.json').write_text(json.dumps(dict(schema='soil-fem-joint-ext-evidence/1',sha256=entries),indent=2))
r=json.loads((out/'independent.json').read_text());m=json.loads((out/'measurements.json').read_text())
elastic=[f for p in r['profiles'].values() for f in p.get('elastic',{}).get('frames',[])];assembly=[f for p in r['profiles'].values() for f in p['reassembly']['frames']];holding=[f for p in r['profiles'].values() for f in p.get('holding',{}).get('frames',[])]
point=global_error=0.
for folder in final.iterdir():
 if not (folder/'run.json').exists():continue
 run=json.loads((folder/'run.json').read_text());definition=run['case']['joint_system']['joints'][0];kn=definition['material']['normal_stiffness_kpa_m'];kt=definition['material']['tangential_stiffness_kpa_m']
 for frame in run['frames']:
  s=frame['state'];total=0.
  for layout,p in zip(run['joint_integration_points'],s['joints']['points']):
   if not p.get('birth'):continue
   n=np.asarray(p['normal']);q=np.asarray(p['traction_kpa']);normal=n@q;e=normal**2/(2*kn)+np.linalg.norm(q-normal*n)**2/(2*kt)
   balance=p['birth']['initial_energy_kpa_m']+p['endpoint_work_kpa_m']-e-p['plastic_dissipation_kpa_m']-p['numerical_dissipation_kpa_m'];point=max(point,abs(float(balance)))
   if s['joints']['lifecycle'][0]['active'] and all(s['active_elements'][layout[k]] for k in ['owner_a','owner_b']):total+=layout['weight_m2']*balance
  global_error=max(global_error,abs(total))
assert point<1e-10 and global_error<1e-10
result=dict(passed=True,profiles=len(r['profiles']),independent_elastic_profiles=sum('elastic'in p for p in r['profiles'].values()),independent_elastic_frames=len(elastic),reassembly_frames=len(assembly),separate_cli_restarts=sum(len(c.get('lifecycle',{}).get('restarts',[])) for c in m['cases'].values()),rehashed_mutations=sum(len(c.get('lifecycle',{}).get('rehashed_tampering',[])) for c in m['cases'].values()),injected_rejections=sum(c.get('lifecycle',{}).get('injected_rejections',0) for c in m['cases'].values()),maximum_displacement_relative=max(f['displacement_relative'] for f in elastic),maximum_stress_relative=max(f['volume_gp_stress_relative'] for f in elastic),maximum_traction_relative=max(f['contact_gp_traction_relative'] for f in elastic),maximum_reassembled_relative_residual=max(f['reassembled_relative_residual'] for f in assembly),maximum_nodal_load_error_kn=max(f['nodal_load_error_kn'] for f in assembly),maximum_birth_holding_component_error_kn=max(f['all_nodal_holding_load_error_kn'] for f in holding),maximum_point_work_balance_error_kpa_m=point,maximum_global_work_balance_error_kn_m=global_error,richards_coupled_numerical_acceptance=False)
(out/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
