import argparse
from decimal import Decimal, localcontext
import json
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
rows=[]
for path in sorted(args.folder.glob('linear-*.json')):
 v=json.loads(path.read_text());a=np.asarray(v['matrix_columns']).T;rhs=np.array(v['rhs']);x=np.array(v['x'])
 with localcontext() as ctx:
  ctx.prec=70
  aa=[[Decimal.from_float(float(t)) for t in row] for row in a]
  bb=[Decimal.from_float(float(t)) for t in rhs]
  xx=[Decimal.from_float(float(t)) for t in x]
  error=[sum((q*w for q,w in zip(row,xx)),Decimal(0))-b for row,b in zip(aa,bb)]
  residual=float((sum(q*q for q in error)/sum(q*q for q in bb)).sqrt())
  mat=[row.copy() for row in aa];rr=bb.copy();n=len(rr)
  for k in range(n):
   i=max(range(k,n),key=lambda i:abs(mat[i][k]));mat[k],mat[i]=mat[i],mat[k];rr[k],rr[i]=rr[i],rr[k]
   for i in range(k+1,n):
    factor=mat[i][k]/mat[k][k]
    for j in range(k+1,n):mat[i][j]-=factor*mat[k][j]
    rr[i]-=factor*rr[k]
  sol=[Decimal(0)]*n
  for i in reversed(range(n)):sol[i]=(rr[i]-sum((mat[i][j]*sol[j] for j in range(i+1,n)),Decimal(0)))/mat[i][i]
  rounded=[Decimal.from_float(float(t)) for t in sol]
  e2=[sum((q*w for q,w in zip(row,rounded)),Decimal(0))-b for row,b in zip(aa,bb)]
  rounded_residual=float((sum(q*q for q in e2)/sum(q*q for q in bb)).sqrt())
  decimal_unrounded=[sum((q*w for q,w in zip(row,sol)),Decimal(0))-b for row,b in zip(aa,bb)]
  exact_residual=float((sum(q*q for q in decimal_unrounded)/sum(q*q for q in bb)).sqrt())
 rows.append(dict(file=path.name,condition_number=float(np.linalg.cond(a)),rhs_norm=float(np.linalg.norm(rhs)),x_norm=float(np.linalg.norm(x)),reported=v['true_residual'],reported_ordinary=v['ordinary_residual'],reported_compensated=v['compensated_residual'],decimal70_exact_residual_of_stored_x=residual,decimal70_solved_residual=exact_residual,decimal70_solution_rounded_to_f64_residual=rounded_residual))
with args.output.open('x') as f:json.dump(dict(schema='soil-fem-failed-linear-decimal70-diagnostic/1',rows=rows,physical_acceptance=False,passed=False),f,indent=2)
print(json.dumps(rows,indent=2))
