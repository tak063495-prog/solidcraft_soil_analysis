$Tokens=$null
$ParseErrors=$null
[void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path (Get-Location) 'work/reproduce-snippets.ps1'),[ref]$Tokens,[ref]$ParseErrors)
@{errors=@($ParseErrors | ForEach-Object { $_.ToString() }); count=@($ParseErrors).Count} | ConvertTo-Json -Depth 5
if (@($ParseErrors).Count -gt 0) { exit 1 }
