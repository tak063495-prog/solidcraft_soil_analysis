"""Additional default-off, work-only Cholesky observations, unchanged error policy."""
from pathlib import Path
import sys,json,hashlib,subprocess,shutil,difflib
root=Path.cwd();sys.path.insert(0,str(root/'interim/2027-01-08-pc-failure-diagnosis'))
from pcfail_beam_build import generate
out=root/'work/beam-factor-observer';generate(out)
p=out/'src/beams.rs';before=p.read_text();marker='''                    let value = serde_json::json!({'''
addition='''                    let decomposition = c.chol.as_ref().unwrap();
                    let lower = decomposition.l();
                    let mut forward = rhs.clone();
                    lower.solve_lower_triangular_unchecked_mut(&mut forward);
                    let mut replayed = forward.clone();
                    lower.ad_solve_lower_triangular_unchecked_mut(&mut replayed);
                    let value = serde_json::json!({'''
assert before.count(marker)==1
source=before.replace(marker,addition).replace('''                        "rhs": rhs.as_slice(), "interior": interior.as_slice()''','''                        "rhs": rhs.as_slice(), "interior": interior.as_slice(),
                        "column_major_lower": lower.as_slice(), "forward": forward.as_slice(),
                        "replayed": replayed.as_slice()''')
p.write_text(source)
(out/'factor-observation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='work-only/first-observer/src/beams.rs',tofile='work-only/factor-observer/src/beams.rs')))
(out/'factor-binding.json').write_text(json.dumps(dict(first_observer_sha256=hashlib.sha256(before.encode()).hexdigest(),factor_observer_sha256=hashlib.sha256(source.encode()).hexdigest(),production_sha256=hashlib.sha256((root/'src/beams.rs').read_bytes()).hexdigest(),numerical_policy_changed=False,observation_after_original_solution=True),indent=2)+'\n')
shutil.copytree(root/'work/beam-observer/target',out/'target')
command=['cargo','build','--locked','--release','--bin','soil-fem-3d','--manifest-path',str(out/'Cargo.toml')]
result=subprocess.run(command);raise SystemExit(result.returncode)
