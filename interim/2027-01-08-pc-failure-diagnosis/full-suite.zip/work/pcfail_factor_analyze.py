"""Decompose only a saved rejected rounded linear system, in fixed DOF order."""
from pathlib import Path
import json,math,hashlib
import numpy as np
root=Path.cwd();folder=root/'work/roof-factor-n8';path=folder/'first-rejected-factor.json'
v=json.loads(path.read_text());old=json.loads((root/'work/roof-series-v2/n8/first-failed-linear-system.json').read_text());n=v['rows']
def matrix(key):return np.array(np.asarray(v[key]).reshape((n,n),order='F'),dtype=np.longdouble,order='C')
a=matrix('column_major_kqq');l=matrix('column_major_lower');s=np.tril(a)+np.tril(a,-1).T
x=np.array(v['interior'],dtype=np.longdouble);y=np.array(v['forward'],dtype=np.longdouble);b=np.array(v['rhs'],dtype=np.longdouble)
def mv(a,x):return np.sum(a*x[None,:],axis=1,dtype=np.longdouble)
def norm(x):return math.sqrt(math.fsum(float(z)*float(z) for z in x))
def dot(a,b):return math.fsum(float(x)*float(y) for x,y in zip(a,b))
ax=mv(a,x);sx=mv(s,x);ltx=mv(np.ascontiguousarray(l.T),x);lltx=mv(l,ltx);ly=mv(l,y)
parts={'lower_triangle_symmetrization':ax-sx,'rounded_cholesky_factor':sx-lltx,'back_substitution':lltx-ly,'forward_substitution':ly-b}
total=ax-b;combined=sum(parts.values(),np.zeros(n,dtype=np.longdouble));den=max(norm(b),1.)
rows={key:dict(absolute_l2=norm(value),relative_l2=norm(value)/den,signed_inner_product_with_total=dot(value,total),values=[float(z) for z in value]) for key,value in parts.items()}
report=dict(schema='pcfail-cholesky-components/1',diagnostic_only=True,numerical_acceptance=False,
 input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),same_first_rejected_matrix_rhs_and_solution=all(v[k]==old[k] for k in ('rows','factor','relative','tolerance','column_major_kqq','rhs','interior')),
 triangular_replay_exact=np.array_equal(np.array(v['replayed']),np.array(v['interior'])),unknowns=n,
 original_relative=v['relative'],extended_fixed_order_total_relative=norm(total)/den,denominator=den,
 components=rows,closure_max=float(np.max(np.abs(total-combined))),closure_relative=norm(total-combined)/den,
 arithmetic='Stored float64 coefficients promoted exactly to host longdouble; C-order row sums, norms and inner products in fixed-order math.fsum. No Windows arithmetic equivalence claim.',
 interpretation='Signed correlated vectors telescope to the same stored rejected-system residual. Their norms are not additive causal percentages. Factor/triangular solve observations do not certify the pre-rounded assembly or a completed roof.')
(root/'interim/2027-01-08-pc-failure-diagnosis/factor-components-observation.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='components'})
print({key:{k:v for k,v in item.items() if k!='values'} for key,item in rows.items()})
