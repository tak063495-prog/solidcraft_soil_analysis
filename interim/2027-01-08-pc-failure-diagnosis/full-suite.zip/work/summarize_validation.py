"""Select complete, unique outcomes; retain every earlier error and interruption."""
from pathlib import Path
import json,hashlib,re
root=Path.cwd();d=root/'work/validation'
first=json.loads((d/'python-all/results.json').read_text());second=json.loads((d/'python-resume/results.json').read_text());discovery=json.loads((d/'final-discovery.json').read_text());expected=set(discovery['ids'])
if len(second['results'])!=81:raise RuntimeError('class completion not yet finished')
selected={};overridden=[]
for row in first['results']:
 a=row['final'];selected[row['id']]=dict(source='python-all',passed=a['run']==1 and not any(a[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes')))
for row in second['results']:
 a=row['final']
 if sorted(a['executed_ids'])!=sorted(row['assigned_ids']) or sorted(a['passed_ids'])!=sorted(row['assigned_ids']) or any(a[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes')):raise RuntimeError('incomplete/failed final class: '+row['class_name'])
 for name in row['assigned_ids']:
  if name in selected:overridden.append(name)
  selected[name]=dict(source='python-resume',passed=True)
if set(selected)!=expected:raise RuntimeError(('inventory mismatch',sorted(expected-set(selected)),sorted(set(selected)-expected)))
if not all(row['passed'] for row in selected.values()):raise RuntimeError('final failures remain')
proof=dict(ids=sorted(expected),selected={k:selected[k] for k in sorted(selected)},overridden_ids=sorted(overridden),exact_discovery_match=True,duplicate_final_ids=0)
p=d/'python-final-selected.json';p.write_text(json.dumps(proof,indent=2)+'\n')
def raw_first():
 out=dict(test_instances=0,passed=0,test_failures=0,test_errors=0,fixture_errors=0,skipped=0,expected_failures=0,unexpected_successes=0,attempts=0)
 for row in first['results']:
  for a in row['attempts']:
   out['attempts']+=1;out['test_instances']+=a['run'];out['test_failures']+=a['failures'];out['skipped']+=a['skipped'];out['expected_failures']+=a['expected_failures'];out['unexpected_successes']+=a['unexpected_successes']
   if a['run']==0:out['fixture_errors']+=a['errors']
   else:out['test_errors']+=a['errors'];out['passed']+=a['run']-sum(a[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
 return out
def raw_second():
 out=dict(test_instances=0,passed=0,test_failures=0,test_errors=0,fixture_errors=0,skipped=0,expected_failures=0,unexpected_successes=0,class_attempts=0)
 for row in second['results']:
  for a in row['attempts']:
   out['class_attempts']+=1;out['test_instances']+=a['tests_run'];out['passed']+=len(a['passed_ids']);out['test_failures']+=a['failures'];out['skipped']+=a['skipped'];out['expected_failures']+=a['expected_failures'];out['unexpected_successes']+=a['unexpected_successes']
   test_errors=a['tests_run']-len(a['passed_ids'])-sum(a[k] for k in ('failures','skipped','expected_failures','unexpected_successes'))
   out['test_errors']+=test_errors;out['fixture_errors']+=a['errors']-test_errors
 return out
standalone=[]
for p in sorted(d.glob('new-tests-*.log')):
 text=p.read_text();m=re.search(r'Ran (\d+) tests?',text)
 if not m:continue
 run=int(m.group(1));fail=re.search(r'failures=(\d+)',text);err=re.search(r'errors=(\d+)',text);skip=re.search(r'skipped=(\d+)',text)
 failures=int(fail.group(1)) if fail else 0;errors=int(err.group(1)) if err else 0;skipped=int(skip.group(1)) if skip else 0
 standalone.append(dict(log=p.relative_to(root).as_posix(),executed=run,passed=run-failures-errors-skipped,failures=failures,errors=errors,skipped=skipped,counted_in_main=False))
rust=json.loads((d/'rust-counts.json').read_text());inventory=json.loads((d/'rust-inventory.json').read_text())
if not inventory['exact_match'] or inventory['unique_executed']!=467 or any(rust[k] for k in ('failed','ignored','measured','filtered_out')):raise RuntimeError('Rust inventory mismatch')
summary=dict(passed=True,software_tests_passed=True,all_acceptance_complete=False,diagnostic_only=True,pc_executed=False,
 source_base='520cecfce646200505d7fefabaa66ad1bda33f59',scientific_commit='18d54b140bf44b6ca20da2745c3b4dd367437277',
 rust=dict(discovered=467,executed=467,passed=467,failed=0,unexecuted=0,skipped=0,ignored=0,filtered_out=0,measured=0,doc_tests=0,exact_discovered_executed_ids=True),
 python=dict(discovered=len(expected),executed=len(expected),passed=len(expected),failures=0,errors=0,unexecuted=0,skipped=0,expected_failures=0,unexpected_successes=0,duplicate_ids=0,new_tests_included=13,tools_tests_included=2,exact_discovered_executed_ids=True,selected_id_proof_sha256=hashlib.sha256((d/'python-final-selected.json').read_bytes()).hexdigest()),
 rust_checks={'fmt':dict(command=['cargo','fmt','--all','--check'],exit_code=0),'clippy':dict(command=['cargo','clippy','--locked','--all-targets','--','-D','warnings'],exit_code=0),'build':dict(command=['cargo','build','--locked','--release','--all-targets'],exit_code=0),'all_targets':dict(command=['cargo','test','--locked','--release','--all-targets'],exit_code=0),'doc':dict(command=['cargo','test','--locked','--release','--doc'],exit_code=0)},
 initial_python_partial=dict(discovered=len(first['discovered']),completed_finalized_ids=len(first['results']),not_finalized=len(first['discovered'])-len(first['results']),interrupted=1,process_exit_code=130,raw_attempt_counts=raw_first(),reason='retain successes and resume with standard shared class fixtures; interrupted ID is recorded separately'),
 resumed_python=dict(discovered=len(second['discovered_ids']),assigned=len(second['selected_ids']),classes=len(second['results']),final_executed=sum(r['final']['tests_run'] for r in second['results']),final_passed=sum(len(r['final']['passed_ids']) for r in second['results']),raw_attempt_counts=raw_second(),overridden_initial_ids=sorted(overridden)),
 standalone_preparation_and_regressions=standalone,
 source_binding=dict(scientific='final-code-binding.json',validation='validation-code-binding.json',validation_binding_captured='during resumed suite; not claimed as pre-start freeze of the initial pass',intentional_code_changes_after_initial_pass=['tests/test_ci_timeout_configuration.py: sparse template count 10 -> 11','P6 inventory append and auditor SHA pin'],affected_checks_reexecuted=True),
 prior_pc_failures=6,prior_pc_skipped_unexecuted=['b02-n8','b02-n16','a04-steps-32','a04-steps-64','a04-steps-128'],
 windows_ci_after_push='未確定',numerical_acceptance_all_met=False,
 post_registration=dict(report='post-registration.json',separate_from_main_counts=True),
 notes=['Missing archived dependencies produced retained nonzero trials before exact selective Git blob retrieval. No missing evidence was counted as a pass or skip.','Raw fixture errors with zero started tests are counted separately from test errors.','The initial interrupted test has no fabricated success/failure outcome.','Large legacy NC evidence is SHA-verified replay in the cloud, not a new PC calculation or numerical acceptance.'])
(d/'summary-base.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary['python']));print('first raw',raw_first(),'resumed raw',raw_second())
