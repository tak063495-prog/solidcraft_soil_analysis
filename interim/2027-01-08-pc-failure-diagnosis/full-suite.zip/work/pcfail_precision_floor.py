"""Observe stored failed reference iterates; no new solve or tolerance change."""
from pathlib import Path
import json,numpy as np,hashlib
root=Path.cwd();rows=[]
for mode in ('binary64','state64-flux80'):
 p=root/'work/hydraulic-final'/mode/'failed-state.npz';z=np.load(p)
 ratio=np.abs(z['r'])/(1e-16+1e-8*z['scale']);i=int(np.argmax(ratio))
 spacing=np.abs(np.spacing(z['x']));ulps=np.abs(z['dx'])/spacing
 rows.append(dict(mode=mode,failed_state_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    critical_component=i,critical_residual=float(z['r'][i]),critical_scale=float(z['scale'][i]),
    original_scaled_residual=float(ratio[i]),original_absolute_target_at_component=float(.01*(1e-16+1e-8*z['scale'][i])),
    unknowns=len(z['x']),maximum_newton_update_in_state_ulps=float(np.max(ulps)),
    updates_smaller_than_half_state_ulp=int(np.count_nonzero(ulps<.5)),
    updates_smaller_than_one_state_ulp=int(np.count_nonzero(ulps<1)),
    interpretation='ULP is evaluated at the stored failed iterate; not an error bound or a relaxed stopping test.'))
out=dict(schema='pcfail-stored-precision-floor/1',diagnostic_only=True,numerical_acceptance=False,solver_runs=0,rows=rows)
(root/'interim/2027-01-08-pc-failure-diagnosis/precision-floor-observation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
