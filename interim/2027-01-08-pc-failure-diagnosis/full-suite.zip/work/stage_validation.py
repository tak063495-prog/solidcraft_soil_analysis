"""Package task logs and supplementary observations; never include old archives."""
from pathlib import Path
import shutil,hashlib,json,zipfile,subprocess
root=Path.cwd();dest=root/'work/validation-seal-source';dest.mkdir(exist_ok=False)
def copy(path,relative=None):
 p=root/path;target=dest/(relative or path);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for p in (root/'work/validation').rglob('*'):
 if p.is_file():copy(p.relative_to(root))
for name in ('required-pins.json','pin-fetch.log','ancestry-fetch.log','checkout.log','checkout-retry.log','test-cache-releases.json','c01-prefetch.json','c01-prefetch.log','mean-evidence-prefetch.json','mean-evidence-prefetch.log','push-dry-run.log','reproduce-syntax.json','reproduce-syntax-final.json','reproduce-syntax.stderr','reproduce-snippets.ps1','parse-reproduce.ps1','factor-build.log','factor-analysis.log','factor-decimal-run.log','p601-after-scientific.json'):
 if (root/'work'/name).is_file():copy(Path('work')/name)
for name in ('run_python_all.py','run_python_resume.py','prepare_pins.py','prefetch_c01.py','prefetch_mean.py','trim_test_cache.py','summarize_validation.py','pcfail_factor_build.py','pcfail_factor_analyze.py','pcfail_factor_decimal.py','pcfail_precision_floor.py','pcfail_roof_cutback_algebra.py','stage_scientific.py','stage_validation.py','build_b02_direct.py','beam_series.py'):
 copy(Path('work')/name)
for label in ('roof-factor-n8','factor-decimal-process','b02-production-cli-scope'):
 for p in (root/'work'/label).rglob('*'):
  if p.is_file():copy(p.relative_to(root))
for name in ('binding.json','factor-binding.json','observation.patch','factor-observation.patch','src/beams.rs','Cargo.toml','Cargo.lock','rust-toolchain.toml'):
 copy(Path('work/beam-factor-observer')/name)
for mode in ('binary64','state64-flux80'):
 for name in ('failed-state.npz','observation.json'):copy(Path('work/hydraulic-final')/mode/name)
for name in ('installation.json','hashes.sha256'):copy(Path('work/powershell')/name)
for name in ('factor-components-observation.json','factor-decimal-observation.json','precision-floor-observation.json','roof-cutback-algebra.json','final-code-binding.json','validation-code-binding.json'):
 copy(Path('interim/2027-01-08-pc-failure-diagnosis')/name)
vendor=next(Path('/workspace/.cargo/registry/src').glob('*/nalgebra-0.34.2/src/linalg/cholesky.rs'))
target=dest/'vendor-primary-source/nalgebra-0.34.2-cholesky.rs';target.parent.mkdir();shutil.copy2(vendor,target)
meta=dict(source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),vendor_cholesky_sha256=hashlib.sha256(vendor.read_bytes()).hexdigest(),production_cli_sha256=hashlib.sha256((root/'target/release/soil-fem-3d').read_bytes()).hexdigest(),factor_observer_sha256=hashlib.sha256((root/'work/beam-factor-observer/target/release/soil-fem-3d').read_bytes()).hexdigest(),windows_ci_after_push='unconfirmed',pc_calculations_executed=False)
(dest/'package-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
h=root/'interim/2027-01-08-pc-failure-diagnosis';archive=h/'full-suite.zip';entries={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(dest.rglob('*')):
  if not p.is_file():continue
  name=p.relative_to(dest).as_posix();z.write(p,name)
  with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  entries[name]=dict(size=p.stat().st_size,sha256=digest)
with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
index=dict(schema='pcfail-validation-evidence/1',archive='full-suite.zip',size=archive.stat().st_size,sha256=digest,entries=entries)
with (h/'full-suite-index.json').open('x') as f:json.dump(index,f,indent=2);f.write('\n')
# Independent reread of all saved bytes, not an assertion about numerical acceptance.
with zipfile.ZipFile(archive) as z:
 if len(z.namelist())!=len(set(z.namelist())) or set(z.namelist())!=set(entries):raise ValueError('member inventory differs')
 for name,record in entries.items():
  with z.open(name) as f:d=hashlib.file_digest(f,'sha256').hexdigest()
  if d!=record['sha256']:raise ValueError(name)
(h/'full-suite-verification.json').write_text(json.dumps(dict(all_members_verified=True,entries=len(entries),archive_sha256=digest,numerical_acceptance=False),indent=2)+'\n')
print('sealed validation',archive.stat().st_size,'bytes',len(entries),'entries')
