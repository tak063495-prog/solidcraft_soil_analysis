"""Remove only task-downloaded sparse cache copies, preserving Git evidence blobs."""
import json,subprocess,hashlib
from pathlib import Path
root=Path.cwd();p=root/'work/validation/python-all/fetched.json'
rows=json.loads(p.read_text());active=Path(rows[-1]['path']).parent
protected={Path('interim')/x for x in ['2026-12-25-b01-curved-tri6-cause-diagnosis','2026-12-03-tri6-curved-b01','2026-12-20-a01-joint-combo-cause-diagnosis','2026-11-23-joint-combo-extension']}
log=root/'work/test-cache-releases.json';released=json.loads(log.read_text()) if log.exists() else []
for row in rows:
 p=root/row['path']
 if not p.exists() or Path(row['path']).parent in protected|{active}:continue
 with p.open('rb') as f:
  h=hashlib.sha1(('blob '+str(p.stat().st_size)+'\0').encode())
  for raw in iter(lambda:f.read(1024*1024),b''):h.update(raw)
 if h.hexdigest()!=row['blob']:raise ValueError('fetched copy changed; retain '+str(p))
 subprocess.run(['git','cat-file','-e',row['blob']],check=True)
 p.unlink();subprocess.run(['git','update-index','--skip-worktree','-z','--stdin'],input=row['path'].encode()+b'\0',check=True);released.append(row)
log.write_text(json.dumps(released,indent=2)+'\n');print('released newly fetched cache copies',len(released),'active',active)
