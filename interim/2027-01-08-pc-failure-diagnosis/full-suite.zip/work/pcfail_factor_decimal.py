"""Portable Decimal dot-product cross-check; no new solve or acceptance change."""
from pathlib import Path
import json,math,hashlib,time
from decimal import Decimal as D,localcontext
root=Path.cwd();p=root/'work/roof-factor-n8/first-rejected-factor.json';v=json.loads(p.read_text());n=v['rows'];a=v['column_major_kqq'];l=v['column_major_lower'];b=v['rhs'];x=v['interior'];y=v['forward']
def norm(values):return math.sqrt(math.fsum(float(z)*float(z) for z in values))
def calculate(precision):
 start=time.monotonic()
 with localcontext() as ctx:
  ctx.prec=precision
  xx=list(map(D.from_float,x));yy=list(map(D.from_float,y));bb=list(map(D.from_float,b));zero=D(0)
  ltx=[sum((D.from_float(l[j*n+k])*xx[k] for k in range(j,n) if l[j*n+k]!=0),zero) for j in range(n)]
  parts={name:[] for name in ('lower_triangle_symmetrization','rounded_cholesky_factor','back_substitution','forward_substitution')};total=[];closure=[]
  for i in range(n):
   ax=sum((D.from_float(a[j*n+i])*xx[j] for j in range(n) if a[j*n+i]!=0),zero)
   asym=sum(((D.from_float(a[j*n+i])-D.from_float(a[i*n+j]))*xx[j] for j in range(i+1,n) if a[j*n+i]!=a[i*n+j]),zero)
   coeff=[D.from_float(l[j*n+i]) for j in range(i+1)]
   lltx=sum((c*z for c,z in zip(coeff,ltx)),zero);ly=sum((c*z for c,z in zip(coeff,yy)),zero)
   values=[asym,ax-asym-lltx,lltx-ly,ly-bb[i]]
   for key,z in zip(parts,values):parts[key].append(z)
   total.append(ax-bb[i]);closure.append(total[-1]-sum(values,zero))
  denominator=max(norm(bb),1.);stats={key:dict(absolute_l2=norm(vals),relative_l2=norm(vals)/denominator) for key,vals in parts.items()}
  report=dict(decimal_precision=precision,relative_total=norm(total)/denominator,components=stats,closure_max=float(max(map(abs,closure))),elapsed_seconds=time.monotonic()-start)
  return report,{key:[float(z) for z in vals] for key,vals in parts.items()}
reports=[];vectors=[]
for precision in (50,80):
 r,f=calculate(precision);reports.append(r);vectors.append(f);print(r,flush=True)
comparison={key:dict(exact_float64_component_mismatches=sum(x!=y for x,y in zip(vectors[0][key],vectors[1][key])),maximum_float64_component_difference=max(abs(x-y) for x,y in zip(vectors[0][key],vectors[1][key])),float64_norms_equal=reports[0]['components'][key]==reports[1]['components'][key]) for key in vectors[0]}
out=dict(schema='pcfail-cholesky-decimal/1',diagnostic_only=True,numerical_acceptance=False,input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),solver_runs=0,precision_cross=reports,float64_comparison=comparison,component_vectors_at_80_digits=vectors[1],interpretation='Same rounded coefficients; fixed DOF order Decimal products/sums. Norms use fixed-order math.fsum after explicit float64 conversion. No new acceptance tolerance.')
(root/'interim/2027-01-08-pc-failure-diagnosis/factor-decimal-observation.json').write_text(json.dumps(out,indent=2)+'\n');print(comparison,flush=True)
