from pathlib import Path
import os,subprocess,sys,json
root=Path.cwd();sys.path.insert(0,str(root/'interim/2027-01-08-pc-failure-diagnosis'))
from pcfail_run import run
base=root/'work/roof-series-v2';base.mkdir(exist_ok=False)
solver=root/'work/beam-observer/target/release/soil-fem-3d'
for n in (2,4,8):
 folder=base/f'n{n}'
 subprocess.run([sys.executable,'interim/2026-12-03-tri6-curved-b01/b01_cases.py',str(folder),'--kind','roof','--n',str(n),'--steps','4'],check=True)
 os.environ['PCFAIL_BEAM_TRACE']=str(folder/'first-failed-linear-system.json')
 result=run([str(solver),'solve-stages',*[str(folder/(k+'.json')) for k in ('mesh','ground','stages','run')]],folder/'process',timeout=1800)
 print(n,result,flush=True)
