"""Full discovered suite with explicit retained missing-blob failures and retries.
Only the exact missing tracked archive is materialized, then retried unchanged.
"""
import json,os,re,subprocess,sys,time,unittest
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
from run_ci_python_evidence_shards import discover
out=root/'work/validation/python-all';out.mkdir(parents=True,exist_ok=False)
tests,groups=discover(root);results=[];fetched=[]
class Result(unittest.TextTestResult):
 def addError(self,test,err):
  self.missing=getattr(err[1],'filename',None)
  super().addError(test,err)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for i,name in enumerate(sorted(tests)):
 attempts=[]
 for retry in range(100):
  test=unittest.TestSuite([tests[name]])
  with (out/(str(i)+'-'+str(retry)+'.log')).open('w') as log:
   start=time.monotonic();r=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(test)
  attempt=dict(run=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped),expected_failures=len(r.expectedFailures),unexpected_successes=len(r.unexpectedSuccesses),elapsed_seconds=time.monotonic()-start)
  attempts.append(attempt)
  missing=getattr(r,'missing',None)
  if not missing:break
  p=Path(missing).resolve()
  if not p.is_relative_to(root) or not p.is_relative_to(root/'interim') or not any(s in p.name for s in ('.zip','.tar','.gz','.part','.npz','.7z')):break
  rel=p.relative_to(root).as_posix()
  oid=subprocess.run(['git','rev-parse','--verify',head+':'+rel],capture_output=True,text=True)
  if oid.returncode:break
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:
   got=subprocess.run(['git','show',head+':'+rel],stdout=f,stderr=subprocess.PIPE)
  if got.returncode:raise RuntimeError((rel,got.stderr.decode()))
  fetched.append(dict(path=rel,blob=oid.stdout.strip(),bytes=p.stat().st_size))
  (out/'fetched.json').write_text(json.dumps(fetched,indent=2))
 results.append(dict(id=name,attempts=attempts,final=attempts[-1]))
 (out/'results.json').write_text(json.dumps(dict(discovered=sorted(tests),groups=groups,results=results),indent=2))
 print(i+1,'/',len(tests),name,attempts[-1],flush=True)
