import json,subprocess,hashlib,os,tempfile
from pathlib import Path
root=Path.cwd();rows=[]
for label in ['2026-12-11-c01-global-step-control','2026-12-12-c01-switch-event-localization','2026-12-13-c01-cause-diagnosis']:
 folder=root/'interim'/label;x=json.loads((folder/'archive-index.json').read_text())
 for part in x['parts']:
  p=folder/part['file'];rel=p.relative_to(root).as_posix()
  if p.exists():continue
  oid=subprocess.check_output(['git','rev-parse','HEAD:'+rel],text=True).strip()
  rows.append(dict(path=rel,blob=oid,bytes=part['bytes'],sha256=part['sha256']))
print('selected missing C01 parts',len(rows),flush=True)
if rows:subprocess.run(['git','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin','--stdin'],input='\n'.join(r['blob'] for r in rows)+'\n',text=True,check=True)
for row in rows:
 p=root/row['path']
 if p.exists():continue
 with tempfile.NamedTemporaryFile(dir=root/'work',delete=False) as f:
  tmp=Path(f.name);subprocess.run(['git','show',row['blob']],stdout=f,check=True)
 with tmp.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 if digest!=row['sha256'] or tmp.stat().st_size!=row['bytes']:raise ValueError(row['path'])
 if p.exists():tmp.unlink()
 else:os.rename(tmp,p)
 print(row['path'],flush=True)
(root/'work/c01-prefetch.json').write_text(json.dumps(rows,indent=2)+'\n')
