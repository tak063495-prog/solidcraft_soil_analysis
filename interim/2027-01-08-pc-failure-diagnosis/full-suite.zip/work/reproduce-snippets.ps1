Set-Location D:\Work
$ErrorActionPreference='Stop'
$Stamp=(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
$Store="D:\Work\PCFAIL-objects-$Stamp"
$Tree="D:\Work\PCFAIL-$Stamp"
$Branch='codex/plastic-spatial-convergence'
$Commit='18d54b140bf44b6ca20da2745c3b4dd367437277'
git clone --filter=blob:none --depth=1 --single-branch --branch $Branch --no-checkout https://github.com/tak063495-prog/solidcraft_soil_analysis.git $Store
if ($LASTEXITCODE -ne 0) { throw '限定clone失敗' }
git -C $Store fetch --filter=blob:none --depth=1 --no-tags origin $Commit
if ($LASTEXITCODE -ne 0) { throw '固定commit取得失敗' }
git -C $Store worktree add --detach --no-checkout $Tree $Commit
if ($LASTEXITCODE -ne 0) { throw '別worktree作成失敗' }
git -C $Tree config core.autocrlf false
git -C $Tree sparse-checkout init --no-cone
$Patterns=@('/*','!/interim/**/*.zip','!/interim/**/*.zip.part*','!/interim/**/*.tar',
 '!/interim/**/*.tar.gz','!/interim/**/*.tar.part*','!/interim/**/*.tar.gz.part*',
 '!/interim/**/*.tgz','!/interim/**/*.gz','!/interim/**/*.7z','!/interim/**/*.npz','!/interim/**/*.part*')
$Patterns | git -C $Tree sparse-checkout set --no-cone --stdin
if ($LASTEXITCODE -ne 0) { throw 'sparse設定失敗' }
git -C $Tree read-tree --reset -u HEAD
if ($LASTEXITCODE -ne 0) { throw 'sparseソース配置失敗' }
Set-Location $Tree
if ((git rev-parse HEAD).Trim() -ne $Commit) { throw '固定SHA不一致' }
$Diag='interim/2027-01-08-pc-failure-diagnosis'
$Py="$Tree\.venv\Scripts\python.exe"
$Out="$Tree\runs\pcfail-$Stamp"
New-Item -ItemType Directory $Out | Out-Null
$env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'; $env:OMP_NUM_THREADS='1'
$env:CARGO_BUILD_JOBS='2'; $env:RUST_TEST_THREADS='2'
$env:PYTHONUTF8='1'; $env:PYTHONIOENCODING='utf-8'
py -3.13 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python3.13 venv失敗' }
& $Py -m pip install --disable-pip-version-check -r requirements-reference.lock.txt
if ($LASTEXITCODE -ne 0) { throw '固定依存の導入失敗' }
rustup toolchain install 1.99.1 --profile minimal --component rustfmt --component clippy
if ($LASTEXITCODE -ne 0) { throw 'Rust1.99.1導入失敗' }
rustc --version --verbose
& $Py -c "import numpy as n; print('longdouble',n.finfo(n.longdouble),'float64',n.finfo(n.float64))" | Out-File "$Out\precision.txt" -Encoding utf8
& $Py "$Diag/pcfail_run.py" --output "$Out/build-process" --timeout 7500 --memory-gib 8 -- cargo build --locked --release --all-targets
if ($LASTEXITCODE -ne 0) { throw 'build未完了。新規出力を保持' }

& $Py "$Diag/pcfail_evidence.py" --profile b01 --output "$Out/b01-before-fetch"
# 終了2: evidence-status.jsonの全missing partを保持。終了1:破損等を保持して原因確認。

foreach ($EvidenceProfile in @('b01','b01-cli','a01','a01-old')) {
  & $Py "$Diag/pcfail_run.py" --output "$Out/fetch-$EvidenceProfile-process" --timeout 1800 --memory-gib 4 -- `
    $Py "$Diag/pcfail_evidence.py" --profile $EvidenceProfile --fetch-commit $Commit --output "$Out/fetch-$EvidenceProfile"
  if ($LASTEXITCODE -ne 0) { Write-Host "$EvidenceProfile の証拠は未達。記録を保持し、次の独立群を確認する" }
}
& $Py "$Diag/pcfail_run.py" --output "$Out/b01-evidence-process" --timeout 1800 --memory-gib 4 -- `
  $Py "$Diag/pcfail_evidence.py" --profile b01 --output "$Out/b01-evidence" --extract "$Out/b01-unsealed"
& $Py "$Diag/pcfail_run.py" --output "$Out/a01-verify-process" --timeout 1800 --memory-gib 8 -- `
  $Py "$Diag/pcfail_evidence.py" --profile a01 --output "$Out/a01-verify"
& $Py "$Diag/pcfail_run.py" --output "$Out/a01-old-process" --timeout 3600 --memory-gib 8 -- `
  $Py "$Diag/pcfail_evidence.py" --profile a01-old --output "$Out/a01-old" --extract "$Out/a01-old-subset"

& $Py "$Diag/pcfail_run.py" --output "$Out/b01-remeasure-process" --timeout 1800 --memory-gib 4 -- `
  $Py interim/2026-12-25-b01-curved-tri6-cause-diagnosis/b01cause_report.py `
  --formal "$Out/b01-unsealed/b01cause-formal" --output "$Out/b01-remeasured.json"

& $Py "$Diag/pcfail_run.py" --output "$Out/b01-cli-process" --timeout 1800 --memory-gib 4 -- `
  $Py "$Diag/pcfail_cli.py" --solver "$Tree/target/release/soil-fem-3d.exe" --output "$Out/b01-cli"

& $Py "$Diag/pcfail_run.py" --output "$Out/b02-observer-build-process" --timeout 7500 --memory-gib 8 -- `
  $Py interim/2026-12-01-tri6-offset-composite-b02/build_observer.py "$Tree/work/pcfail-b02-observer-$Stamp"
if ($LASTEXITCODE -ne 0) { throw '観測器build未完了' }
& $Py "$Diag/pcfail_run.py" --output "$Out/b02-n4-process" --timeout 7500 --memory-gib 8 -- `
  $Py "$Diag/pcfail_b02.py" --output "$Out/b02-n4" --observer "$Tree/target/release/b02-observer.exe" `
  --cli "$Tree/target/release/soil-fem-3d.exe" --steps 4

# 条件を満たしたときだけ、まずn8（目安20–90分/1–6GiB）。
& $Py "$Diag/pcfail_run.py" --output "$Out/b02-n8-process" --timeout 7500 --memory-gib 8 -- `
  $Py "$Diag/pcfail_b02.py" --output "$Out/b02-n8" --observer "$Tree/target/release/b02-observer.exe" `
  --cli "$Tree/target/release/soil-fem-3d.exe" --steps 8
# n8が上の条件を満たした場合だけn16（目安30–120分/1–6GiB）。
& $Py "$Diag/pcfail_run.py" --output "$Out/b02-n16-process" --timeout 7500 --memory-gib 8 -- `
  $Py "$Diag/pcfail_b02.py" --output "$Out/b02-n16" --observer "$Tree/target/release/b02-observer.exe" `
  --cli "$Tree/target/release/soil-fem-3d.exe" --steps 16

$Roof="$Out/roof-n8"
& $Py interim/2026-12-03-tri6-curved-b01/b01_cases.py $Roof --kind roof --n 8 --steps 4
if ($LASTEXITCODE -ne 0) { throw '入力生成失敗' }
& $Py "$Diag/pcfail_run.py" --output "$Out/roof-n8-process" --timeout 1800 --memory-gib 8 -- `
  "$Tree/target/release/soil-fem-3d.exe" solve-stages "$Roof/mesh.json" "$Roof/ground.json" "$Roof/stages.json" "$Roof/run.json"

& $Py "$Diag/pcfail_run.py" --output "$Out/a04-matrix-process" --timeout 7500 --memory-gib 8 -- `
  $Py interim/2026-12-23-a04-richards-wet-joint-cause-diagnosis/a04cause_driver.py --output "$Out/a04-matrix"
# 原因観測だけを追加する場合。元の反復条件を変えない独立入力専用診断。
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-precision-process" --timeout 1800 --memory-gib 4 -- `
  $Py "$Diag/pcfail_hydraulic.py" --output "$Out/a04-precision" --steps 4 --precision host

# まず32のみ（目安5–20分/1–2GiB）。
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-32-process" --timeout 7500 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/study.py --output "$Out/a04-32" --steps 32
if ($LASTEXITCODE -ne 0) { throw 'a04-32未完了。次水準へ進まない' }
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-32-audit-process" --timeout 1800 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/audit.py --run "$Out/a04-32"
if ($LASTEXITCODE -ne 0) { throw 'a04-32の元ゲート監査未達。次水準へ進まない' }
# 32完走・元ゲート・予算を確認後だけ64（目安10–40分/1–2GiB）。
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-64-process" --timeout 7500 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/study.py --output "$Out/a04-64" --steps 64
if ($LASTEXITCODE -ne 0) { throw 'a04-64未完了。次水準へ進まない' }
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-64-audit-process" --timeout 1800 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/audit.py --run "$Out/a04-64"
if ($LASTEXITCODE -ne 0) { throw 'a04-64の元ゲート監査未達。次水準へ進まない' }
# 64の同条件確認後だけ128（目安20–80分/1–3GiB）。
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-128-process" --timeout 7500 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/study.py --output "$Out/a04-128" --steps 128
if ($LASTEXITCODE -ne 0) { throw 'a04-128未完了。次水準へ進まない' }
& $Py "$Diag/pcfail_run.py" --output "$Out/a04-128-audit-process" --timeout 1800 --memory-gib 8 -- `
  $Py interim/2026-11-29-richards-wet-joint-a04/audit.py --run "$Out/a04-128"
if ($LASTEXITCODE -ne 0) { throw 'a04-128の元ゲート監査未達。次水準へ進まない' }

$NewEvidenceCode="import sys,json; from pathlib import Path; sys.path.insert(0,'$Diag'); from pcfail_evidence import fetch,verify; f=Path('$Diag').resolve(); m=json.loads((f/'archive-index.json').read_text(encoding='utf-8')); fetch(f,m,'$Commit'); r=verify(f,m); print(r); assert r['status']=='verified'"
& $Py "$Diag/pcfail_run.py" --output "$Out/new-evidence-process" --timeout 1800 --memory-gib 4 -- `
  $Py -c $NewEvidenceCode
if ($LASTEXITCODE -ne 0) { throw '新試験用の4partが未達。欠落を試験成功へ変換しない' }
& $Py "$Diag/pcfail_run.py" --output "$Out/new-tests-process" --timeout 1800 --memory-gib 4 -- `
  $Py -m unittest discover -s tests -p test_pc_failure_diagnosis.py -v
