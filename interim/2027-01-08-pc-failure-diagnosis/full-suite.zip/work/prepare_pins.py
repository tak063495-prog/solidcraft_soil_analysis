import json,tomllib,subprocess,re,os
from pathlib import Path
root=Path.cwd();pins=set()
for p in [root/'interim/2026-12-10-ci-p601-inventory-fix/inventory.toml',root/'interim/2026-12-06-p6-01-status-reconciliation/ledger.json']:
 x=tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
 def walk(v):
  if isinstance(v,dict):
   for k,x in v.items():
    if k in ('commit','base_commit') and isinstance(x,str) and re.fullmatch('[a-f0-9]{40}',x):pins.add(x)
    walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(x)
for p in [root/'interim/2026-12-06-p6-01-status-reconciliation/audit_status.py',*root.glob('interim/*p6*/*.py')]:
 pins.update(re.findall(r"BASE\s*=\s*['\"]([a-f0-9]{40})",p.read_text()))
env=dict(os.environ,GIT_NO_LAZY_FETCH='1');missing=[]
for pin in sorted(pins):
 if subprocess.run(['git','cat-file','-e',pin+'^{commit}'],stderr=subprocess.DEVNULL,env=env).returncode:missing.append(pin)
Path('work/required-pins.json').write_text(json.dumps({'all':sorted(pins),'missing':missing},indent=2))
print(len(pins),len(missing),flush=True)
if missing:subprocess.run(['git','fetch','--no-tags','--depth=1','--filter=blob:none','origin','--stdin'],input='\n'.join(missing)+'\n',text=True,check=True)
