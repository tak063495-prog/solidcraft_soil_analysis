from pathlib import Path
import json,hashlib,subprocess,tempfile,os
root=Path.cwd();folder=root/'interim/2026-11-10-nc-mean-stress-release';index=json.loads((folder/'archive-sha256.json').read_text());rows=[]
for item in index['parts']:
 p=folder/item['name'];rel=p.relative_to(root).as_posix()
 if p.exists():continue
 oid=subprocess.check_output(['git','rev-parse','HEAD:'+rel],text=True).strip()
 rows.append(dict(path=rel,blob=oid,size=item['size'],sha256=item['sha256']))
print('selective indexed mean-evidence parts',len(rows),'bytes',sum(r['size'] for r in rows),flush=True)
if rows:subprocess.run(['git','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin','--stdin'],input='\n'.join(r['blob'] for r in rows)+'\n',text=True,check=True)
for row in rows:
 p=root/row['path']
 if p.exists():continue
 with tempfile.NamedTemporaryFile(dir=root/'work',delete=False) as stream:
  temp=Path(stream.name);subprocess.run(['git','show',row['blob']],stdout=stream,check=True)
 with temp.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 if temp.stat().st_size!=row['size'] or digest!=row['sha256']:raise ValueError(row['path'])
 if p.exists():temp.unlink()
 else:os.rename(temp,p)
(root/'work/mean-evidence-prefetch.json').write_text(json.dumps(rows,indent=2)+'\n')
pid=int((root/'work/paused-python-runner.pid').read_text());os.kill(pid,18)
print('resumed class runner',pid,flush=True)
