from pathlib import Path
import shutil,json,hashlib
root=Path.cwd();dest=root/'work/scientific-seal-source';dest.mkdir()
for label in ['b02-n4-final','roof-series-v2','roof-series','hydraulic-final','a04-native-final','b01-cli-final']:
 folder=root/'work'/label
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or any(v in p.relative_to(folder).parts for v in ('bin','solver')):continue
  target=dest/label/p.relative_to(folder);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for name in ['roof-linear-observation.json','beam-build.log','beam-series.log','beam-series-v2.log','b02-n4-final.log','b02-build-direct.log']:
 shutil.copy2(root/'work'/name,dest/name)
for name in ('binding.json','observation.patch','src/beams.rs'):
 source=root/'work/beam-observer'/name;target=dest/'beam-observer'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for p in (root/'work/b02-direct').glob('*.json'):shutil.copy2(p,dest/p.name)
for p in (root/'work/selected-evidence-final').glob('*-verified.json'):shutil.copy2(p,dest/p.name)
for name in ('new-tests-first.log','new-tests-fixed.log'):
 target=dest/'retained-test-preparation'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(root/'work/validation'/name,target)
binaries={}
for label,p in [('production-cli',root/'target/release/soil-fem-3d'),('beam-observer',root/'work/beam-observer/target/release/soil-fem-3d'),('b02-observer',root/'work/b02-direct/b02-observer')]:
 with p.open('rb') as f:binaries[label]=hashlib.file_digest(f,'sha256').hexdigest()
(dest/'binary-binding.json').write_text(json.dumps(binaries,indent=2)+'\n')
