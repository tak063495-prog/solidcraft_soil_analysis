"""Resume the complete inventory with normal shared class fixtures and sparse blobs."""
import hashlib,json,os,subprocess,sys,time,unittest
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
from run_ci_python_evidence_shards import discover
out=root/'work/validation/python-resume';out.mkdir(exist_ok=False)
tests,groups=discover(root)
previous=json.loads((root/'work/validation/python-all/results.json').read_text())
completed={r['id'] for r in previous['results'] if not any(r['final'][k] for k in ('errors','failures','skipped','expected_failures','unexpected_successes'))}
changed_class='test_ci_timeout_configuration.CITimeoutConfiguration.'
selected=[name for name in sorted(tests) if name not in completed or name.startswith(changed_class)]
classes={}
for name in selected:classes.setdefault(name.rsplit('.',1)[0],[]).append(name)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();fetches=[];results=[]
class Result(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.executed=[];self.passed=[];self.missing=[]
 def startTest(self,test):self.executed.append(test.id());super().startTest(test)
 def addSuccess(self,test):self.passed.append(test.id());super().addSuccess(test)
 def addError(self,test,err):
  name=getattr(err[1],'filename',None)
  if name:self.missing.append(str(name))
  super().addError(test,err)
def fetch_missing(missing):
 p=Path(missing).resolve()
 if not p.is_relative_to(root/'interim') or not any(s in p.name for s in ('.zip','.tar','.gz','.part','.npz','.7z')):return False
 targets=[p]
 # A whole indexed split archive is the dependency; fetch its listed parts once.
 for indexpath in sorted(p.parent.glob('*.json')):
  try:index=json.loads(indexpath.read_text(encoding='utf-8'))
  except (ValueError,UnicodeError):continue
  if not isinstance(index,dict) or not isinstance(index.get('parts'),list):continue
  items=index['parts'];candidates=[];size=0
  for item in items:
   if not isinstance(item,dict):break
   name=item.get('name',item.get('file',item.get('path')))
   if not isinstance(name,str):break
   candidate=(p.parent/name).resolve()
   if not candidate.is_relative_to(root/'interim'):break
   candidates.append(candidate);size+=item.get('size',item.get('bytes',0))
  else:
   if p in candidates and 0<size<=4*1024**3:targets=candidates;break
 rows=[]
 for path in targets:
  if path.exists():continue
  rel=path.relative_to(root).as_posix();oid=subprocess.run(['git','rev-parse','--verify',head+':'+rel],capture_output=True,text=True)
  if oid.returncode:continue
  rows.append(dict(path=rel,blob=oid.stdout.strip()))
 if not rows:return False
 # Explicit reachable blob OIDs, no history or complete checkout.
 subprocess.run(['git','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin','--stdin'],input='\n'.join(r['blob'] for r in rows)+'\n',text=True,stdout=subprocess.DEVNULL,check=True)
 for row in rows:
  path=root/row['path'];path.parent.mkdir(parents=True,exist_ok=True)
  if path.exists():continue
  with path.open('xb') as stream:subprocess.run(['git','show',row['blob']],stdout=stream,check=True)
  row['bytes']=path.stat().st_size;fetches.append(row)
 (out/'fetched.json').write_text(json.dumps(fetches,indent=2)+'\n');return True
for ci,(cls,ids) in enumerate(classes.items()):
 attempts=[];before=len(fetches)
 for retry in range(100):
  cases=[tests[name].__class__(tests[name]._testMethodName) for name in ids]
  with (out/(str(ci)+'-'+str(retry)+'.log')).open('w') as log:
   start=time.monotonic();r=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(unittest.TestSuite(cases))
  attempt=dict(tests_run=r.testsRun,executed_ids=r.executed,passed_ids=r.passed,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped),expected_failures=len(r.expectedFailures),unexpected_successes=len(r.unexpectedSuccesses),missing_files=r.missing,elapsed_seconds=time.monotonic()-start)
  attempts.append(attempt)
  if not r.missing:break
  restored=False
  for name in r.missing:restored=fetch_missing(name) or restored
  if not restored:break
 results.append(dict(class_name=cls,assigned_ids=ids,attempts=attempts,final=attempts[-1]))
 (out/'results.json').write_text(json.dumps(dict(discovered_ids=sorted(tests),groups=groups,selected_ids=selected,results=results),indent=2)+'\n')
 print(ci+1,'/',len(classes),cls,'passed',len(r.passed),'errors',len(r.errors),'failures',len(r.failures),'skipped',len(r.skipped),flush=True)
 # Only newly fetched task cache copies, all Git blobs remain available.
 released=[]
 for row in fetches[before:]:
  path=root/row['path']
  if not path.exists():continue
  with path.open('rb') as stream:
   digest=hashlib.sha1(('blob '+str(path.stat().st_size)+'\0').encode())
   for raw in iter(lambda:stream.read(1024*1024),b''):digest.update(raw)
  if digest.hexdigest()!=row['blob']:raise ValueError('archive cache changed; retain '+row['path'])
  path.unlink();subprocess.run(['git','update-index','--skip-worktree','-z','--stdin'],input=row['path'].encode()+b'\0',check=True)
  released.append(row)
 with (out/'released.jsonl').open('a') as stream:stream.write(json.dumps(released)+'\n')
