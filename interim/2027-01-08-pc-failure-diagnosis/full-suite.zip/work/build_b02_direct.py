from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();deps=root/'target/release/deps';out=root/'work/b02-direct';out.mkdir(exist_ok=False)
def lib(name):return max(deps.glob('lib'+name+'-*.rlib'),key=lambda p:p.stat().st_mtime)
command=['rustc','--edition=2024','-O','--extern','soil_fem_3d='+str(root/'target/release/libsoil_fem_3d.rlib'),'--extern','serde='+str(lib('serde')),'--extern','serde_json='+str(lib('serde_json')),'-L','dependency='+str(deps),str(root/'interim/2026-12-01-tri6-offset-composite-b02/observer.rs'),'-o',str(out/'b02-observer')]
p=subprocess.run(command,capture_output=True,text=True);(out/'build.log').write_text(p.stdout+p.stderr);(out/'build.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n');raise SystemExit(p.returncode)
