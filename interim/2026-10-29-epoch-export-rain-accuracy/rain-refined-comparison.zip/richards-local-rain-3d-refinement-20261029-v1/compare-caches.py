"""Only audited Native endpoint caches qualify for the predeclared refined gates."""
from pathlib import Path
import hashlib,json,os,sys
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
import numpy as np
p=Path(__file__).resolve().parent;old=p.parent/'richards-local-rain-3d-20261029-v1'
read=lambda q:json.loads(q.read_text('utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
rms=lambda x:float(np.sqrt(np.mean(np.asarray(x)**2)))

def interpolate(field,target):
    # Same previously checked trilinear cell-centre comparison as the failed
    # original window. Constant extension at the domain boundary is retained.
    n=field.shape[0];value=field
    for axis in range(3):
        coordinate=np.clip(target*n-.5,0.,n-1.)
        lower=np.minimum(np.floor(coordinate).astype(int),n-2);upper=lower+1
        fraction=coordinate-lower;shape=[1,1,1];shape[axis]=len(target)
        value=np.take(value,lower,axis=axis)*(1-fraction.reshape(shape))+np.take(value,upper,axis=axis)*fraction.reshape(shape)
    return value

assert read(p/'all-audits-and-endpoints-terminal.json')['passed']
assert read(p/'reference-terminal.json')['passed'] and read(p/'native-time-raw-terminal.json')['passed']
protocol=read(p/'protocol.json');gates=protocol['gates'];inputs={}
assert protocol['native_space_window']==[8,16,24] and protocol['reference_space_window']==[16,32,64]
assert protocol['original_failures_and_thresholds_preserved']
parent_comparison=read(old/'comparison.json');assert not parent_comparison['passed']
assert [c for c in parent_comparison['checks'] if not c['passed']]==protocol['parent_failed_checks']

def cache(n,dt):
    reused=dt==100 and n in [8,16]
    folder=p/(f'reused-{n}-dt100' if reused else f'rt0-{n}-dt{dt}')
    q=folder/'endpoints-audited.json';r=read(q);terminal=read(folder/'audit-cache-terminal.json')
    audit_path=old/f'rt0-{n}-dt{dt}/audit.json' if reused else folder/'audit.json'
    assert terminal['passed'] and terminal['original_unmodified_audit']
    assert r['schema']=='soil-fem-local-rain-endpoints/1' and not r['physical_audit_pending']
    assert r['subdivisions']==n and r['solver_sha256']==protocol['solver_sha256']
    assert r['accepted_discrete_audit_sha256']==terminal['audit_sha256']==sha(audit_path)
    audit=read(audit_path);assert audit['passed'] and r['source_result_sha256'] in audit['sha256'].values()
    assert terminal['source_result_sha256']==r['source_result_sha256']
    inputs[str(q.relative_to(p))]=sha(q);inputs[str(audit_path)]=sha(audit_path)
    frames={f['name']:f for f in r['frames']};assert set(frames)=={'rain','pause','rain_again'}
    for name,t in [('rain',3600),('pause',7200),('rain_again',10800)]:
        f=frames[name];assert f['time_s']==t
        h=np.asarray(f['head_cube_mean_m']);assert h.shape==(n,n,n) and np.isfinite(h).all()
    return frames

natives={(n,dt):cache(n,dt) for n,dt in [(8,100),(16,100),(24,100),(16,50),(16,25)]}
refs={}
for n,dt in [(16,100),(32,100),(64,100),(32,50),(32,25)]:
    q=(old if dt==100 and n in [16,32] else p)/f'fv-{n}-dt{dt}.json'
    if q.parent==old:assert sha(q)==read(p/'reused-parent-files.json')[q.name]
    r=read(q);assert r['rain_patch_area_m2']==.25 and not r['reads_native_results']
    assert max(f['transverse_flux_rms_m_s'] for f in r['frames'])>1e-12
    refs[n,dt]=r;inputs[str(q)]=sha(q)

checks=[];comparisons=[];refinements=[]
def check(name,actual,upper):
    checks.append(dict(name=name,actual=float(actual),upper_bound=float(upper),passed=bool(np.isfinite(actual) and actual<upper)))
def nh(n,dt,stage):return np.asarray(natives[n,dt][stage]['head_cube_mean_m'])
def rf(n,dt,stage):return next(f for f in refs[n,dt]['frames'] if f['name']==stage)
sample=(np.arange(64)+.5)/64
for stage in ['rain','pause','rain_again']:
    reference=rf(64,100,stage);href=np.asarray(reference['head_m'])
    for n in [8,16,24]:
        h=nh(n,100,stage);d=h-interpolate(href,(np.arange(n)+.5)/n)
        row=dict(stage=stage,native_subdivisions=n,reference_subdivisions=64,dt_s=100,
            head_rms_error_m=rms(d),head_maximum_error_m=float(np.max(np.abs(d))),
            storage_error_m3=abs(natives[n,100][stage]['storage_offset_m3']-reference['storage_offset_m3']))
        comparisons.append(row)
        if n==24:
            check(stage+' finest head RMS',row['head_rms_error_m'],gates['finest_head_rms_m'])
            check(stage+' finest storage',row['storage_error_m3'],gates['finest_storage_error_m3'])
    groups=[('native_space',[interpolate(nh(n,100,stage),sample) for n in [8,16,24]]),
        ('fv_space',[interpolate(np.asarray(rf(n,100,stage)['head_m']),sample) for n in [16,32,64]]),
        ('native_time',[nh(16,dt,stage) for dt in [100,50,25]]),
        ('fv_time',[np.asarray(rf(32,dt,stage)['head_m']) for dt in [100,50,25]])]
    row=dict(stage=stage)
    for label,fields in groups:
        differences=[rms(fields[0]-fields[1]),rms(fields[1]-fields[2])]
        row[label+'_successive_rms_m']=differences
        ratio=differences[1]/differences[0] if differences[0]>1e-16 else 1e300
        check(stage+' '+label+' difference ratio',ratio,gates['successive_space_and_time_difference_ratio'])
        if label.endswith('_time'):
            check(stage+' '+label+' fine-step RMS',differences[1],protocol['additional_finest_time_difference_rms_gate_m'])
    refinements.append(row)
for (n,dt),r in refs.items():check(f'FV{n} dt{dt} integrated mass',r['maximum_integrated_mass_error_m3'],gates['independent_global_mass_error_m3'])
report=dict(schema='soil-fem-local-rain-refined-comparison/1',passed=all(c['passed'] for c in checks),
    original_failed_window_preserved=protocol['parent_failed_checks'],checks=checks,
    comparisons=comparisons,refinements=refinements,solver_sha256=protocol['solver_sha256'],
    protocol_sha256=sha(p/'protocol.json'),comparison_procedure_sha256=sha(Path(__file__)),
    audited_input_sha256=inputs,pointwise_maximum_error_reported_but_not_an_rms_gate=True,
    original_period_boundary_recovery_verified_separately=True,new_refined_restart_comparison_not_run=True,
    mechanical_or_stability_validation=False,p6_complete=False)
with (p/'comparison.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,allow_nan=False)
print('Refined gates:',sum(c['passed'] for c in checks),'/',len(checks),flush=True)
raise SystemExit(0 if report['passed'] else 1)
