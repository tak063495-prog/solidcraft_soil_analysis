"""Run the unchanged CI group once, retaining its measured JSON before cleanup."""
import os
import runpy
import sys
from pathlib import Path

root = Path.cwd()
out = Path(sys.argv[1]).resolve()
runner = root / "tools/run_ci_python_evidence_shards.py"
copy = out / "remeasured-spatial.json"
def retain(event, args):
    if event == "open" and isinstance(args[0], str) and args[1] == "r":
        src = Path(args[0])
        if src.parts[-2:] == ("replay", "measurements.json") and not copy.exists():
            os.link(src, copy)

sys.addaudithook(retain)
sys.argv = [str(runner), "--group", "python-spatial-evidence", "--output", str(out / "base-spatial")]
sys.path.insert(0, str(runner.parent))
runpy.run_path(str(runner), run_name="__main__")
