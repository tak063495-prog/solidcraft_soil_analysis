"""Compare retained NC spatial measurements using JSON Pointer paths."""
import hashlib
import json
import sys
from pathlib import Path

saved_path, actual_path, output = map(Path, sys.argv[1:])
deltas = []

def compare(a, b, pointer):
    if type(a) is not type(b):
        raise ValueError(f"type mismatch at {pointer}")
    if isinstance(a, dict):
        if a.keys() != b.keys():
            raise ValueError(f"key mismatch at {pointer}")
        for key in sorted(a):
            token = key.replace("~", "~0").replace("/", "~1")
            compare(a[key], b[key], f"{pointer}/{token}")
    elif isinstance(a, list):
        if len(a) != len(b):
            raise ValueError(f"length mismatch at {pointer}")
        for i, (x, y) in enumerate(zip(a, b, strict=True)):
            compare(x, y, f"{pointer}/{i}")
    elif isinstance(a, float) and a != b:
        deltas.append(dict(pointer=pointer, saved=a, remeasured=b, delta=b-a, abs_delta=abs(b-a)))
    elif a != b:
        raise ValueError(f"discrete mismatch at {pointer}")

saved, actual = saved_path.read_bytes(), actual_path.read_bytes()
compare(json.loads(saved), json.loads(actual), "")
largest = max(deltas, key=lambda row: row["abs_delta"], default=None)
report = dict(saved_sha256=hashlib.sha256(saved).hexdigest(),
              remeasured_sha256=hashlib.sha256(actual).hexdigest(),
              byte_identical=saved == actual, changed_numeric_fields=len(deltas),
              largest_absolute_difference=largest, differences=deltas)
with output.open("x", encoding="utf-8", newline="\n") as f:
    json.dump(report, f, indent=2, allow_nan=False)
    f.write("\n")
print(json.dumps({k:v for k,v in report.items() if k!="differences"}))
