"""Invoke exactly the baseline fixture's replay, preserving its output directory."""
import importlib.util
from pathlib import Path
import sys

root = Path.cwd()
path = root / "interim/2026-11-10-nc-spatial-release/remeasure.py"
spec = importlib.util.spec_from_file_location("nc_spatial_remeasure", path)
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
replay.run(Path(sys.argv[1]).resolve(), allow_platform_float_differences=sys.platform == "win32")
