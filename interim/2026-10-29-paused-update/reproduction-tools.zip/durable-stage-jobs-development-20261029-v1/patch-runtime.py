from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;runtime=p/'runtime'
q=runtime/'src/stage_job.rs';text=q.read_text(encoding='utf-8')
def replace(a,b,count=1):
    global text
    assert text.count(a)==count,(a,text.count(a))
    text=text.replace(a,b)
replace('const MESH: &str', 'mod recovery;\n\nconst MESH: &str')
replace('    pub parent_job_id: Option<String>,','    pub parent_job_id: Option<String>,\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    pub checkpoint_interval: Option<usize>,')
replace('    parent: Option<(&str, &Path)>,\n) -> Result<Manifest> {','    parent: Option<(&str, &Path)>,\n    checkpoint_interval: Option<usize>,\n) -> Result<Manifest> {\n    validate_interval(checkpoint_interval)?;')
replace('        parent_job_id: parent.map(|(id, _)| id.into()),','        parent_job_id: parent.map(|(id, _)| id.into()),\n        checkpoint_interval,')
replace('    prepare_impl(mesh, ground, case, output, None)','    prepare_impl(mesh, ground, case, output, None, None)')
replace('        Some((&manifest.job_id, &saved)),\n    )','        Some((&manifest.job_id, &saved)),\n        manifest.binding.checkpoint_interval,\n    )')
needle='pub fn status(folder: &Path) -> Result<Status> {'
addition='''fn validate_interval(interval: Option<usize>) -> Result<()> {
    if interval.is_some_and(|n| !(1..=4096).contains(&n)) {
        return Err(Error::Input("checkpoint interval must be1..4096 accepted increments".into()));
    }
    Ok(())
}
pub fn prepare_durable(mesh: &Path, ground: &Path, case: &Path, interval: usize, output: &Path) -> Result<Manifest> {
    prepare_impl(mesh, ground, case, output, None, Some(interval))
}
/// Fork a verified accepted snapshot into a new immutable job. This does not
/// stop its parent or infer liveness from a stored status/PID.
pub fn prepare_recovery(previous: &Path, output: &Path) -> Result<Manifest> {
    let (manifest, mesh, ground, case) = load(previous)?;
    if manifest.binding.identity != Identity::current(&mesh, &ground, &case)? {
        return Err(Error::Input("recover with the frozen solver executable".into()));
    }
    let saved = recovery::saved_path(previous, &manifest, &mesh, &ground, &case)?;
    prepare_impl(&previous.join(MESH), &previous.join(GROUND), &previous.join(CASE), output,
        Some((&manifest.job_id, &saved)), manifest.binding.checkpoint_interval)
}
'''
replace(needle,addition+'\n'+needle)
replace('    let identity = &manifest.binding.identity;','    validate_interval(manifest.binding.checkpoint_interval)?;\n    let identity = &manifest.binding.identity;')
replace('    last_status: Instant,','    last_status: Instant,\n    accepted_since_checkpoint: usize,')
replace('    trace: Mutex<TraceState>,','    trace: Mutex<TraceState>,\n    checkpoint_interval: Option<usize>,')
replace('impl FileObserver {','impl FileObserver {\n    fn reset_checkpoint_count(&self) -> Result<()> {\n        self.trace.lock().map_err(|e| Error::Control(e.to_string()))?.accepted_since_checkpoint = 0;\n        Ok(())\n    }')
replace('        trace.status.progress_events = sequence;','        if matches!(progress.kind, crate::stage_control::Kind::Accepted) {\n            trace.accepted_since_checkpoint += 1;\n        }\n        trace.status.progress_events = sequence;')
replace('        Ok(self.requested())','        let accepted = self.trace.lock().map_err(|e| Error::Control(e.to_string()))?.accepted_since_checkpoint;\n        Ok(self.requested() || self.checkpoint_interval.is_some_and(|n| accepted >= n))')
replace('            "progress.jsonl",','            "progress.jsonl",\n            "recovery.json",\n            "recovery-checkpoint-0.json",\n            "recovery-checkpoint-1.json",')
replace('        folder: folder.clone(),\n        trace:', '        folder: folder.clone(),\n        checkpoint_interval: manifest.binding.checkpoint_interval,\n        trace:')
replace('            last_status: Instant::now(),','            last_status: Instant::now(),\n            accepted_since_checkpoint: 0,')
start=text.index('        let result = if manifest.binding.parent_job_id.is_some() {',text.index('pub fn run('))
end=text.index('    })();',start)
new='''        let mut continuation = if manifest.binding.parent_job_id.is_some() {
            Some(read::<Checkpoint>(&folder.join(SAVED))?)
        } else { None };
        let mut generation = 0_u64;
        loop {
            observer.reset_checkpoint_count()?;
            let result = if let Some(saved) = continuation.take() {
                saved.resume_observed(&mesh, ground.clone(), case.clone(), &observer)?
            } else {
                stages::solve_observed(&mesh, ground.clone(), case.clone(), &observer)?
            };
            load(&folder)?;
            if result.complete {
                write_new(&folder.join("result.json"), &result)?;
                observer.finish(State::Succeeded, Some("result.json"), None)?;
                return Ok(Outcome::Succeeded);
            }
            if result.failure_reason.as_deref() == Some("checkpoint_requested") {
                let saved = Checkpoint::seal(&mesh, result)?;
                if observer.requested() {
                    write_new(&folder.join("checkpoint.json"), &saved)?;
                    observer.finish(State::Checkpointed, Some("checkpoint.json"), None)?;
                    return Ok(Outcome::Checkpointed);
                }
                if manifest.binding.checkpoint_interval.is_none() {
                    return Err(Error::Control("unexpected internal checkpoint without a durable policy".into()));
                }
                generation = generation.checked_add(1).ok_or_else(|| Error::Control("recovery generation overflow".into()))?;
                recovery::save(&folder, &manifest.job_id, generation, &saved)?;
                continuation = Some(saved);
            } else {
                let reason = result.failure_reason.clone();
                write_new(&folder.join("incomplete.json"), &result)?;
                observer.finish(State::Failed, Some("incomplete.json"), reason)?;
                return Ok(Outcome::Failed);
            }
        }
'''
text=text[:start]+new+text[end:];q.write_text(text,encoding='utf-8')
q=runtime/'src/main.rs';text=q.read_text(encoding='utf-8')
needle='        [command,mesh,ground,case,output] if command=="prepare-stages-job" => {'
addition='''        [command,mesh,ground,case,interval,output] if command=="prepare-durable-stages-job" => {
            let interval:usize=interval.parse().map_err(|_|Error::Input("checkpoint interval must be a positive integer".into()))?;
            let manifest=soil_fem_3d::stage_job::prepare_durable(Path::new(mesh),Path::new(ground),Path::new(case),interval,Path::new(output))?;
            println!("Prepared durable staged mechanics job {}",manifest.job_id);
        }
        [command,previous,output] if command=="prepare-stages-recovery" => {
            let manifest=soil_fem_3d::stage_job::prepare_recovery(Path::new(previous),Path::new(output))?;
            println!("Prepared accepted-snapshot recovery {}",manifest.job_id);
        }
'''
assert text.count(needle)==1;text=text.replace(needle,addition+needle,1)
q.write_text(text,encoding='utf-8')
print('Private durable policy, alternating atomic snapshots and recovery CLI patched; production unchanged')
