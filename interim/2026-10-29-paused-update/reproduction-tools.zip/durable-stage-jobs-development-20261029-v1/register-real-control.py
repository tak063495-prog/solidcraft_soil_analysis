from pathlib import Path
import datetime,hashlib,json,shutil
p=Path(__file__).resolve().parent
policy=p.parent/'goal-progress-20261027-v1/active-pause-policy.json';r=json.loads(policy.read_text(encoding='utf-8-sig'))
script=Path(r['script']);before=script.read_text(encoding='utf-8');shutil.copy2(script,p/'safe-pause-before-real274.py')
needle="    portable_marker=root/'runs/completed-studies-portable-solve-20261028-v1/pause-requested'";assert before.count(needle)==1
after=before.replace(needle,"    jobs.extend(root/'runs/durable-stage-jobs-development-20261029-v1/real274-control'/n for n in ['legacy','durable'])\n"+needle,1)
compile(after,str(script),'exec');script.write_text(after,encoding='utf-8',newline='\n')
r.update(script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
policy.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print('Real274 default and durable jobs registered for cooperative preservation')
