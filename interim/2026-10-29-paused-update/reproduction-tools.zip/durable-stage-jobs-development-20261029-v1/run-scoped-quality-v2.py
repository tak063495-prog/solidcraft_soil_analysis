"""Validate the isolated candidate before any production promotion."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent;runtime=p/'runtime'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
folder=p/'scoped-quality-v2';folder.mkdir();env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(p/'target'),RUST_TEST_THREADS='1')
records=[]
for label,args in [('fmt',['fmt','--all']),('stage-job-tests',['test','--locked','--release','--test','stage_job','--','--test-threads=1'])]:
    if (p/'pause-requested').exists():raise SystemExit(2)
    if label!='fmt':
        sys.path.insert(0,str(runtime/'tools'))
        from freeze_sources import freeze,manifest
        freeze(folder)
        source=manifest();assert len(source)==611
    command=['C:/Users/link_/.cargo/bin/cargo.exe',*args];began=time.monotonic()
    with (folder/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (folder/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]),flush=True)
    assert code==0
assert manifest()==source
root=p.parents[1];old=read(p/'baseline-source-manifest.json')
assert all(sha(root/n)==h for n,h in old.items() if not n.endswith('.md'))
with (folder/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,records=records,private_source_files=611,production_root_code_unchanged=True,
        private_sources_unchanged=True,full_quality_and_real_case_acceptance_pending=True,p6_complete=False),stream,indent=2)
print('PASS scoped durable and legacy CLI job checks; production promotion still gated',flush=True)
