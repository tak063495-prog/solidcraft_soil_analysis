"""Full regression for the unpromoted611-source durable-job candidate."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent;runtime=p/'runtime';folder=p/'full-quality';folder.mkdir()
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'scoped-quality-v2/terminal.json')['passed']
sys.path.insert(0,str(runtime/'tools'));from freeze_sources import freeze,manifest
assert manifest()==read(p/'scoped-quality-v2/source-snapshot.json')
freeze(folder);bound=manifest();assert len(bound)==611
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',
    CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(p/'target'),RUST_TEST_THREADS='2',
    OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
cargo=Path('C:/Users/link_/.cargo/bin/cargo.exe');records=[]
commands=[('fmt',[cargo,'fmt','--all','--','--check']),('rust-tests',[cargo,'test','--locked','--release']),
    ('clippy',[cargo,'clippy','--locked','--all-targets','--','-D','warnings']),('build',[cargo,'build','--locked','--release']),
    ('python-tests',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py'])]
for label,args in commands:
    if (p/'pause-requested').exists():raise SystemExit(2)
    if label=='python-tests':
        target=runtime/'target/release/soil-fem-3d.exe';target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p/'target/release/soil-fem-3d.exe',target)
        assert sha(target)==sha(p/'target/release/soil-fem-3d.exe')
    command=list(map(str,args));began=time.monotonic()
    with (folder/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (folder/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began);records.append(row)
    with (folder/(label+'-terminal.json')).open('x') as stream:json.dump(row,stream,indent=2)
    print(json.dumps(row),flush=True)
    assert code==0 and manifest()==bound
rust=(folder/'rust-tests.log').read_text(encoding='utf-8');python=(folder/'python-tests.log').read_text(encoding='utf-8')
counts=[tuple(map(int,q)) for q in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',rust)]
assert sum(q[0] for q in counts)==272 and all(q[1:]==(0,0) for q in counts)
assert 'Ran 162 tests' in python and '\nOK\n' in python
(folder/'solver').mkdir();shutil.copy2(p/'target/release/soil-fem-3d.exe',folder/'solver/soil-fem-3d.exe')
with (folder/'quality.json').open('x') as stream:
    json.dump(dict(passed=True,source_files=611,rust_tests_passed=272,python_tests_passed=162,
        all_sources_unchanged=True,fmt_clippy_build_passed=True,solver_sha256=sha(folder/'solver/soil-fem-3d.exe'),
        records=records,production_root_not_promoted=True,real_case_control_separate=True,p6_complete=False),stream,indent=2)
print('PASS611-source candidate full regression; real-case and production promotion gates remain separate',flush=True)
