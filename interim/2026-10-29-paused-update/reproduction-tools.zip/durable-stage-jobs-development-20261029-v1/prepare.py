"""Create an isolated611-source candidate from the previously validated610-source archive."""
from pathlib import Path,PurePosixPath
import hashlib,json,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1]
q=root/'runs/mcc-midpoint-quality-20261029-v13'
sources=json.loads((q/'source-snapshot.json').read_text(encoding='utf-8-sig'))
assert len(sources)==610
runtime=p/'runtime';runtime.mkdir()
with zipfile.ZipFile(q/'source-snapshot.zip') as z:
    assert set(z.namelist())==set(sources)
    for n,h in sources.items():
        path=PurePosixPath(n);assert not path.is_absolute() and '..' not in path.parts
        data=z.read(n);assert hashlib.sha256(data).hexdigest()==h
        target=runtime/n;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(data)
with (p/'baseline-source-manifest.json').open('x') as stream:json.dump(sources,stream,indent=2)
print('Isolated validated610-source baseline prepared; production Root unchanged')
