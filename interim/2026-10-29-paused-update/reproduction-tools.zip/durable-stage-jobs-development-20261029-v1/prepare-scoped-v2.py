from pathlib import Path
import json
p=Path(__file__).resolve().parent
q=p/'runtime/src/main.rs';text=q.read_text(encoding='utf-8')
needle='usage: soil-fem-3d solve-mixed-mechanics';assert text.count(needle)==1
text=text.replace(needle,'usage: soil-fem-3d prepare-durable-stages-job MESH.json GROUND.json CASE.json ACCEPTED_INTERVAL NEW_JOB | prepare-stages-recovery PREVIOUS_JOB NEW_JOB | solve-mixed-mechanics',1)
q.write_text(text,encoding='utf-8')
text=(p/'run-scoped-quality.py').read_text(encoding='utf-8')
assert text.count("folder=p/'scoped-quality'")==1 and text.count('freeze(p)')==1
text=text.replace("folder=p/'scoped-quality'","folder=p/'scoped-quality-v2'",1).replace('freeze(p)','freeze(folder)',1)
compile(text,str(p/'run-scoped-quality-v2.py'),'exec')
with (p/'run-scoped-quality-v2.py').open('x',encoding='utf-8') as stream:stream.write(text)
with (p/'scoped-quality/failure.json').open('x') as stream:
    json.dump(dict(passed=False,reason='Compiler rejected reuse of moved manifest.job_id; no numerical tests ran',
        corrected_to_borrow_observer_job_id=True,original_source_snapshot_retained=True),stream,indent=2)
print('Compiler fix and CLI usage prepared; original failed build and source freeze retained')
