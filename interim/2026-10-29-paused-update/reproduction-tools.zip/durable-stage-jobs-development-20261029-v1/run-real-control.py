"""Compare real CAD-derived five-stage histories with opt-in durable execution."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent;root=p.parents[1]
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'scoped-quality-v2/terminal.json')['passed']
frozen=read(p/'scoped-quality-v2/source-snapshot.json')
assert all(sha(p/'runtime'/n)==h for n,h in frozen.items())
original=root/'runs/native-fem-smoke-20261029-v1/Native63 cooperative smoke/workflow/analysis'
assert read(original.parents[1]/'smoke-verification.json')['passed']
folder=p/'real274-control';folder.mkdir()
original_solver=p/'target/release/soil-fem-3d.exe';assert original_solver.is_file()
(p/'solver-scoped').mkdir();solver=p/'solver-scoped/soil-fem-3d.exe'
shutil.copy2(original_solver,solver);assert sha(original_solver)==sha(solver)
records=[];binding={str(solver):sha(solver)}
for relative in ['ground/mesh.json','ground/ground.json','stages.json','stage-results.json']:
    binding[str(original/relative)]=sha(original/relative)
def call(label,command):
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=list(map(str,command));began=time.monotonic()
    with (folder/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=p/'runtime',stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (folder/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]),flush=True);assert code==0
for mode in ['legacy','durable']:
    job=folder/mode
    args=[solver,'prepare-durable-stages-job' if mode=='durable' else 'prepare-stages-job',
        original/'ground/mesh.json',original/'ground/ground.json',original/'stages.json']
    if mode=='durable':args.append('8')
    args.append(job);call('prepare-'+mode,args)
    call('solve-'+mode,[job/'solver/soil-fem-3d.exe','run-stages-job',job])
groups=['frames','last_committed','reference_displacement_m','integration_points','excavation_audits','transition_audits','geostatic','attempts']
def stable(v):
    if isinstance(v,dict):return {k:stable(x) for k,x in v.items() if k!='elapsed_seconds'}
    if isinstance(v,list):return [stable(x) for x in v]
    return v
old=read(original/'stage-results.json');legacy=read(folder/'legacy/result.json');durable=read(folder/'durable/result.json')
assert all(r['complete'] and len(r['frames'])==5 for r in [old,legacy,durable])
for key in groups:assert stable(old[key])==stable(legacy[key])==stable(durable[key]),key
pointer=read(folder/'durable/recovery.json');assert pointer['generation']>=2
assert not (folder/'legacy/recovery.json').exists()
assert not (folder/'durable/checkpoint.json').exists()
assert all(sha(Path(n))==h for n,h in binding.items())
assert all(sha(p/'runtime'/n)==h for n,h in frozen.items())
with (folder/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,actual_cad_case=True,frames=5,all8_physical_groups_exact=True,
        legacy_durable_and_previously_tested_root610_histories_exact=True,only_elapsed_seconds_omitted=True,
        recovery_generation=pointer['generation'],solver_sha256=sha(solver),records=records,
        source_and_input_binding_sha256=binding,production_root_not_promoted=True,p6_complete=False),stream,indent=2)
print('PASS actual CAD five-stage default/durable/Root610 histories are all exact',flush=True)
