"""Recompute the exact fixed-wall inputs under one validated solver with periodic accepted snapshots."""
from pathlib import Path,PurePosixPath
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,time,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1]
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('elements',type=int,choices=[2865,5144]);args=parser.parse_args()
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
def sha(q):
    h=hashlib.sha256()
    with q.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()
quality=root/'runs/durable-stage-jobs-development-20261029-v1/full-quality'
assert read(quality/'quality.json')['passed']
candidate=root/'runs/durable-stage-jobs-development-20261029-v1'
assert read(candidate/'real274-control/terminal.json')['all8_physical_groups_exact']
assert all(sha(candidate/'runtime'/n)==h for n,h in read(quality/'source-snapshot.json').items())
old=root/'runs'/('native-mcc-compact-pit-fixed-surface-refinement-20261028-v2' if args.elements==2865 else 'native-mcc-compact-pit-fixed-surface-refinement-20261029-v3')
assert read(old/'wall-spatial-topology-proof.json')['wall_mesh_equivalent_within_tolerance']
oldprep=read(old/'preparation.json');assert oldprep['elements']==args.elements
assert all(sha(Path(n))==h for n,h in oldprep['sha256'].items())
if (p/'pause-requested').exists():raise SystemExit(2)
out=p/('mesh'+str(args.elements));out.mkdir();runtime=out/'runtime';runtime.mkdir()
sources=read(old/'source-snapshot.json');assert len(sources)==600
with zipfile.ZipFile(old/'source-snapshot.zip') as z:
    assert set(z.namelist())==set(sources)
    for n,h in sources.items():
        q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts
        data=z.read(n);assert hashlib.sha256(data).hexdigest()==h
        target=runtime/n;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(data)
with (out/'audit-source-manifest.json').open('x') as stream:json.dump(sources,stream,indent=2)
analysis=out/'workflow/analysis';(analysis/'ground').mkdir(parents=True)
oldanalysis=old/'workflow/analysis';paths=['ground/mesh.json','ground/ground.json','stages.json']
for n in paths:shutil.copy2(oldanalysis/n,analysis/n);assert sha(analysis/n)==sha(oldanalysis/n)
solver=out/'solver/soil-fem-3d.exe';solver.parent.mkdir();shutil.copy2(quality/'solver/soil-fem-3d.exe',solver)
assert sha(solver)==read(quality/'quality.json')['solver_sha256']
audit=(root/'runs/native-mcc-compact-pit-fixed-surface-refinement-20261029-v3/audit-fields.py').read_text(encoding='utf-8')
assert "sys.path.insert(0,str(p/'runtime/tools'))" in audit
with (out/'audit-fields.py').open('x',encoding='utf-8') as stream:stream.write(audit)
binding={str(q):sha(q) for q in [solver,old/'preparation.json',old/'wall-spatial-topology-proof.json',quality/'source-snapshot.json',out/'audit-fields.py',Path(__file__)]}
for n in paths:binding[str(analysis/n)]=sha(analysis/n)
with (out/'preparation.json').open('x') as stream:
    json.dump(dict(prepared=True,elements=args.elements,points=args.elements*27,plates=832,structural_nodes=440,
        same_native_input_sha256=oldprep['same_native_input_sha256'],fresh_initialization_no_history_transfer=True,
        original_mechanical_inputs_byte_exact=True,original_preparation=str(old),sha256=binding,
        checkpoint_interval=4,solver_sha256=sha(solver),same_solver_for_both_meshes=True,
        native_large_result_display_not_accepted=True,p6_complete=False),stream,indent=2)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
records=[]
def call(label,command):
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=list(map(str,command));began=time.monotonic()
    with (out/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (out/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]),flush=True);assert code==0
job=analysis/'solver-job'
call('prepare-solver',[solver,'prepare-durable-stages-job',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stages.json','4',job])
call('solve',[job/'solver/soil-fem-3d.exe','run-stages-job',job]);shutil.copy2(job/'result.json',analysis/'stage-results.json')
call('export',[sys.executable,runtime/'tools/export_stages.py',analysis/'ground/mesh.json',analysis/'stage-results.json',analysis/'results'])
call('verify',[sys.executable,runtime/'tools/verify_stage_package.py',analysis/'ground/mesh.json',analysis/'ground/ground.json',analysis/'stage-results.json',analysis/'results','--solver',solver])
with (out/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,scope='solver and mechanical package only; independent seed/load audit still pending',
        elements=args.elements,records=records,sources_and_inputs_unchanged=True,p6_complete=False),stream,indent=2)
call('independent-fields',[sys.executable,out/'audit-fields.py'])
assert read(out/'field-verification.json')['seed_load_and_recorded_cutback_gates_passed']
assert all(sha(Path(n))==h for n,h in binding.items())
assert all(sha(runtime/n)==h for n,h in sources.items())
with (out/'study-terminal.json').open('x') as stream:
    json.dump(dict(passed=True,elements=args.elements,solver_sha256=sha(solver),records=records,
        original_three_inputs_byte_exact=True,periodic_checkpoint_interval=4,
        independent_seed_load_and_cutback_audit_passed=True,source_binding_sha256=binding,
        spatial_comparison_pending=True,native_gpu_acceptance_separate=True,p6_complete=False),stream,indent=2)
print('PASS fixed-wall'+str(args.elements)+' complete and audited; pair comparison pending',flush=True)
