from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
p=Path(__file__).resolve().parent;root=p.parents[1]
native=root/'runs/native-large-source-stream-20261029-v1'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
tests=p/'overlay/crates/engine/src/soil_results/tests.rs'
shutil.copy2(p/'overlay-binding.json',p/'overlay-binding-before-tests.json')
with tests.open('a',encoding='utf-8') as stream:stream.write('\n'+(p/'coordinate-tests.rs').read_text(encoding='utf-8'))
env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(p/'proof/target'))
binding={str(q):sha(q) for q in [p/'proof/Cargo.toml',p/'proof/src/main.rs',p/'coordinate-tests.rs',p/'overlay/crates/engine/src/soil_results/attachments.rs',Path(__file__)]}
records=[]
large=root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow'
commands=[('tests',['test','--offline','--manifest-path',str(p/'proof/Cargo.toml')]),
    ('actual-case',['run','--offline','--manifest-path',str(p/'proof/Cargo.toml'),'--',str(large/'analysis/ground/mesh.json'),str(large/'analysis/stages.json'),str(large/'view/frame-000.json')])]
for label,args in commands:
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=['C:/Users/link_/.cargo/bin/cargo.exe',*args];began=time.monotonic()
    with (p/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (p/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]),flush=True)
    assert code==0
assert all(sha(Path(n))==h for n,h in binding.items())
original=read(native/'source63.json')['files_sha256']
assert all(sha(native/'checkout'/n)==h for n,h in original.items())
with (p/'proof-terminal.json').open('x') as stream:
    json.dump(dict(passed=True,records=records,source63_under_ci_unchanged=True,proof_binding_sha256=binding,
        actual_metric_and_source_mapping_exact=True,full_native_integration_pending=True,p6_complete=False),stream,indent=2)
print('PASS coordinate-index isolated checks and actual662-node exhaustive comparison',flush=True)
