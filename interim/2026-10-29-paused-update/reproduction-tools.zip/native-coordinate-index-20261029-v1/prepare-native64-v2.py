"""Correct test namespace after the actual engine exposed its nested test module."""
from pathlib import Path
import hashlib,json,shutil
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';checkout=old/'checkout'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
failed=read(p/'native-quality/coordinate-tests-terminal.json');assert failed['exit_code']==101
snapshot=read(p/'source64.json')['files_sha256']
assert len(snapshot)==64 and all(sha(checkout/n)==h for n,h in snapshot.items())
saved=p/'native-quality/failed-source64.json';shutil.copy2(p/'source64.json',saved)
shutil.copy2(p/'source64.zip',p/'native-quality/failed-source64.zip')
paths=[checkout/'crates/engine/src/soil_results/tests.rs',p/'overlay/crates/engine/src/soil_results/tests.rs',p/'coordinate-tests.rs']
for q in paths:
    text=q.read_text(encoding='utf-8')
    assert text.count('use super::attachments::CoordinateIndex;')==3
    text=text.replace('use super::attachments::CoordinateIndex;','use crate::soil_results::attachments::CoordinateIndex;')
    q.write_text(text,encoding='utf-8')
main=p/'proof/src/main.rs';shutil.copy2(main,p/'native-quality/proof-main-before-namespace.rs')
text=main.read_text(encoding='utf-8');assert text.count('mod attachments;')==1
text=text.replace('mod attachments;','pub(crate) mod attachments;\npub(crate) mod soil_results { pub(crate) use crate::attachments; }',1)
main.write_text(text,encoding='utf-8')
(p/'source64.json').unlink();(p/'source64.zip').unlink()
text=(p/'build-and-check-native64-resumed.py').read_text(encoding='utf-8')
body=text[text.index('env=dict(os.environ'):]
assert body.count("folder=p/'native-quality'")==1
body=body.replace("folder=p/'native-quality'","folder=p/'native-quality-v2'",1)
prefix='''"""Validate corrected engine-test namespace; retain the failed64-source snapshot."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';checkout=old/'checkout'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
expected=set(read(p/'native-quality/failed-source64.json')['files_sha256'])
assert len(expected)==64 and not (p/'pause-requested').exists()
'''
text=prefix+body;compile(text,str(p/'build-and-check-native64-v2.py'),'exec')
with (p/'build-and-check-native64-v2.py').open('x',encoding='utf-8') as stream:stream.write(text)
with (p/'native-quality/failure.json').open('x') as stream:
    json.dump(dict(passed=False,reason='Existing protocol tests are nested under native::tests, not soil_results::tests; three appended imports did not resolve',
        test_imports_corrected_to_crate_soil_results=True,production_coordinate_algorithm_unchanged=True,
        failed_source64_snapshot_retained=True,full_native_quality_and_gui_still_required=True,p6_complete=False),stream,indent=2)
print('Native64 test namespace corrected; failed snapshot retained; production matching code unchanged')
