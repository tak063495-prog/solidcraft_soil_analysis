"""Resume from the archived candidate without claiming the interrupted63 CI passed."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1]
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
old=root/'runs/native-large-source-stream-20261029-v1'
assert not (p/'source64.json').exists() and not (p/'native-quality').exists()
assert not (old/'full-quality/ci-terminal.json').exists()
proof=read(p/'proof-terminal.json');assert proof['passed']
assert all(sha(Path(n))==h for n,h in proof['proof_binding_sha256'].items())
previous=read(old/'source63.json')['files_sha256']
assert len(previous)==63 and all(sha(old/'checkout'/n)==h for n,h in previous.items())
ps="Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^(solidcraft|solidcraft-cli|cargo|rustc|xtask)\\.exe$'} | Select-Object ProcessId,Name | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',ps],text=True,encoding='utf-8-sig').strip()
saved=p/'resume-20261029-v1';saved.mkdir()
marker=p/'pause-requested';assert marker.is_file()
shutil.copy2(marker,saved/'pause-requested-before-resume');assert sha(marker)==sha(saved/'pause-requested-before-resume')
marker.unlink()
policy=root/'runs/goal-progress-20261027-v1/active-pause-policy.json';state=read(policy)
assert state['threshold_percent']==100 and sha(Path(state['script']))==state['script_sha256']
state.update(goal_active=True,explicit_user_pause=False,latest_observed_weekly_usage_percent=23,
    source='User set the goal active after the explicit pause; latest direct human100% threshold retained.',
    updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
policy.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
text=(p/'build-and-check-native64.py').read_text(encoding='utf-8')
start=text.index("overlay=p/'overlay'")
prefix='''"""Validate the64-file candidate after an interrupted63 baseline; no baseline CI success is inferred."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';checkout=old/'checkout'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'proof-terminal.json')['passed']
assert not (p/'pause-requested').exists()
previous=read(old/'source63.json')['files_sha256']
assert all(sha(checkout/n)==h for n,h in previous.items())
assert not (old/'full-quality/ci-terminal.json').exists()
with (p/'native63-ci-interruption-preserved.json').open('x') as stream:
    json.dump(dict(source_files=63,baseline_ci_accepted=False,interrupted=True,
        source_manifest_sha256=sha(old/'source63.json'),partial_ci_log_sha256=sha(old/'full-quality/ci.log'),
        full_candidate64_ci_required=True,obsolete63_release_not_built=True,p6_complete=False),stream,indent=2)
'''
resumed=prefix+text[start:]
compile(resumed,str(p/'build-and-check-native64-resumed.py'),'exec')
with (p/'build-and-check-native64-resumed.py').open('x',encoding='utf-8') as stream:stream.write(resumed)
with (saved/'resume-binding.json').open('x') as stream:
    json.dump(dict(resumed_by_user=True,native63_sources_verified_before_adoption=True,
        candidate_proof_bytes_verified=True,old_interrupted_ci_not_claimed_passed=True,
        full_native64_ci_required=True,old_driver_sha256=sha(p/'build-and-check-native64.py'),
        resumed_driver_sha256=sha(p/'build-and-check-native64-resumed.py'),pause_threshold_percent=100,p6_complete=False),stream,indent=2)
print('Resume prepared;63 interrupted CI retained and64 full CI will run independently',flush=True)
