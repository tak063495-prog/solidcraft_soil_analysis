from pathlib import Path
import datetime,hashlib,json,shutil
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';desktop=p/'desktop'
for n in ['gui-control.py','dismiss-startup-overlay.py','request-safe-quit.json']:
    shutil.copy2(old/'desktop-ci'/n,desktop/n)
text=(old/'desktop-ci/open-and-inspect.py').read_text(encoding='utf-8')
needle="read(p.parent/'real-view-preparation.json')";assert text.count(needle)==1
text=text.replace(needle,"read(root/'runs/native-large-source-stream-20261029-v1/real-view-preparation.json')",1)
with (desktop/'open-and-inspect.py').open('x',encoding='utf-8') as stream:stream.write(text)
for source,target in [('verify-desktop-template.py','verify-desktop.py'),('finish-desktop-template.py','finish-desktop.py')]:
    text=(old/source).read_text(encoding='utf-8')
    assert text.count('native_source_files=63')==1
    text=text.replace('native_source_files=63','native_source_files=64',1)
    with (desktop/target).open('x',encoding='utf-8') as stream:stream.write(text)
text=(old/'desktop-ci/when-ready.py').read_text(encoding='utf-8')
needle="owner/'ci-desktop-build/terminal.json'";assert text.count(needle)==2
text=text.replace(needle,"owner/'review-build-terminal.json'")
with (desktop/'when-ready.py').open('x',encoding='utf-8') as stream:stream.write(text)
for q in desktop.glob('*.py'):compile(q.read_text(encoding='utf-8'),str(q),'exec')
policy=root/'runs/goal-progress-20261027-v1/active-pause-policy.json'
r=json.loads(policy.read_text(encoding='utf-8-sig'));script=Path(r['script']);before=script.read_text(encoding='utf-8')
shutil.copy2(script,p/'safe-pause-before-native64-desktop.py')
needle="    for gui_name in ['desktop','desktop-ci']:\n        gui=root/'runs/native-large-source-stream-20261029-v1'/gui_name"
assert before.count(needle)==1
replacement="    gui_folders=[root/'runs/native-large-source-stream-20261029-v1'/n for n in ['desktop','desktop-ci']]\n    gui_folders.extend(root/'runs/native-coordinate-index-20261029-v1'/n for n in ['desktop','desktop-release'])\n    for gui in gui_folders:"
after=before.replace(needle,replacement,1);compile(after,str(script),'exec')
script.write_text(after,encoding='utf-8',newline='\n')
r.update(script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
policy.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print('Prepared Native64 review checks and owned-app graceful quit policy')
