"""Let Native63 CI finish, but skip its now-obsolete release after a real integration rejection."""
from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent
old=p.parent/'native-large-source-stream-20261029-v1'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
assert read(p/'proof-terminal.json')['passed']
rejection=read(old/'desktop-ci/open-real-result-v2.json')
assert not rejection['reply']['ok'] and 'structural coordinate matching budget exceeded' in rejection['reply']['error']
assert read(old/'desktop-ci/owned-app-exited.json')['original_handle_signaled']
assert not (old/'full-quality/release-child.json').exists()
with (old/'pause-requested').open('x') as stream:stream.write('Finish current CI; skip superseded Source63 release after actual coordinate-budget rejection. Goal remains active.\n')
with (p/'source63-release-retirement.json').open('x') as stream:
    json.dump(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source63_ci_allowed_to_finish=True,source63_release_skipped_after_known_integration_rejection=True,
        prior_owned_app_gracefully_exited=True,rejection_sha256=hashlib.sha256((old/'desktop-ci/open-real-result-v2.json').read_bytes()).hexdigest(),
        isolated_index_proof_passed=True,source64_native_validation_pending=True,goal_remains_active=True,
        global_pause_threshold_percent=100,p6_complete=False),stream,indent=2)
print('Native63 CI continues; obsolete release suppressed. Goal and follow-up validation remain active.')
