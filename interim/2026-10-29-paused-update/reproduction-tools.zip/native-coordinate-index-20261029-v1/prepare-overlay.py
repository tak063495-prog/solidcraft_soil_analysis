"""Prepare an isolated follow-up; never edit the source63 checkout under active CI."""
from pathlib import Path
import hashlib,json,shutil
p=Path(__file__).resolve().parent
root=p.parents[1]
native=root/'runs/native-large-source-stream-20261029-v1'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
sources=read(native/'source63.json')['files_sha256']
assert all(sha(native/'checkout'/n)==h for n,h in sources.items())
overlay=p/'overlay';base=Path('crates/engine/src/soil_results')
for n in ['mod.rs','structures.rs','tests.rs']:
    target=overlay/base/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(native/'checkout'/base/n,target)
shutil.copy2(p/'attachments.rs',overlay/base/'attachments.rs')
q=overlay/base/'mod.rs';text=q.read_text(encoding='utf-8')
needle='#[cfg(not(target_arch = "wasm32"))]\nmod geometry;'
assert text.count(needle)==1
text=text.replace(needle,'#[cfg(not(target_arch = "wasm32"))]\nmod attachments;\n'+needle,1)
q.write_text(text,encoding='utf-8')
q=overlay/base/'structures.rs';text=q.read_text(encoding='utf-8')
needle='    let mut matching_budget = 0usize;'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n    let index = if definitions.iter().any(|d| d.get("match_soil_node").and_then(Value::as_bool) == Some(true)) {\n        Some(super::attachments::CoordinateIndex::new(&g.nodes_m)?)\n    } else {\n        None\n    };',1)
start=text.index('            matching_budget = matching_budget.saturating_add(g.nodes_m.len());')
end=text.index('        } else if let Some(set)',start)
old=text[start:end]
assert 'found.first().copied()' in old and 'matching_budget > 2_000_000' in old
new='            let position = vector::<3>(definition.get("position_m"))?;\n            let index = index.as_ref().ok_or_else(|| bad(CMD, "missing structural coordinate index"))?;\n            Some(index.find_unique(position, &mut matching_budget)?)\n'
text=text[:start]+new+text[end:];q.write_text(text,encoding='utf-8')
with (p/'overlay-binding.json').open('x') as stream:
    json.dump(dict(base_source63_manifest_sha256=sha(native/'source63.json'),base_sources_unchanged=True,
        files_sha256={str(q.relative_to(overlay)).replace('\\','/'):sha(q) for q in overlay.rglob('*.rs')},
        exact_euclidean_tolerance_m=1e-8,distance_comparison_budget_unchanged=2000000,
        full_native_ci_and_integration_pending=True,p6_complete=False),stream,indent=2)
print('Prepared isolated coordinate-index overlay; active Native63 source untouched')
