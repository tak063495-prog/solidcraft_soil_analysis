"""Remove strict-CI test warnings after the frozen-v2 targeted test completes."""
from pathlib import Path
import hashlib,json,shutil
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';checkout=old/'checkout'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'native-quality-v2/coordinate-tests-terminal.json')['exit_code']==0
assert read(root/'runs/goal-progress-20261027-v1/active-pause-policy.json')['goal_active']
snapshot=read(p/'source64.json')['files_sha256'];assert all(sha(checkout/n)==h for n,h in snapshot.items())
for n in ['json','zip']:shutil.copy2(p/('source64.'+n),p/'native-quality-v2'/('source64-with-warning.'+n))
for q in [checkout/'crates/engine/src/soil_results/tests.rs',p/'overlay/crates/engine/src/soil_results/tests.rs',p/'coordinate-tests.rs']:
    text=q.read_text(encoding='utf-8');assert text.count('&mut usize::MAX')==1
    lines=[]
    for line in text.splitlines(keepends=True):
        if '&mut usize::MAX' in line:
            lines.append(line[:len(line)-len(line.lstrip())]+'let mut overflow_budget = usize::MAX;\n')
            line=line.replace('&mut usize::MAX','&mut overflow_budget')
        lines.append(line)
    text=''.join(lines)
    assert text.count('for i in 0..662')==1 and text.count('find_unique(points[i],')==1
    text=text.replace('for i in 0..662','for (i, point) in points.iter().take(662).enumerate()').replace('find_unique(points[i],','find_unique(*point,')
    q.write_text(text,encoding='utf-8')
for n in ['json','zip']:(p/('source64.'+n)).unlink()
marker=p/'pause-requested';assert marker.read_text(encoding='utf-8').startswith('Supersede64-v2')
shutil.copy2(marker,p/'native-quality-v2/hold-marker-before-next-candidate.txt');marker.unlink()
text=(p/'build-and-check-native64-v2.py').read_text(encoding='utf-8')
assert text.count("folder=p/'native-quality-v2'")==1
text=text.replace("folder=p/'native-quality-v2'","folder=p/'native-quality-v3'",1)
text=text.replace("read(p/'native-quality/failed-source64.json')","read(p/'native-quality-v2/source64-with-warning.json')",1)
compile(text,str(p/'build-and-check-native64-v3.py'),'exec')
with (p/'build-and-check-native64-v3.py').open('x',encoding='utf-8') as stream:stream.write(text)
shutil.copy2(p/'desktop/when-ready.py',p/'desktop/when-ready-v3.py')
print('Strict-CI test warning fixes prepared; production coordinate matcher unchanged')
