"""Validate corrected engine-test namespace; retain the failed64-source snapshot."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1]
old=root/'runs/native-large-source-stream-20261029-v1';checkout=old/'checkout'
read=lambda q:json.loads(q.read_text(encoding='utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
expected=set(read(p/'native-quality-v2/source64-with-warning.json')['files_sha256'])
assert len(expected)==64 and not (p/'pause-requested').exists()
env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(checkout/'target'),SOLIDCRAFT_TEST_JOBS='1',RUST_TEST_THREADS='4')
folder=p/'native-quality-v3';folder.mkdir();records=[];source=None
def call(label,args):
    if (p/'pause-requested').exists():raise SystemExit(2)
    if source:assert all(sha(checkout/n)==h for n,h in source.items())
    command=['C:/Users/link_/.cargo/bin/cargo.exe',*args];began=time.monotonic()
    with (folder/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=checkout,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        with (folder/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    unchanged=source is None or all(sha(checkout/n)==h for n,h in source.items())
    row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began,sources_unchanged=unchanged)
    records.append(row)
    with (folder/(label+'-terminal.json')).open('x') as stream:json.dump(row,stream,indent=2)
    print(json.dumps(row),flush=True)
    assert code==0 and unchanged
call('fmt',['fmt','--all'])
tracked=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=checkout,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=checkout,text=True).splitlines()
assert set(tracked+untracked)==expected
source={n:sha(checkout/n) for n in sorted(expected)}
with (p/'source64.json').open('x') as stream:json.dump(dict(base='edf57cec293dcea301201f1d5173b33e16351466',files_sha256=source),stream,indent=2)
with zipfile.ZipFile(p/'source64.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,h in source.items():assert sha(checkout/n)==h;z.writestr(n,(checkout/n).read_bytes())
call('coordinate-tests',['test','--locked','--profile','ci','-p','solidcraft-engine','coordinate_index'])
assert '3 passed; 0 failed' in (folder/'coordinate-tests.log').read_text(encoding='utf-8')
call('review-build',['build','--locked','--profile','ci','-p','solidcraft','-p','solidcraft-cli'])
(p/'native').mkdir();binaries={}
for n in ['solidcraft.exe','solidcraft-cli.exe']:
    original=checkout/'target/ci'/n;before=sha(original);shutil.copy2(original,p/'native'/n)
    assert sha(original)==sha(p/'native'/n)==before;binaries[n]=before
with (p/'review-build-terminal.json').open('x') as stream:
    json.dump(dict(passed=True,source_files=64,profile='ci',sources_unchanged=True,
        coordinate_regressions_passed=3,binaries_sha256=binaries,full_native_ci_pending=True,
        actual_large_native_acceptance_pending=True,p6_complete=False),stream,indent=2)
call('ci',['xtask','ci'])
assert 'ci: all gates passed' in (folder/'ci.log').read_text(encoding='utf-8')
print('Native64 full CI passed; waiting for actual large CI-profile GUI acceptance before final release',flush=True)
while not (p/'desktop/desktop-verification.json').exists():
    if (p/'pause-requested').exists() or (p/'skip-obsolete-release').exists():raise SystemExit(2)
    time.sleep(5)
assert read(p/'desktop/desktop-verification.json')['passed']
call('release',['build','--locked','--release','-p','solidcraft','-p','solidcraft-cli'])
(p/'release-native').mkdir();release={}
for n in ['solidcraft.exe','solidcraft-cli.exe']:
    original=checkout/'target/release'/n;before=sha(original);shutil.copy2(original,p/'release-native'/n)
    assert sha(original)==sha(p/'release-native'/n)==before;release[n]=before
with (folder/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,source_files=64,full_native_ci_passed=True,sources_unchanged=True,
        records=records,binaries_sha256=release,ci_profile_large_gui_passed=True,
        release_gpu_acceptance_still_required=True,p6_complete=False),stream,indent=2)
print('PASS Native64 full CI and release build; release GPU acceptance remains separate',flush=True)
