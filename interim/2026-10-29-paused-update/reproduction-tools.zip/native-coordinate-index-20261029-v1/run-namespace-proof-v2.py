from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;root=p.parents[1];folder=p/'namespace-proof-v2';folder.mkdir()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
paths=[p/'proof/Cargo.toml',p/'proof/Cargo.lock',p/'proof/src/main.rs',p/'coordinate-tests.rs',p/'overlay/crates/engine/src/soil_results/attachments.rs']
binding={str(q):sha(q) for q in paths}
large=root/'runs/mcc-large-structures-development-20261028-v1/large-case/workflow'
env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(p/'proof/target'));records=[]
for label,args in [('tests',['test','--locked','--offline','--manifest-path',str(p/'proof/Cargo.toml')]),
    ('actual-case',['run','--locked','--offline','--manifest-path',str(p/'proof/Cargo.toml'),'--',str(large/'analysis/ground/mesh.json'),str(large/'analysis/stages.json'),str(large/'view/frame-000.json')])]:
    if (p/'pause-requested').exists():raise SystemExit(2)
    command=['C:/Users/link_/.cargo/bin/cargo.exe',*args];began=time.monotonic()
    with (folder/(label+'.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        with (folder/(label+'-child.json')).open('x') as stream:
            json.dump(dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),stream)
        code=child.wait()
    records.append(dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-began));print(json.dumps(records[-1]),flush=True);assert code==0
assert all(sha(Path(n))==h for n,h in binding.items())
with (folder/'terminal.json').open('x') as stream:
    json.dump(dict(passed=True,records=records,test_namespace_matches_engine=True,files_sha256=binding,
        actual_662_mappings_exact=True,full_native_ci_and_gpu_acceptance_pending=True,p6_complete=False),stream,indent=2)
print('PASS corrected-namespace tests and actual662 source/display mappings',flush=True)
