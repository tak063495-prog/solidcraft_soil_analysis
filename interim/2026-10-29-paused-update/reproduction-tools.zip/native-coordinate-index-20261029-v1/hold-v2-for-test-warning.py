"""Finish the current test compile, then supersede it before the known warning reaches-Dwarnings CI."""
from pathlib import Path
import json
p=Path(__file__).resolve().parent
log=(p/'native-quality-v2/coordinate-tests.log').read_text(encoding='utf-8')
assert 'const_item_mutation' in log and '&mut usize::MAX' in log
assert not (p/'review-build-terminal.json').exists() and not (p/'desktop/launch.json').exists()
with (p/'pause-requested').open('x',encoding='utf-8') as stream:
    stream.write('Supersede64-v2 test source after const-item-mutation warning; finish active compile, skip downstream build. Goal remains active.\n')
with (p/'native-quality-v2/warning-correction-required.json').open('x') as stream:
    json.dump(dict(const_item_mutation_in_test_detected=True,production_coordinate_code_unchanged=True,
        current_compile_allowed_to_finish=True,next_candidate_will_correct_test_variable_and_loop=True,
        obsolete_downstream_build_suppressed=True,goal_remains_active=True,p6_complete=False),stream,indent=2)
print('Known test warning recorded; downstream-v2 build suppressed without pausing the goal')
