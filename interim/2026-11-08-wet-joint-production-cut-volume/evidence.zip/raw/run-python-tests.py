import os
for n in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[n]='1'
import json,sys,unittest,time
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'));sys.path.insert(0,str(root/'tests'))
loader=unittest.TestLoader();suite=loader.discover('tests',pattern='test_*.py')
def flatten(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):yield from flatten(t)
  else:yield t
all_tests=list(flatten(suite));excluded=[t.id() for t in all_tests if t.id().startswith('test_low_preload_nc.') or t.id() == 'test_low_preload_nc_followup.LowNCFollowup.test_real_separate_process_restarts_inside_every_phase']
selected=[t for t in all_tests if t.id() not in excluded]
Path('work/wet-production/python-selection.json').write_text(json.dumps(dict(discovered=len(all_tests),selected=len(selected),excluded=excluded,reason='User explicitly prohibits another low-preload NC run without new verified improvement; this test class launches that case.'),indent=2))
start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
Path('work/wet-production/python-result.json').write_text(json.dumps(dict(tests_run=result.testsRun,failures=[(str(t),e) for t,e in result.failures],errors=[(str(t),e) for t,e in result.errors],skipped=[(str(t),e) for t,e in result.skipped],successful=result.wasSuccessful(),elapsed_seconds=time.monotonic()-start),indent=2))
sys.exit(not result.wasSuccessful())
