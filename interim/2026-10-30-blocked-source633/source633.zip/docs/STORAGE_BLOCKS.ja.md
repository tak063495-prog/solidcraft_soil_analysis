# 元結果を保持する分割読込

この候補では、projected MCCの元結果を小さな履歴ブロックへ分け、既存の力学検査へ全工程・全積分点・初期種状態・施工遷移・最終確定状態を渡します。元結果と各ブロックのSHA256を確認します。表示用の平均値で材料履歴を置き換えません。

元結果のencoded読込はprojected MCCに限り32 GiBまでです。各componentのencoded上限256 MiB、payloadとキャッシュの会計上限512 MiB、表示パケットの上限は保持します。監査側のNumPy配列や保持する参照は別であり、プロセス全体のメモリーを512 MiBに保証するものではありません。MC/IDH等の従来の受付上限は変えません。

実結果1,459,184,313 bytes・8,061 Tet10・217,647 GP・全5工程で、元の混合MCC検査と既存の全有効GP/板/節点VTU比較を通過した読込実装が基礎です。既存APIの板座標tupleを保つ修正を含む、この統合候補の品質検査・実producerと大きな14,909要素ケースは別に検証します。Native、一般10万要素、空間収束、正式配布や全P6の受入はこの記録だけで認定しません。

通常の環境構築はrequirements.lock.txt、独立参照を含む試験はrequirements-reference.lock.txtを使用します。追加のijsonは3.6.0に固定しています。Windows x64・CPython3.13のwheelだけを使う検証では、requirements-verification-win-cp313.lock.txtに9パッケージのwheel SHA256を固定しています。

検証用wheelを別のwheelhouseへ保存し、全ファイルをtools/verification_wheels_windows.jsonと照合した後、新しい仮想環境へ次のようにオフライン導入できます。

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install --no-index --find-links wheelhouse --require-hashes -r requirements-verification-win-cp313.lock.txt
.venv\Scripts\python.exe -m pip check
.venv\Scripts\python.exe -W error::SyntaxWarning -m unittest discover -s tests -p 'test_*.py' -v
```

Rustを含む試験には固定したFEM実行ファイルをtarget/releaseへ置くか、同じソースからビルドします。別の場所でビルドしたexeのハッシュを元の受入証明書へ書き直さず、新しいジョブと監査を作成してください。同一PCの新規配置と新規PC・別GPUの受入は区別します。
