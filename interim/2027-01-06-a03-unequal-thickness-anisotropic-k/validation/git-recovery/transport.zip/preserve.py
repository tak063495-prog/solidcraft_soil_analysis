"""Stream all old working bytes against the fixed base tree; never rewrite them."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
base='484f007490d4a042c7ad330de75881025c76a8df'
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);a=parser.parse_args()
env=dict(os.environ,GIT_NO_LAZY_FETCH='1');rows=[];excluded=[];special=[]
allowed=('interim/2026-12-06-p6-01-status-reconciliation/audit_status.py','interim/2026-12-10-ci-p601-inventory-fix/inventory.toml')
for line in subprocess.check_output(['git','ls-tree','-r',base],text=True,env=env).splitlines():
 meta,name=line.split('\t');mode,kind,oid=meta.split();assert kind=='blob'
 if name.startswith('interim/2026-11-10-nc-postfold-branches/evidence.tar.gz.part'):
  excluded.append(dict(path=name,git_blob_sha1=oid,existing_ci_exclusion=True));continue
 path=Path(name);assert path.is_file(),name
 h=hashlib.sha1(('blob '+str(path.stat().st_size)+'\0').encode());s=hashlib.sha256()
 with path.open('rb') as f:
  for raw in iter(lambda:f.read(1024*1024),b''):h.update(raw);s.update(raw)
 if name in allowed:
  old=subprocess.check_output(['git','show',base+':'+name],env=env);new=path.read_bytes()
  if name.endswith('inventory.toml'):assert new.startswith(old)
  else:
   pattern=rb"SUPPLEMENTAL_SHA256 = '[0-9a-f]{64}'"
   assert re.sub(pattern,b'PIN',old)==re.sub(pattern,b'PIN',new)
  special.append(dict(path=name,allowed_change_only=True,old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=s.hexdigest()));continue
 assert h.hexdigest()==oid,name
 assert (path.stat().st_mode & 0o111 != 0)==(mode=='100755'),name
 rows.append(dict(path=name,git_blob_sha1=oid,sha256=s.hexdigest(),bytes=path.stat().st_size,mode=mode))
 if len(rows)%2000==0:print('verified old paths',len(rows),flush=True)
a.output.mkdir(parents=True,exist_ok=False)
(a.output/'base-tree-binding.json').write_text(json.dumps(rows,indent=2)+'\n')
(a.output/'base-preservation.json').write_text(json.dumps(dict(base=base,old_files_exact=len(rows),bytes=sum(r['bytes'] for r in rows),allowed_changes=special,existing_ci_exclusions=excluded,missing_required_archives=0,old_scientific_values_failures_archives_and_nc_unchanged=True),indent=2)+'\n')
print('ALL OLD BYTES VERIFIED',len(rows),flush=True)
