# Local main-CI and nightly property tests

This older checkout uses the libtest runner in `xtask/src/test.rs`.
Its local gate now follows the existing official PR/main distinction in
`.github/workflows/ci.yml`: only the kernel integration target `boolean_props`
is reserved for nightly property testing. The policy is also documented in
`.config/nextest.toml`. Other heavy regression tests still run locally.

`cargo xtask test --property-tests` includes those properties. Direct Cargo
execution is unchanged, for example
`cargo test --profile ci -p solidcraft-kernel --test boolean_props`.
Selecting only that target without opting in fails explicitly; no empty test
selection may report success.

This is a narrow adaptation of the policy discussed in upstream PR 7263,
https://github.com/tangency-labs/solidcraft/pull/7263 (head
`2211b47f8a72393eaa4c00ff5ceed46bd596e7b5`, reviewed while open).
The full PR targets newer APIs, including a nextest runner absent here; it was
not applied verbatim. Kernel algorithms, regression seeds, ignored flags and
numerical tolerances have not changed.

The previously observed cylinder/sphere Boolean counterexample and the failed
all-target Native65 CI remain failures. A successful main-policy CI is not a
claim that the nightly properties pass or that the kernel defect was repaired.
