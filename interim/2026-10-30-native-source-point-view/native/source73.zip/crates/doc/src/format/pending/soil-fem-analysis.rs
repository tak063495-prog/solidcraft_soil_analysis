//! Soil FEM analysis attributes are saved under metadata.org.solidcraft.soil-fem:
//! versioned ground/stage inputs, logical body labels, producer/component/name-family
//! bindings and the CAD fingerprint explicitly reviewed when configured. Older
//! designs have no analysis; no migration invents materials or body identities.
//! The last release refuses the newer design format rather than silently dropping
//! analysis attributes. Running jobs and results are not stored as design data.
