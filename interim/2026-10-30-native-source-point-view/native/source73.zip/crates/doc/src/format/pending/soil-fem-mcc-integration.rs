//! Construction inputs may persist an optional MCC integration override in the
//! existing soil-analysis metadata. Absence retains the material's own setting;
//! no older design data is rewritten. The external FEM validates the full law.
