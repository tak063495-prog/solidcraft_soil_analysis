//! Persistent analysis attributes and input-only snapshots. The FEM remains an
//! external process; appearance, density and display meshes never supply soil data.
use crate::params::bad;
use crate::{Result, Session};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use solidcraft_doc::{Document, ModelBody, ModelState};
#[cfg(not(target_arch = "wasm32"))]
use std::collections::BTreeMap;
use std::collections::BTreeSet;

pub const KEY: &str = "org.solidcraft.soil-fem";
const SCHEMA: &str = "solidcraft-soil-analysis/1";
const LIMIT: usize = 256;
const CMD: &str = "analysis.soil";

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Binding {
    pub analysis_body: String,
    pub cad_body: String,
    pub creator_feature: u64,
    pub component: u64,
    /// All outputs of this producer/component. A changed family is ambiguous.
    pub producer_outputs: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Setup {
    pub schema: String,
    pub ground: Value,
    pub stages: Value,
    pub bindings: Vec<Binding>,
    pub reviewed_cad_sha256: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct BindRequest {
    analysis_body: String,
    cad_body: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Configure {
    ground: Value,
    stages: Value,
    bindings: Vec<BindRequest>,
    expected_cad_sha256: String,
    expected_setup_sha256: String,
}

pub fn digest(value: &impl Serialize) -> Result<String> {
    let bytes = serde_json::to_vec(value).map_err(|e| bad(CMD, e.to_string()))?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

/// Deliberately conservative: non-analysis document edits invalidate captures.
/// View-only visibility does not; uncaptured occurrence moves do.
pub fn cad_digest(s: &Session) -> Result<String> {
    let mut doc = (*s.doc).clone();
    doc.metadata.remove(KEY);
    doc.visibility = Default::default();
    digest(&json!({"document": doc, "pending_moves": s.pending_moves}))
}

pub fn setup_digest(s: &Session) -> Result<String> {
    digest(s.doc.metadata.get(KEY).unwrap_or(&Value::Null))
}

fn bounded(value: &Value) -> Result<()> {
    let bytes = serde_json::to_vec(value).map_err(|e| bad(CMD, e.to_string()))?;
    if bytes.len() > solidcraft_doc::metadata::MAX_VALUE_BYTES {
        return Err(bad(CMD, "analysis attributes exceed 64 KiB"));
    }
    let mut pending = vec![(value, 0usize)];
    while let Some((v, depth)) = pending.pop() {
        if depth > 24 {
            return Err(bad(CMD, "analysis attributes exceed nesting limit"));
        }
        match v {
            Value::Array(a) => pending.extend(a.iter().map(|x| (x, depth + 1))),
            Value::Object(m) => pending.extend(m.values().map(|x| (x, depth + 1))),
            _ => {}
        }
    }
    Ok(())
}

fn label(s: &str) -> Result<()> {
    if s.is_empty() || s.len() > 128 || s.trim() != s || s.chars().any(char::is_control) {
        return Err(bad(CMD, "body labels must be 1..128 bytes, trimmed and without control characters"));
    }
    Ok(())
}

/// Bridge-contract checks only; constitutive, mesh and stage admissibility is
/// checked by the authoritative external Rust FEM validator before any solve.
fn labels(ground: &Value, stages: &Value) -> Result<BTreeSet<String>> {
    let projected = stages.get("schema").and_then(Value::as_str) == Some("soil-fem-projected-mcc-stages/1");
    if ground.get("schema").and_then(Value::as_str) != Some("soil-fem-ground/1")
        || ground.get("units").and_then(Value::as_str) != Some("m-kN-kPa")
        || (!projected && stages.get("schema").and_then(Value::as_str) != Some("soil-fem-stages/1"))
    {
        return Err(bad(CMD, "expected soil-fem-ground/1 in m-kN-kPa and soil-fem-stages/1"));
    }
    let materials = ground.get("materials").and_then(Value::as_array).ok_or_else(|| bad(CMD, "materials are required"))?;
    if materials.is_empty() || materials.len() > LIMIT {
        return Err(bad(CMD, "expected 1..256 materials"));
    }
    if let Some(integration) = stages.pointer("/settings/mcc_integration").filter(|v| !v.is_null()) {
        if !matches!(integration.as_str(), Some("backward_euler" | "midpoint")) {
            return Err(bad(CMD, "MCC integration must be backward_euler or midpoint, or omitted to use material settings"));
        }
        if !materials.iter().any(|m| m.get("mcc").is_some_and(Value::is_object)) {
            return Err(bad(CMD, "an MCC integration override requires at least one MCC material"));
        }
    }
    if projected
        && (materials.iter().any(|m| !m.get("mcc").is_some_and(Value::is_object))
            || ground.pointer("/initialization/water_level_m").is_some_and(|v| !v.is_null())
            || ["joint_system", "anchor_system"].iter().any(|key| stages.get(*key).is_some_and(|v| !v.is_null()))
            || stages
                .get("beam_system")
                .filter(|v| !v.is_null())
                .is_some_and(|v| !matches!(v.get("schema").and_then(Value::as_str), Some("soil-fem-beams/1" | "soil-fem-structures/1")))
            || stages.get("initially_inactive_bodies").is_some_and(|v| v.as_array().is_none_or(|a| !a.is_empty()))
            || !matches!(stages.pointer("/settings/kinematics").and_then(Value::as_str), Some("side_rollers" | "explicit")))
    {
        return Err(bad(
            CMD,
            "projected MCC native inputs require dry MCC, side_rollers/explicit kinematics, explicit linear structures, and no water/contact/anchor/birth coupling",
        ));
    }
    let mut ids = BTreeSet::new();
    for m in materials {
        let id = m.get("id").and_then(Value::as_u64).filter(|&n| n > 0 && n <= u32::MAX as u64).ok_or_else(|| bad(CMD, "invalid material id"))?;
        if !ids.insert(id) {
            return Err(bad(CMD, "duplicate material id"));
        }
    }
    let field = if ground.pointer("/initialization/method").and_then(Value::as_str) == Some("equilibrate") { "bodies" } else { "layers" };
    let bodies = ground.get(field).and_then(Value::as_array).ok_or_else(|| bad(CMD, format!("{field} are required")))?;
    if bodies.is_empty() || bodies.len() > LIMIT {
        return Err(bad(CMD, "expected 1..256 material bodies"));
    }
    let mut names = BTreeSet::new();
    for b in bodies {
        let n = b.get("body").and_then(Value::as_str).ok_or_else(|| bad(CMD, "body label is required"))?;
        label(n)?;
        if !names.insert(n.to_string()) {
            return Err(bad(CMD, "duplicate material body"));
        }
        if !b.get("material_id").and_then(Value::as_u64).is_some_and(|id| ids.contains(&id)) {
            return Err(bad(CMD, "body refers to an unknown material"));
        }
    }
    if let Some(tools) = ground.get("excavation_bodies") {
        for v in tools.as_array().filter(|a| a.len() <= LIMIT).ok_or_else(|| bad(CMD, "excavation_bodies must be a bounded array"))? {
            let n = v.as_str().ok_or_else(|| bad(CMD, "excavation body label must be text"))?;
            label(n)?;
            if !names.insert(n.to_string()) {
                return Err(bad(CMD, "excavation and material bodies must be distinct"));
            }
        }
    }
    stages
        .get("stages")
        .and_then(Value::as_array)
        .filter(|a| a.len() <= LIMIT)
        .ok_or_else(|| bad(CMD, "stages must be an array of at most 256 steps"))?;
    if projected
        && stages.get("stages").and_then(Value::as_array).is_some_and(|steps| {
            steps.iter().any(|step| {
                !matches!(
                    step.get("kind").and_then(Value::as_str),
                    Some(
                        "boundary"
                            | "pressure"
                            | "excavate"
                            | "reset_display"
                            | "install_beams"
                            | "remove_beams"
                            | "install_structures"
                            | "remove_structures"
                    )
                )
            })
        })
    {
        return Err(bad(CMD, "projected MCC supports boundary/pressure/excavation/display-reset and linear structure installation/removal stages"));
    }
    if names.len() > LIMIT {
        return Err(bad(CMD, "at most 256 analysis bodies"));
    }
    Ok(names)
}

pub fn required_body_labels(ground: &Value, stages: &Value) -> Result<Vec<String>> {
    Ok(labels(ground, stages)?.into_iter().collect())
}

/// File selection belongs to the interactive front end; this JSON command only
/// reads explicitly supplied files through the existing VFS permission boundary.
pub fn read_inputs(_: &mut Session, p: &Value) -> Result<Value> {
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Paths {
        ground_path: String,
        stages_path: String,
    }
    let paths: Paths = serde_json::from_value(p.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    let read = |path: &str| -> Result<Value> {
        if path.is_empty() || path.len() > 4096 {
            return Err(bad(CMD, "invalid input path"));
        }
        let text = solidcraft_io::vfs::read_to_string(path, solidcraft_doc::metadata::MAX_VALUE_BYTES).map_err(|e| bad(CMD, e.to_string()))?;
        serde_json::from_str(&text).map_err(|e| bad(CMD, e.to_string()))
    };
    let ground = read(&paths.ground_path)?;
    let stages = read(&paths.stages_path)?;
    let names = required_body_labels(&ground, &stages)?;
    let value = json!({"ground":ground,"stages":stages,"required_body_labels":names});
    bounded(&value)?;
    Ok(value)
}

fn outputs(state: &ModelState, feature: u64, component: u64) -> Vec<String> {
    let mut names: Vec<_> = state.bodies.iter().filter(|b| b.feature == feature && b.component == component).map(|b| b.name.clone()).collect();
    names.sort();
    names
}

fn resolve<'a>(binding: &Binding, state: &'a ModelState) -> Result<&'a ModelBody> {
    let family = outputs(state, binding.creator_feature, binding.component);
    if family != binding.producer_outputs {
        return Err(bad(CMD, format!("{}: CAD output family changed; explicitly rebind", binding.analysis_body)));
    }
    let mut candidates =
        state.bodies.iter().filter(|b| b.feature == binding.creator_feature && b.component == binding.component && b.name == binding.cad_body);
    let body = candidates.next().ok_or_else(|| bad(CMD, format!("{}: CAD body is missing; explicitly rebind", binding.analysis_body)))?;
    if candidates.next().is_some() {
        return Err(bad(CMD, "ambiguous CAD body binding"));
    }
    Ok(body)
}

fn setup(s: &Session) -> Result<Setup> {
    let value = s.doc.metadata.get(KEY).ok_or_else(|| bad(CMD, "configure soil analysis first"))?;
    bounded(value)?;
    let setup: Setup = serde_json::from_value(value.clone()).map_err(|e| bad(CMD, format!("invalid saved analysis: {e}")))?;
    if setup.schema != SCHEMA || setup.bindings.len() > LIMIT {
        return Err(bad(CMD, "unsupported saved analysis schema or binding count"));
    }
    let expected = labels(&setup.ground, &setup.stages)?;
    let actual: BTreeSet<_> = setup.bindings.iter().map(|b| b.analysis_body.clone()).collect();
    let cad: BTreeSet<_> = setup.bindings.iter().map(|b| b.cad_body.clone()).collect();
    if actual != expected || actual.len() != setup.bindings.len() || cad.len() != setup.bindings.len() {
        return Err(bad(CMD, "saved analysis body bindings are incomplete or duplicated"));
    }
    Ok(setup)
}

pub fn model(s: &mut Session, _: &Value) -> Result<Value> {
    inspect(s)
}

pub fn inspect(s: &Session) -> Result<Value> {
    let state = s.model.state();
    let cad_sha256 = cad_digest(s)?;
    let mut issues = Vec::new();
    let saved = if s.doc.metadata.get(KEY).is_none() {
        None
    } else {
        match setup(s) {
            Ok(v) => Some(v),
            Err(e) => {
                issues.push(e.to_string());
                None
            }
        }
    };
    if let Some(setup) = &saved {
        for b in &setup.bindings {
            if let Err(e) = resolve(b, &state) {
                issues.push(e.to_string());
            }
        }
    }
    if !s.doc.occurrences.is_empty() {
        issues.push("soil export requires definition bodies without assembly occurrences".into());
    }
    if s.model.results.iter().any(|r| r.error.is_some()) {
        issues.push("CAD timeline has evaluation errors".into());
    }
    if s.active_sketch.is_some() || !s.pending_moves.is_empty() {
        issues.push("finish sketch edits and capture pending moves first".into());
    }
    let changed = saved.as_ref().is_some_and(|v| v.reviewed_cad_sha256 != cad_sha256);
    let bodies: Vec<_> =
        state.bodies.iter().take(LIMIT + 1).map(|b| json!({"cad_body":b.name,"creator_feature":b.feature,"component":b.component})).collect();
    Ok(json!({"schema":"solidcraft-soil-model-status/1","configuration":saved,"issues":issues,"cad_changed_since_review":changed,
        "cad_sha256":cad_sha256,"setup_sha256":setup_digest(s)?,"cad_bodies":bodies,"solver_validation":"requires_mesh_and_external_fem_validation"}))
}

pub fn configure(s: &mut Session, value: &Value) -> Result<Value> {
    bounded(value)?;
    let request: Configure = serde_json::from_value(value.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    if request.expected_cad_sha256 != cad_digest(s)? || request.expected_setup_sha256 != setup_digest(s)? {
        return Err(bad(CMD, "CAD or analysis changed while the editor was open; reload before saving"));
    }
    let expected = labels(&request.ground, &request.stages)?;
    if request.bindings.len() != expected.len() {
        return Err(bad(CMD, "bind every material/excavation body exactly once"));
    }
    let state = s.model.state();
    let mut seen = BTreeSet::new();
    let mut seen_cad = BTreeSet::new();
    let mut bindings = Vec::new();
    for b in request.bindings {
        if !expected.contains(&b.analysis_body) || !seen.insert(b.analysis_body.clone()) || !seen_cad.insert(b.cad_body.clone()) {
            return Err(bad(CMD, "unknown or duplicate analysis/CAD body binding"));
        }
        let body = state.body(&b.cad_body).ok_or_else(|| bad(CMD, format!("no CAD body {}", b.cad_body)))?;
        bindings.push(Binding {
            analysis_body: b.analysis_body,
            cad_body: b.cad_body,
            creator_feature: body.feature,
            component: body.component,
            producer_outputs: outputs(&state, body.feature, body.component),
        });
    }
    bindings.sort_by(|a, b| a.analysis_body.cmp(&b.analysis_body));
    let next =
        Setup { schema: SCHEMA.into(), ground: request.ground, stages: request.stages, bindings, reviewed_cad_sha256: request.expected_cad_sha256 };
    let next = serde_json::to_value(next).map_err(|e| bad(CMD, e.to_string()))?;
    bounded(&next)?;
    let mut metadata = s.doc.metadata.clone();
    metadata.set(KEY, next)?;
    if metadata != s.doc.metadata {
        s.doc_mut().metadata = metadata;
    }
    inspect(s)
}

/// Called by the authoritative body.rename command in its same undo step.
/// No metadata from a future/unknown schema is interpreted or rewritten.
pub(crate) fn renamed(doc: &mut Document, old: &str, new: &str) -> Result<()> {
    let Some(value) = doc.metadata.get(KEY) else { return Ok(()) };
    let Ok(mut setup) = serde_json::from_value::<Setup>(value.clone()) else { return Ok(()) };
    if setup.schema != SCHEMA {
        return Ok(());
    }
    for binding in &mut setup.bindings {
        if binding.cad_body == old {
            binding.cad_body = new.to_string();
        }
        for name in &mut binding.producer_outputs {
            if name == old {
                *name = new.to_string();
            }
        }
        binding.producer_outputs.sort();
    }
    doc.metadata.set(KEY, serde_json::to_value(setup).map_err(|e| bad(CMD, e.to_string()))?)?;
    Ok(())
}

pub fn snapshot(s: &mut Session, _: &Value) -> Result<Value> {
    let status = inspect(s)?;
    if status.get("issues").and_then(Value::as_array).is_some_and(|a| !a.is_empty())
        || status.get("cad_changed_since_review").and_then(Value::as_bool) == Some(true)
    {
        return Err(bad(CMD, "CAD changed or body bindings are unresolved; review the analysis model before capture"));
    }
    let setup = setup(s)?;
    let state = s.model.state();
    let mut bindings = Vec::new();
    for b in &setup.bindings {
        let body = resolve(b, &state)?;
        bindings.push(json!({"analysis_body":b.analysis_body,"cad_body":body.name,"creator_feature":body.feature,"component":body.component}));
    }
    let payload = json!({"schema":"solidcraft-soil-snapshot/1","cad_sha256":cad_digest(s)?,"ground":setup.ground,"stages":setup.stages,"bindings":bindings,
        "cad_length_unit":"mm","analysis_units":"m-kN-kPa","solver_validation":"requires_mesh_and_external_fem_validation"});
    Ok(json!({"input_sha256":digest(&payload)?,"snapshot":payload}))
}

#[cfg(target_arch = "wasm32")]
pub fn export(_: &mut Session, _: &Value) -> Result<Value> {
    Err(bad(CMD, "STEP analysis capture is available in the native desktop application"))
}

#[cfg(not(target_arch = "wasm32"))]
pub fn export(s: &mut Session, p: &Value) -> Result<Value> {
    use std::io::{Read, Write};
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Export {
        directory: String,
        expected_input_sha256: String,
    }
    let request: Export = serde_json::from_value(p.clone()).map_err(|e| bad(CMD, e.to_string()))?;
    if request.directory.is_empty() || request.directory.len() > 4096 {
        return Err(bad(CMD, "invalid capture directory"));
    }
    let frozen = snapshot(s, &Value::Null)?;
    if frozen.get("input_sha256").and_then(Value::as_str) != Some(&request.expected_input_sha256) {
        return Err(bad(CMD, "analysis inputs changed before capture"));
    }
    let directory = std::path::PathBuf::from(&request.directory);
    solidcraft_io::vfs::check(&request.directory).map_err(|e| bad(CMD, e.to_string()))?;
    std::fs::create_dir(&directory).map_err(|e| bad(CMD, format!("new capture directory required: {e}")))?;
    let write = |name: &str, bytes: &[u8]| -> Result<String> {
        let path = directory.join(name);
        solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
        let mut f = std::fs::OpenOptions::new().write(true).create_new(true).open(path).map_err(|e| bad(CMD, e.to_string()))?;
        f.write_all(bytes).and_then(|_| f.sync_all()).map_err(|e| bad(CMD, e.to_string()))?;
        Ok(format!("{:x}", Sha256::digest(bytes)))
    };
    let setup = setup(s)?;
    let state = s.model.state();
    let mut records = Vec::new();
    let mut files = BTreeMap::new();
    // A capture.json written last is the completion marker. Partial captures are
    // retained for diagnostics and never confused with a complete analysis job.
    let mut total_step_bytes = 0usize;
    for (i, b) in setup.bindings.iter().enumerate() {
        let body = resolve(b, &state)?;
        let filename = format!("body-{:04}.step", i + 1);
        let bytes = solidcraft_io::export_with_metadata(
            &s.doc.painted(&s.world_state()),
            std::slice::from_ref(&body.name),
            solidcraft_io::Format::Step,
            &b.analysis_body,
            &s.doc.metadata,
        )?;
        total_step_bytes = total_step_bytes.saturating_add(bytes.len());
        if bytes.len() > 256 << 20 || total_step_bytes > 512 << 20 {
            return Err(bad(CMD, "STEP body exceeds 256 MiB capture limit"));
        }
        let hash = write(&filename, &bytes)?;
        files.insert(filename.clone(), hash.clone());
        records.push(json!({"analysis_body":b.analysis_body,"cad_body":body.name,"step":filename,"source_sha256":hash,"cad_length_unit":"mm"}));
    }
    let canonical =
        serde_json::to_vec(frozen.get("snapshot").ok_or_else(|| bad(CMD, "missing snapshot payload"))?).map_err(|e| bad(CMD, e.to_string()))?;
    files.insert("snapshot-canonical.json".into(), write("snapshot-canonical.json", &canonical)?);
    for (name, value) in [("ground.json", &setup.ground), ("stages.json", &setup.stages), ("input-snapshot.json", &frozen)] {
        files.insert(name.to_string(), write(name, &serde_json::to_vec_pretty(value).map_err(|e| bad(CMD, e.to_string()))?)?);
    }
    let bytes = solidcraft_io::write_design(&s.design());
    files.insert("source.solidcraft.json".into(), write("source.solidcraft.json", &bytes)?);
    if snapshot(s, &Value::Null)? != frozen {
        return Err(bad(CMD, "CAD or analysis inputs changed during capture"));
    }
    let mut binary = std::fs::File::open(std::env::current_exe().map_err(|e| bad(CMD, e.to_string()))?).map_err(|e| bad(CMD, e.to_string()))?;
    let mut exporter = Sha256::new();
    let mut buffer = vec![0u8; 1024 * 1024];
    loop {
        let n = binary.read(&mut buffer).map_err(|e| bad(CMD, e.to_string()))?;
        if n == 0 {
            break;
        }
        exporter.update(buffer.get(..n).ok_or_else(|| bad(CMD, "invalid executable read length"))?);
    }
    let receipt = json!({"schema":"solidcraft-soil-capture/1","complete":true,"input_sha256":request.expected_input_sha256,"bodies":records,"files_sha256":files,
        "exporter_binary_sha256":format!("{:x}",exporter.finalize()),"exporter_version":env!("CARGO_PKG_VERSION"),
        "solver_validation":"requires_mesh_and_external_fem_validation"});
    write("capture.json", &serde_json::to_vec_pretty(&receipt).map_err(|e| bad(CMD, e.to_string()))?)?;
    Ok(json!({"directory":request.directory,"capture":receipt}))
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> Session {
        let mut s = Session::default();
        s.execute("solid.box", &json!({"length":10000,"width":10000,"height":4000})).unwrap();
        s
    }
    fn request(s: &Session) -> Value {
        let m = inspect(s).unwrap();
        json!({"ground":{"schema":"soil-fem-ground/1","units":"m-kN-kPa","initialization":{"method":"equilibrate"},
            "materials":[{"id":1}],"bodies":[{"body":"Clay","material_id":1}]},
            "stages":{"schema":"soil-fem-stages/1","stages":[]},
            "bindings":[{"analysis_body":"Clay","cad_body":s.model.state().bodies.first().unwrap().name}],
            "expected_cad_sha256":m["cad_sha256"],"expected_setup_sha256":m["setup_sha256"]})
    }
    #[test]
    fn attributes_have_atomic_undo_and_optimistic_edit_conflicts() {
        let mut s = fixture();
        let p = request(&s);
        let undo = s.undo.len();
        s.execute("analysis.soil.configure", &p).unwrap();
        assert_eq!(s.undo.len(), undo + 1);
        let snap = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
        assert_eq!(snap["snapshot"]["bindings"][0]["analysis_body"], "Clay");
        assert_eq!(snap["snapshot"]["cad_length_unit"], "mm");
        assert!(s.execute("analysis.soil.configure", &p).is_err(), "stale editor must not overwrite newer attributes");
        assert_eq!(s.execute("analysis.soil.snapshot", &json!({})).unwrap(), snap);
        s.execute("edit.undo", &json!({})).unwrap();
        assert!(s.doc.metadata.get(KEY).is_none());
        s.execute("edit.redo", &json!({})).unwrap();
        assert_eq!(s.execute("analysis.soil.snapshot", &json!({})).unwrap(), snap);
    }
    #[test]
    fn rename_preserves_logical_body_identity_and_invalidates_the_old_capture() {
        let mut s = fixture();
        let p = request(&s);
        s.execute("analysis.soil.configure", &p).unwrap();
        let old = s.model.state().bodies.first().unwrap().name.clone();
        let before = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
        let undo = s.undo.len();
        s.execute("body.rename", &json!({"body":old,"name":"Renamed CAD soil"})).unwrap();
        let m = inspect(&s).unwrap();
        assert!(m["issues"].as_array().unwrap().is_empty());
        assert_eq!(m["cad_changed_since_review"], true);
        assert_eq!(m["configuration"]["bindings"][0]["cad_body"], "Renamed CAD soil");
        assert_eq!(m["configuration"]["bindings"][0]["analysis_body"], "Clay");
        assert_eq!(s.undo.len(), undo + 1, "rename and its binding update are one undo step");
        assert!(s.execute("analysis.soil.snapshot", &json!({})).is_err());
        s.execute("edit.undo", &json!({})).unwrap();
        assert_eq!(s.execute("analysis.soil.snapshot", &json!({})).unwrap(), before);
    }
    #[test]
    fn changed_output_families_are_unresolved_and_never_selected_by_bounds() {
        let mut s = fixture();
        s.execute("analysis.soil.configure", &request(&s)).unwrap();
        let setup = setup(&s).unwrap();
        let binding = setup.bindings.first().unwrap();
        let mut changed = (*s.model.state()).clone();
        let mut sibling = changed.bodies.first().unwrap().clone();
        sibling.name = "New split piece".into();
        changed.bodies.push(sibling);
        assert!(resolve(binding, &changed).is_err());
        changed.bodies.clear();
        assert!(resolve(binding, &changed).is_err());
    }
    #[test]
    fn hostile_or_incomplete_configuration_never_changes_the_design() {
        let mut s = fixture();
        let original = s.doc.to_json();
        let undo = s.undo.len();
        let p = request(&s);
        let mut cases = vec![json!(null), json!({}), json!({"unexpected":1})];
        let mut invalid = p.clone();
        invalid["bindings"] = json!([]);
        cases.push(invalid);
        let mut invalid = p.clone();
        invalid["ground"]["bodies"][0]["material_id"] = json!(2);
        cases.push(invalid);
        let mut invalid = p.clone();
        invalid["ground"]["units"] = json!("mm");
        cases.push(invalid);
        let mut invalid = p.clone();
        invalid["bindings"][0]["cad_body"] = json!("missing");
        cases.push(invalid);
        let mut invalid = p.clone();
        invalid["ground"]["unused"] = json!("x".repeat(65537));
        cases.push(invalid);
        let mut invalid = p;
        invalid["ground"]["excavation_bodies"] = json!(["Clay"]);
        cases.push(invalid);
        for invalid in cases {
            assert!(s.execute("analysis.soil.configure", &invalid).is_err());
            assert_eq!(s.doc.to_json(), original);
            assert_eq!(s.undo.len(), undo);
        }
    }
    #[test]
    fn saved_design_reopens_with_the_same_attributes_and_input_fingerprint() {
        let mut s = fixture();
        s.execute("analysis.soil.configure", &request(&s)).unwrap();
        let before = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
        let doc = solidcraft_doc::Document::from_json(&s.doc.to_json()).unwrap();
        let mut restored = Session::new(doc);
        assert_eq!(restored.execute("analysis.soil.snapshot", &json!({})).unwrap(), before);
        let foreign = json!({"schema":"solidcraft-soil-analysis/999","cad_body":"Clay"});
        restored.doc_mut().metadata.set(KEY, foreign.clone()).unwrap();
        let old = restored.model.state().bodies.first().unwrap().name.clone();
        restored.execute("body.rename", &json!({"body":old,"name":"Elsewhere"})).unwrap();
        assert_eq!(restored.doc.metadata.get(KEY), Some(&foreign), "unknown future metadata stays untouched");
        assert!(!inspect(&restored).unwrap()["issues"].as_array().unwrap().is_empty());
    }
    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn capture_exports_one_named_step_per_binding_and_seals_all_inputs_without_overwriting() {
        let mut s = fixture();
        s.execute("analysis.soil.configure", &request(&s)).unwrap();
        let snap = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
        let before = s.doc.to_json();
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/soil-capture-tests");
        std::fs::create_dir_all(&root).unwrap();
        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let output = root.join(format!("{}-{nonce}", std::process::id()));
        let p = json!({"directory":output,"expected_input_sha256":snap["input_sha256"]});
        let receipt = s.execute("analysis.soil.export", &p).unwrap();
        assert_eq!(receipt["capture"]["complete"], true);
        for (name, hash) in receipt["capture"]["files_sha256"].as_object().unwrap() {
            let bytes = std::fs::read(output.join(name)).unwrap();
            assert_eq!(format!("{:x}", Sha256::digest(bytes)), hash.as_str().unwrap());
        }
        assert!(std::fs::read_to_string(output.join("body-0001.step")).unwrap().contains("ISO-10303-21"));
        assert_eq!(s.doc.to_json(), before);
        assert!(s.execute("analysis.soil.export", &p).is_err());
        let unchanged = std::fs::read(output.join("capture.json")).unwrap();
        assert!(!unchanged.is_empty());
    }

    #[test]
    fn mcc_integration_choice_changes_identity_persists_and_has_atomic_undo() {
        for method in ["backward_euler", "midpoint"] {
            let mut s = fixture();
            let mut initial = request(&s);
            initial["ground"]["materials"] = json!([{"id":1,"mcc":{}}]);
            initial["stages"]["settings"] = json!({"kinematics":"side_rollers"});
            s.execute("analysis.soil.configure", &initial).unwrap();
            let before = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
            assert!(before.pointer("/snapshot/stages/settings/mcc_integration").is_none());
            let mut changed = request(&s);
            changed["ground"] = initial["ground"].clone();
            changed["stages"] = initial["stages"].clone();
            changed["stages"]["settings"]["mcc_integration"] = json!(method);
            let undo = s.undo.len();
            s.execute("analysis.soil.configure", &changed).unwrap();
            assert_eq!(s.undo.len(), undo + 1);
            let after = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
            assert_ne!(before["input_sha256"], after["input_sha256"]);
            assert_eq!(after["snapshot"]["stages"]["settings"]["mcc_integration"], method);
            let doc = solidcraft_doc::Document::from_json(&s.doc.to_json()).unwrap();
            let mut restored = Session::new(doc);
            assert_eq!(restored.execute("analysis.soil.snapshot", &json!({})).unwrap(), after);
            s.execute("edit.undo", &json!({})).unwrap();
            assert_eq!(s.execute("analysis.soil.snapshot", &json!({})).unwrap(), before);
            s.execute("edit.redo", &json!({})).unwrap();
            assert_eq!(s.execute("analysis.soil.snapshot", &json!({})).unwrap(), after);
        }
    }

    #[test]
    fn invalid_or_unrelated_mcc_integration_never_changes_the_design() {
        let mut s = fixture();
        let before = s.doc.to_json();
        let undo = s.undo.len();
        for method in [json!(true), json!(3), json!({}), json!([]), json!("other")] {
            let mut invalid = request(&s);
            invalid["ground"]["materials"] = json!([{"id":1,"mcc":{}}]);
            invalid["stages"]["settings"] = json!({"mcc_integration":method});
            assert!(s.execute("analysis.soil.configure", &invalid).is_err());
            assert_eq!(s.doc.to_json(), before);
            assert_eq!(s.undo.len(), undo);
        }
        let mut unrelated = request(&s);
        unrelated["stages"]["settings"] = json!({"mcc_integration":"midpoint"});
        assert!(s.execute("analysis.soil.configure", &unrelated).is_err());
        assert_eq!(s.doc.to_json(), before);
        assert_eq!(s.undo.len(), undo);
    }

    #[test]
    fn projected_mcc_schema_roundtrips_and_refuses_unconnected_physics() {
        let mut s = fixture();
        let mut value = request(&s);
        value["ground"]["materials"][0]["mcc"] = json!({});
        value["stages"]["schema"] = json!("soil-fem-projected-mcc-stages/1");
        value["stages"]["settings"] = json!({"kinematics":"side_rollers"});
        assert!(required_body_labels(&value["ground"], &value["stages"]).is_ok());
        s.execute("analysis.soil.configure", &value).unwrap();
        let snapshot = s.execute("analysis.soil.snapshot", &json!({})).unwrap();
        assert_eq!(snapshot["snapshot"]["stages"]["schema"], "soil-fem-projected-mcc-stages/1");
        for schema in ["soil-fem-beams/1", "soil-fem-structures/1"] {
            let mut structural = value["stages"].clone();
            structural["beam_system"] = json!({"schema":schema});
            structural["stages"] = json!([{"kind":"install_structures","name":"install","members":["wall"],"placement":"cad_new_nodes"},{"kind":"remove_structures","name":"remove","members":["wall"]}]);
            assert!(required_body_labels(&value["ground"], &structural).is_ok());
        }
        let mut wet = value["ground"].clone();
        wet["initialization"]["water_level_m"] = json!(0.);
        assert!(required_body_labels(&wet, &value["stages"]).is_err());
        for key in ["joint_system", "beam_system", "anchor_system"] {
            let mut coupled = value["stages"].clone();
            coupled[key] = json!({});
            assert!(required_body_labels(&value["ground"], &coupled).is_err());
        }
        let mut birth = value["stages"].clone();
        birth["stages"] = json!([{"kind":"birth","name":"new soil"}]);
        assert!(required_body_labels(&value["ground"], &birth).is_err());
        let mut oedometer = value["stages"].clone();
        oedometer["settings"]["kinematics"] = json!("oedometer");
        assert!(required_body_labels(&value["ground"], &oedometer).is_err());
    }
}
