//! Reconstruct projected-MCC display fields from the authoritative primary and
//! material state. Reading a result never runs the external solver.
use super::native::{Frame, Geometry, PointMeta, Points};
use super::source_view::SourceRun;
use crate::{Result, params::bad};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet};

const CMD: &str = "analysis.soil.results";
const RESULT: &str = "soil-fem-projected-mcc-stage-result/1";
const EDGES: [[usize; 2]; 6] = [[0, 1], [1, 2], [2, 0], [0, 3], [1, 3], [2, 3]];

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Primary {
    pub original_node_ids: Vec<usize>,
    pub material_ids: Vec<u32>,
    pub positions_m: Vec<[f64; 3]>,
    pub mean_effective_stress_compression_positive_kpa: Vec<f64>,
    pub cumulative_material_volume_strain_compression_positive: Vec<f64>,
    pub frozen_compatibility_offset_m3: Vec<f64>,
}

pub(super) fn is_projected(run: &Value) -> bool {
    matches!(run.get("schema").and_then(Value::as_str), Some(RESULT | "soil-fem-projected-mcc-stage-result/2"))
}
pub(super) fn tensor(key: &str) -> bool {
    matches!(
        key,
        "work_conjugate_effective_stress_compression_positive_kpa"
            | "cumulative_material_engineering_strain_compression_positive"
            | "cumulative_kinematic_engineering_strain_compression_positive"
    )
}
pub(super) fn derived(key: &str) -> bool {
    tensor(key)
        || matches!(
            key,
            "primary_mean_effective_stress_compression_positive_kpa"
                | "material_mean_effective_stress_compression_positive_kpa"
                | "cumulative_material_volume_strain_compression_positive"
                | "cumulative_kinematic_volume_strain_compression_positive"
                | "material_minus_kinematic_volume_strain"
                | "reference_void_ratio"
                | "last_material_partition_count"
        )
}
pub(super) fn valid_extra(key: &str, value: &Value) -> bool {
    if tensor(key) {
        value.as_array().is_some_and(|v| v.len() == 6 && v.iter().all(|x| x.as_f64().is_some_and(|v| v.is_finite() && v.abs() <= 1e100)))
    } else {
        value.is_null() || value.as_f64().is_some_and(|v| v.is_finite() && v.abs() <= 1e100)
    }
}
fn number(value: Option<&Value>) -> Result<f64> {
    value.and_then(Value::as_f64).filter(|v| v.is_finite() && v.abs() <= 1e100).ok_or_else(|| bad(CMD, "invalid projected source number"))
}
fn array<const N: usize>(value: Option<&Value>) -> Result<[f64; N]>
where
    [f64; N]: serde::de::DeserializeOwned,
{
    let values: [f64; N] =
        serde_json::from_value(value.cloned().ok_or_else(|| bad(CMD, "missing projected source vector"))?).map_err(|e| bad(CMD, e.to_string()))?;
    if values.iter().any(|v| !v.is_finite() || v.abs() > 1e100) {
        return Err(bad(CMD, "invalid projected source vector"));
    }
    Ok(values)
}
fn state(run: &Value, index: usize) -> Result<&Value> {
    run.get("frames").and_then(|v| v.get(index)).and_then(|v| v.get("state")).ok_or_else(|| bad(CMD, "missing projected source state"))
}
fn rows(state: &Value, path: &str, field: &str) -> Result<BTreeMap<(usize, u32), f64>> {
    let rows = state
        .pointer(path)
        .and_then(Value::as_array)
        .filter(|a| a.len() <= 1_200_000)
        .ok_or_else(|| bad(CMD, "missing or oversized projected primary rows"))?;
    let mut out = BTreeMap::new();
    for row in rows {
        let node =
            row.get("node_index").and_then(Value::as_u64).and_then(|v| usize::try_from(v).ok()).ok_or_else(|| bad(CMD, "invalid primary node"))?;
        let material = row
            .get("material_id")
            .and_then(Value::as_u64)
            .and_then(|v| u32::try_from(v).ok())
            .filter(|v| *v > 0)
            .ok_or_else(|| bad(CMD, "invalid primary material"))?;
        if out.insert((node, material), number(row.get(field))?).is_some() {
            return Err(bad(CMD, "duplicate primary node/material pair"));
        }
    }
    Ok(out)
}

fn strain(g: &Geometry, cell: &[usize], bary: [f64; 4], u: &Value) -> Result<[f64; 6]> {
    if cell.len() != 10 {
        return Err(bad(CMD, "projected display requires Tet10"));
    }
    let dl = [[-1., -1., -1.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
    let mut dn = [[0.; 3]; 10];
    for i in 0..4 {
        for j in 0..3 {
            dn[i][j] = (4. * bary[i] - 1.) * dl[i][j];
        }
    }
    for (i, [a, b]) in EDGES.iter().copied().enumerate() {
        for j in 0..3 {
            dn[i + 4][j] = 4. * (dl[a][j] * bary[b] + dl[b][j] * bary[a]);
        }
    }
    let mut jac = [[0.; 3]; 3];
    for (i, node) in cell.iter().enumerate() {
        let p = g.nodes_m.get(*node).ok_or_else(|| bad(CMD, "missing projected geometry node"))?;
        for a in 0..3 {
            for b in 0..3 {
                jac[a][b] += p[a] * dn[i][b];
            }
        }
    }
    let [a, b, c] = jac;
    let cof = [
        [b[1] * c[2] - b[2] * c[1], a[2] * c[1] - a[1] * c[2], a[1] * b[2] - a[2] * b[1]],
        [b[2] * c[0] - b[0] * c[2], a[0] * c[2] - a[2] * c[0], a[2] * b[0] - a[0] * b[2]],
        [b[0] * c[1] - b[1] * c[0], a[1] * c[0] - a[0] * c[1], a[0] * b[1] - a[1] * b[0]],
    ];
    let det = a[0] * cof[0][0] + a[1] * cof[1][0] + a[2] * cof[2][0];
    if !det.is_finite() || det <= 0. {
        return Err(bad(CMD, "invalid projected Tet10 Jacobian"));
    }
    let mut grad_u = [[0.; 3]; 3];
    for (i, node) in cell.iter().enumerate() {
        let displacement: [f64; 3] = array(u.get(*node))?;
        for a in 0..3 {
            for b in 0..3 {
                let grad: f64 = (0..3).map(|k| dn[i][k] * cof[k][b] / det).sum();
                grad_u[a][b] -= displacement[a] * grad;
            }
        }
    }
    let out = [grad_u[0][0], grad_u[1][1], grad_u[2][2], grad_u[0][1] + grad_u[1][0], grad_u[1][2] + grad_u[2][1], grad_u[0][2] + grad_u[2][0]];
    if out.iter().any(|v| !v.is_finite()) {
        return Err(bad(CMD, "non-finite projected strain"));
    }
    Ok(out)
}

pub(super) struct Derived {
    p: f64,
    mean: f64,
    theta: f64,
    reference: f64,
    partitions: f64,
    kinematic: [f64; 6],
    material: [f64; 6],
    work: [f64; 6],
}
impl Derived {
    pub(super) fn scalar(&self, key: &str) -> Option<f64> {
        let volume: f64 = self.kinematic.iter().take(3).sum();
        match key {
            "primary_mean_effective_stress_compression_positive_kpa" => Some(self.p),
            "material_mean_effective_stress_compression_positive_kpa" => Some(self.mean),
            "cumulative_material_volume_strain_compression_positive" => Some(self.theta),
            "cumulative_kinematic_volume_strain_compression_positive" => Some(volume),
            "material_minus_kinematic_volume_strain" => Some(self.theta - volume),
            "reference_void_ratio" => Some(self.reference),
            "last_material_partition_count" => Some(self.partitions),
            _ => None,
        }
    }
    pub(super) fn vector(&self, key: &str) -> Option<[f64; 6]> {
        match key {
            "work_conjugate_effective_stress_compression_positive_kpa" => Some(self.work),
            "cumulative_material_engineering_strain_compression_positive" => Some(self.material),
            "cumulative_kinematic_engineering_strain_compression_positive" => Some(self.kinematic),
            _ => None,
        }
    }
}
pub(super) fn reconstruct(g: &Geometry, f: &Frame, run: &SourceRun, mesh: &Value, layout: &[PointMeta]) -> Result<Vec<Option<Derived>>> {
    let source = state(run, f.index)?;
    let p = rows(source, "/mixed_mcc/pressure_dofs", "compression_positive_kpa")?;
    let theta = rows(source, "/mixed_mcc/projected_volume/volume_dofs", "compression_positive")?;
    let offset = rows(source, "/mixed_mcc/projected_volume/compatibility_offsets", "integral_m3")?;
    let primary = f.mixed_primary.as_ref().ok_or_else(|| bad(CMD, "missing projected display primary state"))?;
    let n = p.len();
    if [
        primary.original_node_ids.len(),
        primary.material_ids.len(),
        primary.positions_m.len(),
        primary.mean_effective_stress_compression_positive_kpa.len(),
        primary.cumulative_material_volume_strain_compression_positive.len(),
        primary.frozen_compatibility_offset_m3.len(),
    ]
    .iter()
    .any(|v| *v != n)
    {
        return Err(bad(CMD, "projected primary field lengths differ"));
    }
    let materials = mesh.get("material_ids").and_then(Value::as_array).ok_or_else(|| bad(CMD, "missing projected material ids"))?;
    let mut expected = BTreeSet::new();
    for element in &f.active_element_ids {
        let cell = g.cells.get(*element).ok_or_else(|| bad(CMD, "missing projected cell"))?;
        let m = materials
            .get(*element)
            .and_then(Value::as_u64)
            .and_then(|v| u32::try_from(v).ok())
            .ok_or_else(|| bad(CMD, "invalid projected material"))?;
        for node in cell.iter().take(4) {
            expected.insert((*node, m));
        }
    }
    if p.keys().copied().collect::<BTreeSet<_>>() != expected
        || theta.keys().copied().collect::<BTreeSet<_>>() != expected
        || offset.keys().copied().collect::<BTreeSet<_>>() != expected
    {
        return Err(bad(CMD, "primary inventory differs from active corner/material pairs"));
    }
    let mut seen = BTreeSet::new();
    for row in 0..n {
        let node = *primary.original_node_ids.get(row).ok_or_else(|| bad(CMD, "missing primary node"))?;
        let m = *primary.material_ids.get(row).ok_or_else(|| bad(CMD, "missing primary material"))?;
        let key = (node, m);
        if !seen.insert(key) || !expected.contains(&key) || primary.positions_m.get(row) != g.nodes_m.get(node) {
            return Err(bad(CMD, "projected primary identities/positions differ"));
        }
        for (actual, expected) in [
            (primary.mean_effective_stress_compression_positive_kpa.get(row), p.get(&key)),
            (primary.cumulative_material_volume_strain_compression_positive.get(row), theta.get(&key)),
            (primary.frozen_compatibility_offset_m3.get(row), offset.get(&key)),
        ] {
            if actual.zip(expected).is_none_or(|(a, b)| !super::native::close_number(*a, *b, b.abs())) {
                return Err(bad(CMD, "projected primary value differs from source"));
            }
        }
    }
    if run.layout_count() != Some(layout.len()) {
        return Err(bad(CMD, "missing projected integration layout"));
    }
    let states = run.histories(f.index)?;
    if states.len() != layout.len() {
        return Err(bad(CMD, "missing projected material histories"));
    }
    let u = source.get("displacement_m").ok_or_else(|| bad(CMD, "missing projected displacements"))?;
    let active: BTreeSet<_> = f.active_element_ids.iter().copied().collect();
    let bytes = layout.len().checked_mul(std::mem::size_of::<Option<Derived>>()).ok_or_else(|| bad(CMD, "projected point cache size overflow"))?;
    if bytes > 512 << 20 {
        return Err(bad(CMD, "projected point cache exceeds retained budget"));
    }
    let mut out = Vec::new();
    out.try_reserve_exact(layout.len()).map_err(|_| bad(CMD, "cannot reserve projected point cache"))?;
    if out.capacity().checked_mul(std::mem::size_of::<Option<Derived>>()).is_none_or(|v| v > 512 << 20) {
        return Err(bad(CMD, "projected point allocation exceeds retained budget"));
    }
    for (id, meta) in layout.iter().enumerate() {
        if !active.contains(&meta.element_index) {
            out.push(None);
            continue;
        }
        let natural = run.natural(id)?;
        let bary = [1. - natural.iter().sum::<f64>(), natural[0], natural[1], natural[2]];
        let cell = g.cells.get(meta.element_index).filter(|c| c.len() == 10).ok_or_else(|| bad(CMD, "projected source requires Tet10"))?;
        let m = materials
            .get(meta.element_index)
            .and_then(Value::as_u64)
            .and_then(|v| u32::try_from(v).ok())
            .ok_or_else(|| bad(CMD, "missing projected material"))?;
        let mut pressure = 0.;
        for (a, node) in cell.iter().take(4).enumerate() {
            pressure += bary[a] * p.get(&(*node, m)).ok_or_else(|| bad(CMD, "missing primary corner"))?;
        }
        let original = states.get(id).ok_or_else(|| bad(CMD, "missing projected history"))?;
        let mut work = original.tensor("effective_stress_compression_positive_kpa")?;
        let mean = work.iter().take(3).sum::<f64>() / 3.;
        for value in work.iter_mut().take(3) {
            *value += pressure - mean;
        }
        let kinematic = strain(g, cell, bary, u)?;
        let volume = number(source.pointer("/mixed_mcc/cumulative_volume_strain_compression_positive").and_then(|v| v.get(id)))?;
        let mut material = kinematic;
        let correction = (volume - kinematic.iter().take(3).sum::<f64>()) / 3.;
        for value in material.iter_mut().take(3) {
            *value += correction;
        }
        out.push(Some(Derived {
            p: pressure,
            mean,
            theta: volume,
            kinematic,
            material,
            work,
            reference: number(source.pointer("/mixed_mcc/reference_void_ratio").and_then(|v| v.get(id)))?,
            partitions: number(source.pointer("/mixed_mcc/last_increment_partitions").and_then(|v| v.get(id)))?,
        }));
    }
    Ok(out)
}

pub(super) fn validate(g: &Geometry, f: &Frame, run: &SourceRun, mesh: &Value, layout: &[PointMeta]) -> Result<()> {
    if !is_projected(run) {
        if f.mixed_primary.is_some() {
            return Err(bad(CMD, "projected display attached to another source family"));
        }
        return Ok(());
    }
    if f.field_semantics.get("equilibrium_stress").and_then(Value::as_str) != Some("work_conjugate_effective_stress_compression_positive_kpa")
        || !f.mixed_equation_audit.is_object()
    {
        return Err(bad(CMD, "projected stress semantics/audit missing"));
    }
    let values = reconstruct(g, f, run, mesh, layout)?;
    let mut groups = vec![Vec::new(); g.cells.len()];
    for (id, meta) in layout.iter().enumerate() {
        if let Some(group) = groups.get_mut(meta.element_index) {
            group.push(id);
        }
    }
    let names = [
        "primary_mean_effective_stress_compression_positive_kpa",
        "material_mean_effective_stress_compression_positive_kpa",
        "cumulative_material_volume_strain_compression_positive",
        "cumulative_kinematic_volume_strain_compression_positive",
        "material_minus_kinematic_volume_strain",
        "reference_void_ratio",
        "last_material_partition_count",
        "work_conjugate_effective_stress_compression_positive_kpa",
        "cumulative_material_engineering_strain_compression_positive",
        "cumulative_kinematic_engineering_strain_compression_positive",
    ];
    for (row, element) in f.active_element_ids.iter().enumerate() {
        let ids = groups.get(*element).filter(|v| !v.is_empty()).ok_or_else(|| bad(CMD, "missing projected cell points"))?;
        let weight: f64 = ids.iter().filter_map(|i| layout.get(*i)).map(|p| p.weight_m3).sum();
        if !weight.is_finite() || weight <= 0. {
            return Err(bad(CMD, "invalid projected cell measure"));
        }
        for key in names {
            let actual = f.cell_fields.other.get(key).and_then(|v| v.get(row)).ok_or_else(|| bad(CMD, "missing projected cell field"))?;
            for component in 0..if tensor(key) { 6 } else { 1 } {
                let mut sum = 0.;
                let mut scale = 0.0f64;
                for id in ids {
                    let value = values.get(*id).and_then(Option::as_ref).ok_or_else(|| bad(CMD, "missing projected source point"))?;
                    let v = if tensor(key) { value.vector(key).and_then(|v| v.get(component).copied()) } else { value.scalar(key) }
                        .ok_or_else(|| bad(CMD, "unknown projected field"))?;
                    let p = layout.get(*id).ok_or_else(|| bad(CMD, "missing projected weight"))?;
                    sum += v * p.weight_m3;
                    scale = scale.max(v.abs());
                }
                let observed = number(if tensor(key) { actual.get(component) } else { Some(actual) })?;
                if !super::native::close_number(observed, sum / weight, (scale * ids.len() as f64).max(1.)) {
                    return Err(bad(CMD, "projected cell field differs from reconstructed source"));
                }
            }
        }
    }
    Ok(())
}

pub(super) fn validate_points(g: &Geometry, f: &Frame, run: &SourceRun, mesh: &Value, layout: &[PointMeta], points: &Points) -> Result<()> {
    if !is_projected(run) {
        return Ok(());
    }
    let expected = reconstruct(g, f, run, mesh, layout)?;
    for name in f.cell_fields.other.keys().filter(|key| derived(key)) {
        if !points.fields.other.contains_key(name) {
            return Err(bad(CMD, "projected raw field missing"));
        }
    }
    for (key, rows) in &points.fields.other {
        if !derived(key) {
            continue;
        }
        for (row, id) in points.integration_point_ids.iter().enumerate() {
            let value = expected.get(*id).and_then(Option::as_ref).ok_or_else(|| bad(CMD, "missing projected raw source point"))?;
            let actual = rows.get(row).ok_or_else(|| bad(CMD, "missing projected raw field"))?;
            for component in 0..if tensor(key) { 6 } else { 1 } {
                let original = if tensor(key) { value.vector(key).and_then(|v| v.get(component).copied()) } else { value.scalar(key) }
                    .ok_or_else(|| bad(CMD, "unknown projected raw field"))?;
                let observed = number(if tensor(key) { actual.get(component) } else { Some(actual) })?;
                if !super::native::close_number(observed, original, original.abs().max(1.)) {
                    return Err(bad(CMD, "projected raw field differs from reconstructed source"));
                }
            }
        }
    }
    Ok(())
}
