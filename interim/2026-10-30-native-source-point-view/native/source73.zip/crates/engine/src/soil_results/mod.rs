//! Native, version-bound FEM result viewing. All quantities and geometry remain
//! separate from the CAD document, its appearances and its undo history.
#[cfg(not(target_arch = "wasm32"))]
mod attachments;
#[cfg(not(target_arch = "wasm32"))]
mod geometry;
#[cfg(not(target_arch = "wasm32"))]
mod native;
#[cfg(not(target_arch = "wasm32"))]
mod projected;
#[cfg(not(target_arch = "wasm32"))]
mod source_compact;
#[cfg(not(target_arch = "wasm32"))]
mod source_points;
#[cfg(not(target_arch = "wasm32"))]
mod source_stream;
#[cfg(not(target_arch = "wasm32"))]
mod source_view;
#[cfg(not(target_arch = "wasm32"))]
mod structures;
#[cfg(not(target_arch = "wasm32"))]
pub use native::*;

#[cfg(target_arch = "wasm32")]
#[derive(Default)]
pub(crate) struct Results;

#[cfg(target_arch = "wasm32")]
pub fn unavailable(_: &mut crate::Session, _: &serde_json::Value) -> crate::Result<serde_json::Value> {
    Err(crate::params::bad("analysis.soil.results", "FEM result loading requires the native desktop application"))
}
#[cfg(target_arch = "wasm32")]
pub use unavailable as open;
#[cfg(target_arch = "wasm32")]
pub use unavailable as configure;
#[cfg(target_arch = "wasm32")]
pub use unavailable as status;
#[cfg(target_arch = "wasm32")]
pub use unavailable as query;
#[cfg(target_arch = "wasm32")]
pub use unavailable as close;
