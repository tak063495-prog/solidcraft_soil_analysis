//! Hash the complete authoritative result while retaining one frame and its
//! previous displacement. Skipped histories remain in the immutable source.
use serde::Deserializer;
use serde::de::{self, DeserializeSeed, IgnoredAny, MapAccess, SeqAccess, Visitor};
use serde_json::{Map, Number, Value};
use sha2::{Digest, Sha256};
use std::cell::Cell;
use std::collections::BTreeSet;
use std::fmt;
use std::io::{self, BufReader, Read};

struct Hashed<R> {
    inner: R,
    bytes: usize,
    maximum: usize,
    digest: Sha256,
}
impl<R: Read> Read for Hashed<R> {
    fn read(&mut self, out: &mut [u8]) -> io::Result<usize> {
        let remaining = self.maximum.saturating_sub(self.bytes);
        let allowed = out.len().min(remaining.saturating_add(1));
        let n = self.inner.read(&mut out[..allowed])?;
        if n > remaining {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "authoritative result exceeds source byte budget"));
        }
        self.bytes += n;
        self.digest.update(&out[..n]);
        Ok(n)
    }
}
struct Budget(Cell<usize>);
impl Budget {
    fn charge<E: de::Error>(&self, n: usize) -> Result<(), E> {
        let left = self.0.get().checked_sub(n).ok_or_else(|| E::custom("selected source exceeds retained payload budget"))?;
        self.0.set(left);
        Ok(())
    }
}
#[derive(Clone, Copy)]
struct Keep<'a>(&'a Budget);
impl<'de> DeserializeSeed<'de> for Keep<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        self.0.charge::<D::Error>(64)?;
        d.deserialize_any(self)
    }
}
impl<'de> Visitor<'de> for Keep<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded JSON value")
    }
    fn visit_bool<E: de::Error>(self, v: bool) -> Result<Value, E> {
        Ok(Value::Bool(v))
    }
    fn visit_i64<E: de::Error>(self, v: i64) -> Result<Value, E> {
        Ok(v.into())
    }
    fn visit_u64<E: de::Error>(self, v: u64) -> Result<Value, E> {
        Ok(v.into())
    }
    fn visit_f64<E: de::Error>(self, v: f64) -> Result<Value, E> {
        Number::from_f64(v).map(Value::Number).ok_or_else(|| E::custom("non-finite source number"))
    }
    fn visit_unit<E: de::Error>(self) -> Result<Value, E> {
        Ok(Value::Null)
    }
    fn visit_str<E: de::Error>(self, v: &str) -> Result<Value, E> {
        self.0.charge::<E>(v.len().saturating_mul(2))?;
        Ok(Value::String(v.to_owned()))
    }
    fn visit_string<E: de::Error>(self, v: String) -> Result<Value, E> {
        self.0.charge::<E>(v.len().saturating_mul(2))?;
        Ok(Value::String(v))
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Vec::new();
        while let Some(v) = a.next_element_seed(self)? {
            values.push(v);
        }
        Ok(Value::Array(values))
    }
    fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Map::new();
        while let Some(key) = a.next_key::<String>()? {
            self.0.charge::<A::Error>(64usize.saturating_add(key.len().saturating_mul(2)))?;
            if values.contains_key(&key) {
                return Err(de::Error::custom("duplicate retained source key"));
            }
            values.insert(key, a.next_value_seed(self)?);
        }
        Ok(Value::Object(values))
    }
}
#[derive(Clone, Copy)]
enum Mode {
    Root,
    PreviousFrame,
    PreviousState,
    Audit,
    Prepared,
}
#[derive(Clone, Copy)]
struct Select<'a> {
    budget: &'a Budget,
    frame: usize,
    mode: Mode,
}
impl<'de> DeserializeSeed<'de> for Select<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        self.budget.charge::<D::Error>(64)?;
        d.deserialize_map(self)
    }
}
impl<'de> Visitor<'de> for Select<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("authoritative source object")
    }
    fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Map::new();
        let mut seen = BTreeSet::new();
        while let Some(key) = a.next_key::<String>()? {
            self.budget.charge::<A::Error>(64usize.saturating_add(key.len().saturating_mul(2)))?;
            if seen.len() >= 256 || !seen.insert(key.clone()) {
                return Err(de::Error::custom("duplicate or excessive source keys"));
            }
            let nested = |mode| Select { mode, ..self };
            let value = match (self.mode, key.as_str()) {
                (Mode::Root, "frames") => Some(a.next_value_seed(Frames(self))?),
                (Mode::Root, "transition_audits") => Some(a.next_value_seed(Audits(self))?),
                (Mode::Root, "schema" | "case" | "complete" | "failure_reason" | "reference_displacement_m" | "integration_points")
                | (Mode::PreviousState | Mode::Prepared, "displacement_m")
                | (Mode::Audit, "stage") => Some(a.next_value_seed(Keep(self.budget))?),
                (Mode::PreviousFrame, "state") => Some(a.next_value_seed(nested(Mode::PreviousState))?),
                (Mode::Audit, "prepared_state") => Some(a.next_value_seed(nested(Mode::Prepared))?),
                _ => {
                    a.next_value::<IgnoredAny>()?;
                    None
                }
            };
            if let Some(value) = value {
                values.insert(key, value);
            }
        }
        Ok(Value::Object(values))
    }
}
struct Frames<'a>(Select<'a>);
impl<'de> DeserializeSeed<'de> for Frames<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        d.deserialize_seq(self)
    }
}
impl<'de> Visitor<'de> for Frames<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("at most257 source frames")
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut frames = Vec::new();
        loop {
            let i = frames.len();
            let value = if i == self.0.frame {
                a.next_element_seed(Keep(self.0.budget))?
            } else if i == self.0.frame.saturating_sub(1) {
                a.next_element_seed(Select { mode: Mode::PreviousFrame, ..self.0 })?
            } else {
                a.next_element::<IgnoredAny>()?.map(|_| Value::Null)
            };
            let Some(value) = value else { break };
            if i >= 257 {
                return Err(de::Error::custom("too many source frames"));
            }
            self.0.budget.charge::<A::Error>(64)?;
            frames.push(value);
        }
        if frames.len() <= self.0.frame {
            return Err(de::Error::custom("selected source frame is missing"));
        }
        Ok(Value::Array(frames))
    }
}
struct Audits<'a>(Select<'a>);
impl<'de> DeserializeSeed<'de> for Audits<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        d.deserialize_seq(self)
    }
}
impl<'de> Visitor<'de> for Audits<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded transition audits")
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Vec::new();
        while let Some(v) = a.next_element_seed(Select { mode: Mode::Audit, ..self.0 })? {
            if values.len() >= 512 {
                return Err(de::Error::custom("too many source transition audits"));
            }
            values.push(v);
        }
        Ok(Value::Array(values))
    }
}

pub(super) fn whole<R: Read>(reader: R, source_limit: usize, retained_budget: usize) -> Result<(Value, String), String> {
    if source_limit == 0 || retained_budget == 0 {
        return Err("invalid complete source reader budget".into());
    }
    let budget = Budget(Cell::new(retained_budget));
    let hash = Hashed { inner: reader, bytes: 0, maximum: source_limit, digest: Sha256::new() };
    let mut input = BufReader::with_capacity(64 << 10, hash);
    let mut d = serde_json::Deserializer::from_reader(&mut input);
    let value = Keep(&budget).deserialize(&mut d).map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())?;
    Ok((value, format!("{:x}", input.get_ref().digest.clone().finalize())))
}

pub(super) fn selected<R: Read>(reader: R, frame: usize, source_limit: usize, retained_budget: usize) -> Result<(Value, String), String> {
    if frame >= 257 || source_limit == 0 || retained_budget == 0 {
        return Err("invalid source reader budget/frame".into());
    }
    let budget = Budget(Cell::new(retained_budget));
    let hash = Hashed { inner: reader, bytes: 0, maximum: source_limit, digest: Sha256::new() };
    let mut input = BufReader::with_capacity(64 << 10, hash);
    let mut d = serde_json::Deserializer::from_reader(&mut input);
    let value = Select { budget: &budget, frame, mode: Mode::Root }.deserialize(&mut d).map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())?;
    Ok((value, format!("{:x}", input.get_ref().digest.clone().finalize())))
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    #[test]
    fn complete_dedicated_snapshot_retains_all_fields_and_enforces_both_budgets() {
        let raw = br#"{"schema":"snapshot","payload":{"state":[1,2,3],"removed":[4,5]}}"#;
        let (value, hash) = whole(raw.as_slice(), raw.len(), 4096).expect("fixture");
        assert_eq!(value["payload"]["removed"], json!([4, 5]));
        assert_eq!(hash, format!("{:x}", Sha256::digest(raw)));
        assert!(whole(raw.as_slice(), raw.len() - 1, 4096).is_err());
        assert!(whole(raw.as_slice(), raw.len(), 64).is_err());
        assert!(whole(br#"{"x":1,"x":2}"#.as_slice(), 100, 4096).is_err());
        assert!(whole(br#"[1e999]"#.as_slice(), 100, 4096).is_err());
        assert!(whole(br#"{} []"#.as_slice(), 100, 4096).is_err());
    }
    #[test]
    fn complete_source_hash_and_only_requested_physical_frame_are_retained() {
        let source = json!({"schema":"test","complete":true,"case":{"stages":[{"kind":"birth"}]},"integration_points":[{"element":0}],"reference_displacement_m":[[0,0,0]],"geostatic":{"discarded":"x".repeat(100_000)},"frames":[{"name":"a","state":{"displacement_m":[[1,2,3]],"material_states":[1]}},{"name":"b","state":{"displacement_m":[[4,5,6]],"material_states":[2]}},{"name":"c","state":{"displacement_m":[[7,8,9]],"material_states":[3]}}],"transition_audits":[{"stage":"b","prepared_state":{"displacement_m":[[2,3,4]],"material_states":[5]}}]});
        let raw = serde_json::to_vec_pretty(&source).expect("fixture");
        for frame in 0..3 {
            let (value, hash) = selected(raw.as_slice(), frame, raw.len(), 32 << 10).expect("bounded selection");
            assert_eq!(hash, format!("{:x}", Sha256::digest(&raw)));
            assert_eq!(value["frames"][frame], source["frames"][frame]);
            if frame > 0 {
                assert_eq!(value["frames"][frame - 1]["state"]["displacement_m"], source["frames"][frame - 1]["state"]["displacement_m"]);
            }
            assert!(value.get("geostatic").is_none());
            assert!(value["transition_audits"][0]["prepared_state"].get("material_states").is_none());
        }
    }
    #[test]
    fn byte_payload_frame_duplicate_and_malformed_input_limits_are_independent() {
        let raw = br#"{"complete":true,"frames":[{"state":{"displacement_m":[[0,0,0]]}}]}"#;
        assert!(selected(raw.as_slice(), 0, raw.len() - 1, 1 << 20).is_err());
        assert!(selected(raw.as_slice(), 0, raw.len(), 64).is_err());
        assert!(selected(raw.as_slice(), 1, raw.len(), 1 << 20).is_err());
        for source in
            [r#"{"frames":[],"frames":[]}"#, r#"{"frames":[{"a":1,"a":2}]}"#, r#"{"frames":[{}],"ignored":[1,]}"#, r#"{"frames":[{}]} true"#]
        {
            assert!(selected(source.as_bytes(), 0, 1 << 20, 1 << 20).is_err());
        }
    }
}
