//! Hash the complete authoritative result while retaining one frame and its
//! previous displacement. Skipped histories remain in the immutable source.
use serde::de::DeserializeOwned;
use serde::de::{self, DeserializeSeed, IgnoredAny, MapAccess, SeqAccess, Visitor};
use serde::{Deserialize, Deserializer, Serialize};
use serde_json::{Map, Number, Value};
use sha2::{Digest, Sha256};
use std::cell::Cell;
use std::collections::BTreeSet;
use std::fmt;
use std::io::{self, BufReader, Read};
use std::marker::PhantomData;

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub(super) struct MccState {
    pub effective_stress_compression_positive_kpa: [f64; 6],
    pub void_ratio: f64,
    pub preconsolidation_pressure_kpa: f64,
    pub plastic_strain_compression_positive: [f64; 6],
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub(super) struct Point {
    pub element_index: usize,
    pub local_index: usize,
    pub natural_coordinates: [f64; 3],
    pub shape_functions: [f64; 10],
    pub position_m: [f64; 3],
    pub weight_m3: f64,
}
trait Valid {
    fn valid(&self) -> bool;
}
fn finite(v: f64) -> bool {
    v.is_finite() && v.abs() <= 1e100
}
impl Valid for MccState {
    fn valid(&self) -> bool {
        self.effective_stress_compression_positive_kpa.iter().chain(&self.plastic_strain_compression_positive).all(|v| finite(*v))
            && finite(self.void_ratio)
            && self.void_ratio > -1.
            && finite(self.preconsolidation_pressure_kpa)
            && self.preconsolidation_pressure_kpa > 0.
    }
}
impl Valid for Point {
    fn valid(&self) -> bool {
        self.element_index < 300_000
            && self.local_index < 512
            && self.natural_coordinates.iter().all(|v| finite(*v) && *v >= -1e-12)
            && self.natural_coordinates.iter().sum::<f64>() <= 1. + 1e-12
            && self.shape_functions.iter().all(|v| finite(*v))
            && (self.shape_functions.iter().sum::<f64>() - 1.).abs() < 1e-12
            && self.position_m.iter().all(|v| finite(*v))
            && finite(self.weight_m3)
            && self.weight_m3 > 0.
    }
}
#[derive(Default)]
struct Slots {
    points: Cell<Option<Vec<Point>>>,
    states: Cell<Option<Vec<MccState>>>,
}
pub(super) struct Selected {
    pub value: Value,
    pub states: Vec<MccState>,
    pub points: Vec<Point>,
    pub digest: String,
    pub accounted_bytes: usize,
}
struct Typed<'a, T>(&'a Budget, PhantomData<T>);
impl<'de, T: DeserializeOwned + Valid> DeserializeSeed<'de> for Typed<'_, T> {
    type Value = Vec<T>;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Vec<T>, D::Error> {
        d.deserialize_seq(self)
    }
}
impl<'de, T: DeserializeOwned + Valid> Visitor<'de> for Typed<'_, T> {
    type Value = Vec<T>;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded typed MCC/point array")
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Vec<T>, A::Error> {
        let mut values = Vec::new();
        while let Some(v) = a.next_element::<T>()? {
            if values.len() >= 5_000_000 || !v.valid() {
                return Err(de::Error::custom("invalid or excessive typed source entries"));
            }
            // Reserve an explicit bounded capacity, rather than relying on
            // Vec's minimum initial allocation. Charge twice the allocation
            // delta before growth, covering both old and new buffers.
            if values.len() == values.capacity() {
                let previous = values.capacity();
                let next = previous.saturating_mul(2).max(1);
                let bytes = next
                    .checked_sub(previous)
                    .and_then(|n| n.checked_mul(std::mem::size_of::<T>()))
                    .and_then(|n| n.checked_mul(2))
                    .ok_or_else(|| de::Error::custom("typed capacity overflow"))?;
                self.0.charge::<A::Error>(bytes)?;
                values.try_reserve_exact(next - values.len()).map_err(de::Error::custom)?;
                if values.capacity() > next {
                    self.0.charge::<A::Error>((values.capacity() - next).saturating_mul(std::mem::size_of::<T>()).saturating_mul(2))?;
                }
            }
            values.push(v);
        }
        Ok(values)
    }
}

struct Hashed<R> {
    inner: R,
    bytes: usize,
    maximum: usize,
    digest: Sha256,
}
impl<R: Read> Read for Hashed<R> {
    fn read(&mut self, out: &mut [u8]) -> io::Result<usize> {
        let remaining = self.maximum.saturating_sub(self.bytes);
        let allowed = out.len().min(remaining.saturating_add(1));
        let n = self.inner.read(&mut out[..allowed])?;
        if n > remaining {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "authoritative result exceeds source byte budget"));
        }
        self.bytes += n;
        self.digest.update(&out[..n]);
        Ok(n)
    }
}
struct Budget(Cell<usize>);
impl Budget {
    fn charge<E: de::Error>(&self, n: usize) -> Result<(), E> {
        let left = self.0.get().checked_sub(n).ok_or_else(|| E::custom("selected source exceeds retained payload budget"))?;
        self.0.set(left);
        Ok(())
    }
}
#[derive(Clone, Copy)]
struct Keep<'a>(&'a Budget);
impl<'de> DeserializeSeed<'de> for Keep<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        self.0.charge::<D::Error>(64)?;
        d.deserialize_any(self)
    }
}
impl<'de> Visitor<'de> for Keep<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded JSON value")
    }
    fn visit_bool<E: de::Error>(self, v: bool) -> Result<Value, E> {
        Ok(Value::Bool(v))
    }
    fn visit_i64<E: de::Error>(self, v: i64) -> Result<Value, E> {
        Ok(v.into())
    }
    fn visit_u64<E: de::Error>(self, v: u64) -> Result<Value, E> {
        Ok(v.into())
    }
    fn visit_f64<E: de::Error>(self, v: f64) -> Result<Value, E> {
        Number::from_f64(v).map(Value::Number).ok_or_else(|| E::custom("non-finite source number"))
    }
    fn visit_unit<E: de::Error>(self) -> Result<Value, E> {
        Ok(Value::Null)
    }
    fn visit_str<E: de::Error>(self, v: &str) -> Result<Value, E> {
        self.0.charge::<E>(v.len().saturating_mul(2))?;
        Ok(Value::String(v.to_owned()))
    }
    fn visit_string<E: de::Error>(self, v: String) -> Result<Value, E> {
        self.0.charge::<E>(v.len().saturating_mul(2))?;
        Ok(Value::String(v))
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Vec::new();
        while let Some(v) = a.next_element_seed(self)? {
            values.push(v);
        }
        Ok(Value::Array(values))
    }
    fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Map::new();
        while let Some(key) = a.next_key::<String>()? {
            self.0.charge::<A::Error>(64usize.saturating_add(key.len().saturating_mul(2)))?;
            if values.contains_key(&key) {
                return Err(de::Error::custom("duplicate retained source key"));
            }
            values.insert(key, a.next_value_seed(self)?);
        }
        Ok(Value::Object(values))
    }
}
#[derive(Clone, Copy)]
enum Mode {
    Root,
    SelectedFrame,
    SelectedState,
    PreviousFrame,
    PreviousState,
    Audit,
    Prepared,
}
#[derive(Clone, Copy)]
struct Select<'a> {
    budget: &'a Budget,
    slots: &'a Slots,
    frame: usize,
    mode: Mode,
}
impl<'de> DeserializeSeed<'de> for Select<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        self.budget.charge::<D::Error>(64)?;
        d.deserialize_map(self)
    }
}
impl<'de> Visitor<'de> for Select<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("authoritative source object")
    }
    fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Map::new();
        let mut seen = BTreeSet::new();
        while let Some(key) = a.next_key::<String>()? {
            self.budget.charge::<A::Error>(64usize.saturating_add(key.len().saturating_mul(2)))?;
            if seen.len() >= 256 || !seen.insert(key.clone()) {
                return Err(de::Error::custom("duplicate or excessive source keys"));
            }
            let nested = |mode| Select { mode, ..self };
            let value = match (self.mode, key.as_str()) {
                (Mode::Root, "frames") => Some(a.next_value_seed(Frames(self))?),
                (Mode::Root, "integration_points") => {
                    let points = a.next_value_seed(Typed::<Point>(self.budget, PhantomData))?;
                    if self.slots.points.replace(Some(points)).is_some() {
                        return Err(de::Error::custom("duplicate source point layout"));
                    }
                    None
                }
                (Mode::SelectedFrame, "state") => Some(a.next_value_seed(nested(Mode::SelectedState))?),
                (Mode::SelectedState, "material_states") => {
                    let states = a.next_value_seed(Typed::<MccState>(self.budget, PhantomData))?;
                    if self.slots.states.replace(Some(states)).is_some() {
                        return Err(de::Error::custom("duplicate selected material history"));
                    }
                    None
                }
                (Mode::Root, "transition_audits") => Some(a.next_value_seed(Audits(self))?),
                (Mode::Root, "schema" | "case" | "complete" | "failure_reason" | "reference_displacement_m")
                | (Mode::PreviousState | Mode::Prepared, "displacement_m")
                | (Mode::Audit, "stage") => Some(a.next_value_seed(Keep(self.budget))?),
                (Mode::PreviousFrame, "state") => Some(a.next_value_seed(nested(Mode::PreviousState))?),
                (Mode::Audit, "prepared_state") => Some(a.next_value_seed(nested(Mode::Prepared))?),
                (Mode::SelectedFrame | Mode::SelectedState, _) => Some(a.next_value_seed(Keep(self.budget))?),
                _ => {
                    a.next_value::<IgnoredAny>()?;
                    None
                }
            };
            if let Some(value) = value {
                values.insert(key, value);
            }
        }
        Ok(Value::Object(values))
    }
}
struct Frames<'a>(Select<'a>);
impl<'de> DeserializeSeed<'de> for Frames<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        d.deserialize_seq(self)
    }
}
impl<'de> Visitor<'de> for Frames<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("at most257 source frames")
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut frames = Vec::new();
        loop {
            let i = frames.len();
            let value = if i == self.0.frame {
                a.next_element_seed(Select { mode: Mode::SelectedFrame, ..self.0 })?
            } else if i == self.0.frame.saturating_sub(1) {
                a.next_element_seed(Select { mode: Mode::PreviousFrame, ..self.0 })?
            } else {
                a.next_element::<IgnoredAny>()?.map(|_| Value::Null)
            };
            let Some(value) = value else { break };
            if i >= 257 {
                return Err(de::Error::custom("too many source frames"));
            }
            self.0.budget.charge::<A::Error>(64)?;
            frames.push(value);
        }
        if frames.len() <= self.0.frame {
            return Err(de::Error::custom("selected source frame is missing"));
        }
        Ok(Value::Array(frames))
    }
}
struct Audits<'a>(Select<'a>);
impl<'de> DeserializeSeed<'de> for Audits<'_> {
    type Value = Value;
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<Value, D::Error> {
        d.deserialize_seq(self)
    }
}
impl<'de> Visitor<'de> for Audits<'_> {
    type Value = Value;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded transition audits")
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Value, A::Error> {
        let mut values = Vec::new();
        while let Some(v) = a.next_element_seed(Select { mode: Mode::Audit, ..self.0 })? {
            if values.len() >= 512 {
                return Err(de::Error::custom("too many source transition audits"));
            }
            values.push(v);
        }
        Ok(Value::Array(values))
    }
}

pub(super) fn selected<R: Read>(reader: R, frame: usize, source_limit: usize, retained_budget: usize) -> Result<Selected, String> {
    if frame >= 257 || source_limit == 0 || retained_budget == 0 {
        return Err("invalid source reader budget/frame".into());
    }
    let budget = Budget(Cell::new(retained_budget));
    let slots = Slots::default();
    let hash = Hashed { inner: reader, bytes: 0, maximum: source_limit, digest: Sha256::new() };
    let mut input = BufReader::with_capacity(64 << 10, hash);
    let mut d = serde_json::Deserializer::from_reader(&mut input);
    let value = Select { budget: &budget, slots: &slots, frame, mode: Mode::Root }.deserialize(&mut d).map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())?;
    let states = slots.states.take().ok_or("selected MCC histories missing")?;
    let points = slots.points.take().ok_or("source integration layout missing")?;
    if states.is_empty() || states.len() != points.len() {
        return Err("source point/history count mismatch".into());
    }
    let schema = value.get("schema").and_then(Value::as_str).ok_or("source schema missing")?;
    if !matches!(schema, "soil-fem-projected-mcc-stage-result/1" | "soil-fem-projected-mcc-stage-result/2") {
        return Err("typed prototype supports projected MCC only".into());
    }
    if value.get("complete").and_then(Value::as_bool) != Some(true) {
        return Err("ordinary source not complete".into());
    }
    Ok(Selected {
        value,
        states,
        points,
        digest: format!("{:x}", input.get_ref().digest.clone().finalize()),
        accounted_bytes: retained_budget - budget.0.get(),
    })
}

#[cfg(test)]
#[path = "compact_tests.rs"]
mod tests;
