//! Raw linear frame/plate fields: source-bound, separate from continuum means.
use super::native::{Frame, Geometry};
use super::native::{MemberLine, Quantity, Scene, Settings, Triangle, Vertex};
use crate::geom::{Aabb3, Vec3};
use crate::{Result, params::bad};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};

const CMD: &str = "analysis.soil.results";
const LIMIT: usize = 10_000;

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Nodes {
    pub ids: Vec<String>,
    pub positions_m: Vec<[f64; 3]>,
    pub soil_node_ids: Vec<Option<usize>>,
    pub displacement_m: Vec<[f64; 3]>,
    pub rotation_rad: Vec<[f64; 3]>,
    pub active: Vec<bool>,
}
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Entry {
    pub id: String,
    pub nodes: Vec<usize>,
    pub section_id: String,
    pub active: bool,
    pub reference_global_kinematics: Vec<f64>,
    pub result: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub thickness_m: Option<f64>,
}
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Fields {
    pub schema: String,
    pub nodes: Nodes,
    pub members: Vec<Entry>,
    pub plates: Vec<Entry>,
    pub global_resultants: BTreeMap<String, [f64; 3]>,
    pub semantics: Value,
}
pub(super) fn semantics() -> Value {
    json!({"coordinates":"CAD metres; displacement from CAD; soil display RESET is not applied",
        "beam_section_components":["axial_N","shear_Vy","shear_Vz","torsion_T","moment_My","moment_Mz"],
        "beam_section_units":["kN","kN","kN","kN m","kN m","kN m"],
        "beam_samples":"start, middle, end; exact local axes and end releases retained",
        "plate_components":["xx","yy","xy"],"plate_membrane":"tension-positive kN/m",
        "plate_bending":"kN m/m; positive with reported local curvature; xy is engineering twist",
        "plate_samples":"raw DKT barycentric locations; no nodal averaging",
        "inactive":"archived node kinematics and installation references retained; result null"})
}

fn finite(v: f64) -> bool {
    v.is_finite() && v.abs() <= 1e100
}
fn number(value: Option<&Value>) -> Result<f64> {
    value.and_then(Value::as_f64).filter(|v| finite(*v)).ok_or_else(|| bad(CMD, "invalid structural scalar"))
}
pub(super) fn vector<const N: usize>(value: Option<&Value>) -> Result<[f64; N]>
where
    [f64; N]: serde::de::DeserializeOwned,
{
    let v: [f64; N] =
        serde_json::from_value(value.cloned().ok_or_else(|| bad(CMD, "missing structural vector"))?).map_err(|e| bad(CMD, e.to_string()))?;
    if !v.iter().copied().all(finite) {
        return Err(bad(CMD, "nonfinite or oversized structural vector"));
    }
    Ok(v)
}
fn same(a: &Value, b: &Value) -> bool {
    match (a, b) {
        (Value::Number(a), Value::Number(b)) => {
            a.as_f64().zip(b.as_f64()).is_some_and(|(a, b)| finite(a) && finite(b) && (a - b).abs() <= 1e-12 + 1e-11 * a.abs().max(b.abs()))
        }
        (Value::Array(a), Value::Array(b)) => a.len() == b.len() && a.iter().zip(b).all(|(a, b)| same(a, b)),
        (Value::Object(a), Value::Object(b)) => a.len() == b.len() && a.iter().all(|(key, a)| b.get(key).is_some_and(|b| same(a, b))),
        _ => a == b,
    }
}
fn bound(actual: &Value, expected: Option<&Value>) -> Result<()> {
    if !expected.is_some_and(|expected| same(actual, expected)) {
        return Err(bad(CMD, "structural display differs from authoritative member history/report"));
    }
    Ok(())
}
fn values(value: Option<&Value>, maximum: usize) -> Result<&[Value]> {
    value
        .and_then(Value::as_array)
        .filter(|a| a.len() <= maximum)
        .map(Vec::as_slice)
        .ok_or_else(|| bad(CMD, "missing or oversized structural inventory"))
}
fn matrix<const N: usize>(value: Option<&Value>, rows: usize) -> Result<()>
where
    [f64; N]: serde::de::DeserializeOwned,
{
    let array = values(value, rows)?;
    if array.len() != rows {
        return Err(bad(CMD, "structural matrix row count differs"));
    }
    for row in array {
        vector::<N>(Some(row))?;
    }
    Ok(())
}
fn axes(value: Option<&Value>) -> Result<()> {
    matrix::<3>(value, 3)?;
    let rows: [[f64; 3]; 3] =
        serde_json::from_value(value.cloned().ok_or_else(|| bad(CMD, "missing structural axes"))?).map_err(|e| bad(CMD, e.to_string()))?;
    let r = crate::geom::Vec3::from(rows[0]);
    let s = crate::geom::Vec3::from(rows[1]);
    let t = crate::geom::Vec3::from(rows[2]);
    if (r.len() - 1.).abs() > 1e-8 || (s.len() - 1.).abs() > 1e-8 || (t.len() - 1.).abs() > 1e-8 || (r.cross(s) - t).len() > 1e-8 {
        return Err(bad(CMD, "invalid structural local axes"));
    }
    Ok(())
}
fn validate_result(entry: &Entry, plate: bool) -> Result<()> {
    if entry.active != entry.result.is_some() {
        return Err(bad(CMD, "inactive structural result must be null"));
    }
    let Some(result) = &entry.result else {
        return Ok(());
    };
    if result.get("id").and_then(Value::as_str) != Some(&entry.id) {
        return Err(bad(CMD, "structural result id differs"));
    }
    axes(result.get("local_axes"))?;
    if plate {
        if number(result.get("area_m2"))? <= 0. {
            return Err(bad(CMD, "invalid plate area"));
        }
        for key in ["membrane_energy_kn_m", "bending_energy_kn_m", "drilling_penalty_energy_kn_m"] {
            if number(result.get(key))? < 0. {
                return Err(bad(CMD, "negative structural energy"));
            }
        }
        let samples = values(result.get("samples"), 3)?;
        if samples.len() != 3 {
            return Err(bad(CMD, "three raw DKT samples required"));
        }
        for sample in samples {
            let bary = vector::<3>(sample.get("barycentric"))?;
            if bary.iter().any(|v| *v < 0.) || (bary.iter().sum::<f64>() - 1.).abs() > 1e-10 {
                return Err(bad(CMD, "invalid plate sample position"));
            }
            for key in ["membrane_strain", "curvature_per_m", "membrane_force_kn_m", "bending_moment_kn"] {
                vector::<3>(sample.get(key))?;
            }
            number(sample.get("drilling_mismatch_rad"))?;
        }
    } else {
        if number(result.get("length_m"))? <= 0. {
            return Err(bad(CMD, "invalid beam length"));
        }
        vector::<12>(result.get("local_end_actions"))?;
        matrix::<3>(result.get("local_end_relative_rotation_rad"), 2)?;
        matrix::<6>(result.get("section_forces_at_start_mid_end"), 3)?;
    }
    Ok(())
}

pub(super) fn validate(g: &Geometry, f: &Frame, run: &Value, mesh: &Value) -> Result<()> {
    let configured = run.pointer("/case/beam_system").filter(|v| v.is_object());
    let Some(data) = &f.structures else {
        if configured.is_some() {
            return Err(bad(CMD, "missing structural frame fields"));
        }
        return Ok(());
    };
    let cfg = configured.ok_or_else(|| bad(CMD, "structural display without source configuration"))?;
    let source = run.get("frames").and_then(|v| v.get(f.index)).ok_or_else(|| bad(CMD, "missing structural source frame"))?;
    let state = source.pointer("/state/beams").ok_or_else(|| bad(CMD, "missing source member state"))?;
    let report = source.get("beam_results").ok_or_else(|| bad(CMD, "missing source member report"))?;
    let n = data.nodes.ids.len();
    if data.schema != "soil-fem-view-structures/1"
        || data.semantics != semantics()
        || n > LIMIT
        || data.members.len() > LIMIT
        || data.plates.len() > LIMIT
        || [
            data.nodes.positions_m.len(),
            data.nodes.soil_node_ids.len(),
            data.nodes.displacement_m.len(),
            data.nodes.rotation_rad.len(),
            data.nodes.active.len(),
        ]
        .iter()
        .any(|v| *v != n)
        || data.nodes.ids.iter().any(|id| id.is_empty() || id.len() > 1024)
        || data.nodes.ids.iter().collect::<BTreeSet<_>>().len() != n
        || data.nodes.positions_m.iter().chain(&data.nodes.displacement_m).chain(&data.nodes.rotation_rad).flatten().any(|v| !finite(*v))
    {
        return Err(bad(CMD, "invalid structural node inventory or fields"));
    }
    let definitions = values(cfg.get("nodes"), LIMIT)?;
    if definitions.len() != n {
        return Err(bad(CMD, "structural source node count differs"));
    }
    let mut ids = BTreeMap::new();
    let mut matching_budget = 0usize;
    let index = if definitions.iter().any(|d| d.get("match_soil_node").and_then(Value::as_bool) == Some(true)) {
        Some(super::attachments::CoordinateIndex::new(&g.nodes_m)?)
    } else {
        None
    };
    for (i, definition) in definitions.iter().enumerate() {
        let id = definition.get("id").and_then(Value::as_str).ok_or_else(|| bad(CMD, "missing structural node id"))?;
        if data.nodes.ids.get(i).map(String::as_str) != Some(id) || ids.insert(id, i).is_some() {
            return Err(bad(CMD, "structural source ids differ"));
        }
        let soil = if definition.get("match_soil_node").and_then(Value::as_bool) == Some(true) {
            let position = vector::<3>(definition.get("position_m"))?;
            let index = index.as_ref().ok_or_else(|| bad(CMD, "missing structural coordinate index"))?;
            Some(index.find_unique(position, &mut matching_budget)?)
        } else if let Some(set) = definition.get("soil_node_set").and_then(Value::as_str) {
            let selected = values(mesh.get("node_sets").and_then(|v| v.get(set)), 1)?;
            if selected.len() != 1 {
                return Err(bad(CMD, "one soil node required per structural attachment"));
            }
            Some(
                selected
                    .first()
                    .and_then(Value::as_u64)
                    .and_then(|v| usize::try_from(v).ok())
                    .ok_or_else(|| bad(CMD, "invalid structural soil attachment"))?,
            )
        } else {
            None
        };
        if data.nodes.soil_node_ids.get(i).copied() != Some(soil) {
            return Err(bad(CMD, "structural soil node mapping differs"));
        }
        let position = match soil {
            Some(node) => *g.nodes_m.get(node).ok_or_else(|| bad(CMD, "structural soil node outside mesh"))?,
            None => vector::<3>(definition.get("position_m"))?,
        };
        bound(&json!(data.nodes.positions_m.get(i)), Some(&json!(position)))?;
        if data.nodes.active.get(i) == Some(&true)
            && let Some(node) = soil
        {
            if f.active_node_ids.binary_search(&node).is_err() {
                return Err(bad(CMD, "active structure is attached to removed soil"));
            }
            bound(&json!(data.nodes.displacement_m.get(i)), source.pointer("/state/displacement_m").and_then(|v| v.get(node)))?;
        }
    }
    for (actual, expected) in [
        (json!(data.nodes.displacement_m), state.get("node_displacement_m")),
        (json!(data.nodes.rotation_rad), state.get("node_rotation_rad")),
        (json!(data.nodes.active), report.get("node_active")),
    ] {
        bound(&actual, expected)?;
    }
    let mut union = BTreeSet::new();
    let mut names = BTreeSet::new();
    let mut sections = BTreeMap::new();
    for section in cfg.get("plate_sections").map(|v| values(Some(v), LIMIT)).transpose()?.unwrap_or_default() {
        let id = section.get("id").and_then(Value::as_str).ok_or_else(|| bad(CMD, "missing plate section id"))?;
        if sections.insert(id, section).is_some() {
            return Err(bad(CMD, "duplicate plate section id"));
        }
    }
    for (entries, key, active_key, reference_key, width) in [
        (&data.members, "members", "active_members", "reference_global_kinematics", 2usize),
        (&data.plates, "plates", "active_plates", "plate_reference_global_kinematics", 3usize),
    ] {
        let source_definitions = if key == "plates" && cfg.get(key).is_none() { &[][..] } else { values(cfg.get(key), LIMIT)? };
        if source_definitions.len() != entries.len() {
            return Err(bad(CMD, "structural member inventory differs"));
        }
        let source_reports = report.get(key).map(|v| values(Some(v), LIMIT)).transpose()?.unwrap_or_default();
        let mut expected_reports = BTreeMap::new();
        for r in source_reports {
            let id = r.get("id").and_then(Value::as_str).ok_or_else(|| bad(CMD, "missing source member report id"))?;
            if expected_reports.insert(id, r).is_some() {
                return Err(bad(CMD, "duplicate source member report"));
            }
        }
        let mut live = 0;
        for (i, (entry, definition)) in entries.iter().zip(source_definitions).enumerate() {
            if !names.insert(entry.id.as_str())
                || definition.get("id").and_then(Value::as_str) != Some(&entry.id)
                || definition.get("section_id").and_then(Value::as_str) != Some(&entry.section_id)
                || entry.nodes.len() != width
                || entry.nodes.iter().any(|n| *n >= data.nodes.ids.len())
                || entry.nodes.iter().collect::<BTreeSet<_>>().len() != width
                || entry.reference_global_kinematics.len() != 6 * width
                || !entry.reference_global_kinematics.iter().copied().all(finite)
            {
                return Err(bad(CMD, "structural definition or installation reference differs"));
            }
            let expected_nodes: Vec<_> = values(definition.get("nodes"), width)?
                .iter()
                .map(|v| v.as_str().and_then(|v| ids.get(v)).copied().ok_or_else(|| bad(CMD, "unknown structural connectivity id")))
                .collect::<Result<_>>()?;
            if expected_nodes != entry.nodes {
                return Err(bad(CMD, "structural connectivity differs"));
            }
            bound(&json!(entry.active), state.get(active_key).and_then(|v| v.get(i)))?;
            bound(&json!(entry.reference_global_kinematics), state.get(reference_key).and_then(|v| v.get(i)))?;
            validate_result(entry, width == 3)?;
            if entry.active {
                let points: Vec<_> = entry
                    .nodes
                    .iter()
                    .map(|n| data.nodes.positions_m.get(*n).copied().map(Vec3::from).ok_or_else(|| bad(CMD, "missing structural geometry")))
                    .collect::<Result<_>>()?;
                let a = *points.first().ok_or_else(|| bad(CMD, "missing member corner"))?;
                let b = *points.get(1).ok_or_else(|| bad(CMD, "missing member corner"))?;
                let result = entry.result.as_ref().ok_or_else(|| bad(CMD, "missing active structural result"))?;
                let ex = (b - a).normalized().ok_or_else(|| bad(CMD, "zero member edge"))?;
                let local_x = vector::<3>(result.get("local_axes").and_then(|v| v.get(0)))?;
                if (Vec3::from(local_x) - ex).len() > 1e-8 {
                    return Err(bad(CMD, "structural local x axis differs from CAD geometry"));
                }
                if width == 3 {
                    let c = *points.get(2).ok_or_else(|| bad(CMD, "missing plate corner"))?;
                    let normal = (b - a).cross(c - a);
                    let area = normal.len() * 0.5;
                    let z = Vec3::from(vector::<3>(result.get("local_axes").and_then(|v| v.get(2)))?);
                    if area <= 1e-16
                        || (area - number(result.get("area_m2"))?).abs() > 1e-10 * area.max(1.)
                        || (normal / normal.len() - z).len() > 1e-8
                    {
                        return Err(bad(CMD, "plate reference area/normal differs from CAD geometry"));
                    }
                } else if ((b - a).len() - number(result.get("length_m"))?).abs() > 1e-10 * (b - a).len().max(1.) {
                    return Err(bad(CMD, "beam reference length differs from CAD geometry"));
                }
                live += 1;
                union.extend(entry.nodes.iter().copied());
                bound(
                    entry.result.as_ref().ok_or_else(|| bad(CMD, "missing active structural result"))?,
                    expected_reports.get(entry.id.as_str()).copied(),
                )?;
            }
            if width == 3 {
                let section = sections.get(entry.section_id.as_str()).ok_or_else(|| bad(CMD, "missing source plate section"))?;
                let thickness = entry.thickness_m.filter(|v| finite(*v) && *v > 0.).ok_or_else(|| bad(CMD, "invalid plate thickness"))?;
                bound(&json!(thickness), section.get("thickness_m"))?;
            } else if entry.thickness_m.is_some() {
                return Err(bad(CMD, "beam has a plate thickness"));
            }
        }
        if live != expected_reports.len() {
            return Err(bad(CMD, "extra inactive structural reports"));
        }
    }
    if data.nodes.active.iter().enumerate().any(|(i, active)| *active != union.contains(&i)) {
        return Err(bad(CMD, "structural active nodes differ from connectivity"));
    }
    let keys = ["external_force_kn", "external_moment_origin_kn_m", "support_force_kn", "support_moment_origin_kn_m"];
    if data.global_resultants.len() != keys.len() {
        return Err(bad(CMD, "structural resultant inventory differs"));
    }
    for key in keys {
        bound(&json!(data.global_resultants.get(key)), report.get(key))?;
    }
    Ok(())
}

#[derive(Clone, Copy)]
struct Sample {
    position: Vec3,
    displacement: Vec3,
}
impl Sample {
    fn between(self, other: Self, t: f64) -> Self {
        Self { position: self.position * (1. - t) + other.position * t, displacement: self.displacement * (1. - t) + other.displacement * t }
    }
}
fn point(data: &Fields, node: usize) -> Result<Sample> {
    Ok(Sample {
        position: Vec3::from(*data.nodes.positions_m.get(node).ok_or_else(|| bad(CMD, "missing structural position"))?),
        displacement: Vec3::from(*data.nodes.displacement_m.get(node).ok_or_else(|| bad(CMD, "missing structural displacement"))?),
    })
}
fn vertex(scene: &mut Scene, sample: Sample, scalar: f64, scale: f64) -> Result<Vertex> {
    let p = (sample.position + sample.displacement * scale - scene.render_origin_m) * 1000.;
    if !p.is_finite() || [p.x, p.y, p.z].iter().any(|v| v.abs() > 1e30) || !finite(scalar) {
        return Err(bad(CMD, "structural display coordinates or values exceed the GPU range"));
    }
    scene.bounds.add(p);
    Ok(Vertex { position_mm: p, scalar: Some(scalar) })
}
fn line(scene: &mut Scene, a: Sample, b: Sample, q: f64, id: usize, scale: f64) -> Result<()> {
    let a = vertex(scene, a, q, scale)?.position_mm;
    let b = vertex(scene, b, q, scale)?.position_mm;
    scene.member_lines.push(MemberLine { a_mm: a, b_mm: b, scalar: q, element_id: id });
    Ok(())
}
fn plane(settings: &Settings) -> Result<Option<(Vec3, f64, bool)>> {
    let Some(section) = &settings.section else {
        return Ok(None);
    };
    let raw = Vec3::from(section.normal);
    let normal = raw.normalized().ok_or_else(|| bad(CMD, "invalid structural section normal"))?;
    Ok(Some((normal, section.offset_m / raw.len(), section.slice_only)))
}
struct Clip<'a> {
    settings: &'a Settings,
    section: Option<(Vec3, f64, bool)>,
    epsilon: f64,
    marker: f64,
}
fn clip_line(scene: &mut Scene, mut a: Sample, mut b: Sample, q: f64, id: usize, clip: &Clip<'_>) -> Result<()> {
    let settings = clip.settings;
    let section = clip.section;
    let epsilon = clip.epsilon;
    let marker = clip.marker;
    if let Some((normal, offset, slice)) = section {
        let da = normal.dot(a.position) - offset;
        let db = normal.dot(b.position) - offset;
        if slice && !(da.abs() <= epsilon && db.abs() <= epsilon) {
            if (da > epsilon && db > epsilon) || (da < -epsilon && db < -epsilon) {
                return Ok(());
            }
            let t = if (da - db).abs() > epsilon { (da / (da - db)).clamp(0., 1.) } else { 0. };
            let cross = a.between(b, t);
            let basis = if normal.z.abs() < 0.9 { normal.cross(Vec3::from([0., 0., 1.])) } else { normal.cross(Vec3::from([1., 0., 0.])) };
            let axis = basis.normalized().ok_or_else(|| bad(CMD, "invalid structural slice marker"))? * marker;
            for direction in [axis, normal.cross(axis)] {
                line(
                    scene,
                    Sample { position: cross.position - direction, ..cross },
                    Sample { position: cross.position + direction, ..cross },
                    q,
                    id,
                    settings.deformation_scale,
                )?;
            }
            return Ok(());
        }
        if !slice {
            if da > epsilon && db > epsilon {
                return Ok(());
            }
            if (da > epsilon) != (db > epsilon) {
                let cut = a.between(b, (da / (da - db)).clamp(0., 1.));
                if da > epsilon {
                    a = cut;
                } else {
                    b = cut;
                }
            }
        }
    }
    line(scene, a, b, q, id, settings.deformation_scale)
}
fn plate_triangle(
    scene: &mut Scene,
    triangle: [Sample; 3],
    q: f64,
    id: usize,
    settings: &Settings,
    section: Option<(Vec3, f64, bool)>,
    epsilon: f64,
) -> Result<()> {
    let mut polygon = triangle.to_vec();
    let mut sliced = false;
    if let Some((normal, offset, slice)) = section {
        let distances = triangle.map(|s| normal.dot(s.position) - offset);
        let coplanar = distances.iter().all(|d| d.abs() <= epsilon);
        if slice && !coplanar {
            let mut intersections: Vec<Sample> = Vec::new();
            for (i, j) in [(0, 1), (1, 2), (2, 0)] {
                let a = triangle[i];
                let b = triangle[j];
                let da = distances[i];
                let db = distances[j];
                if da.abs() <= epsilon && intersections.iter().all(|p| (p.position - a.position).len() > epsilon) {
                    intersections.push(a);
                }
                if (da > epsilon && db < -epsilon) || (da < -epsilon && db > epsilon) {
                    let point = a.between(b, da / (da - db));
                    if intersections.iter().all(|p| (p.position - point.position).len() > epsilon) {
                        intersections.push(point);
                    }
                }
            }
            if let (Some(a), Some(b)) = (intersections.first(), intersections.get(1)) {
                line(scene, *a, *b, q, id, settings.deformation_scale)?;
            }
            return Ok(());
        }
        sliced = slice;
        if !slice && !coplanar {
            polygon.clear();
            for (i, j) in [(0, 1), (1, 2), (2, 0)] {
                let a = triangle[i];
                let b = triangle[j];
                let da = distances[i];
                let db = distances[j];
                if da <= epsilon {
                    polygon.push(a);
                }
                if (da > epsilon) != (db > epsilon) {
                    polygon.push(a.between(b, (da / (da - db)).clamp(0., 1.)));
                }
            }
        }
    }
    let Some(first) = polygon.first().copied() else {
        return Ok(());
    };
    for pair in polygon.get(1..).unwrap_or_default().windows(2) {
        let a = pair.first().copied().ok_or_else(|| bad(CMD, "invalid structural display polygon"))?;
        let b = pair.get(1).copied().ok_or_else(|| bad(CMD, "invalid structural display polygon"))?;
        if sliced {
            scene.reference_section_area_m2 += (a.position - first.position).cross(b.position - first.position).len() * 0.5;
        }
        let vertices = [
            vertex(scene, first, q, settings.deformation_scale)?,
            vertex(scene, a, q, settings.deformation_scale)?,
            vertex(scene, b, q, settings.deformation_scale)?,
        ];
        scene.triangles.push(Triangle { vertices, element_id: id, section: sliced });
    }
    Ok(())
}

pub(super) fn build(g: &Geometry, f: &Frame, settings: &Settings, manifest: &str) -> Result<Scene> {
    let data = f.structures.as_ref().ok_or_else(|| bad(CMD, "this frame has no structural result layer"))?;
    let (plate, component, field) = match settings.quantity {
        Quantity::BeamAxialForce => (false, 0, "section_forces_at_start_mid_end"),
        Quantity::BeamMomentY => (false, 4, "section_forces_at_start_mid_end"),
        Quantity::BeamMomentZ => (false, 5, "section_forces_at_start_mid_end"),
        Quantity::PlateMembraneXx => (true, 0, "membrane_force_kn_m"),
        Quantity::PlateMembraneYy => (true, 1, "membrane_force_kn_m"),
        Quantity::PlateMembraneXy => (true, 2, "membrane_force_kn_m"),
        Quantity::PlateBendingXx => (true, 0, "bending_moment_kn"),
        Quantity::PlateBendingYy => (true, 1, "bending_moment_kn"),
        Quantity::PlateBendingXy => (true, 2, "bending_moment_kn"),
        _ => return Err(bad(CMD, "choose a structural quantity")),
    };
    let entries = if plate { &data.plates } else { &data.members };
    if entries.is_empty() {
        return Err(bad(CMD, "this model has no definitions for the selected structural family"));
    }
    let mut reference = Aabb3::EMPTY;
    for point in &g.nodes_m {
        reference.add(Vec3::from(*point));
    }
    if reference.is_empty() {
        return Err(bad(CMD, "missing reference geometry for structural layer"));
    }
    let mut scene = Scene {
        key: String::new(),
        triangles: Vec::new(),
        glyphs: Vec::new(),
        member_lines: Vec::new(),
        structural_hits: BTreeMap::new(),
        bounds: Aabb3::EMPTY,
        data_range: [f64::INFINITY, f64::NEG_INFINITY],
        color_range: [0., 1.],
        render_origin_m: reference.center(),
        unavailable_cells: 0,
        reference_section_area_m2: 0.,
        approximation: "Structural coordinates/displacements from CAD, independent of soil display RESET. Straight endpoint beam geometry, 16 display segments interpolating raw start/mid/end sections. Flat plates use linear nodal displacement and three equal-area raw DKT sample regions; no cross-element smoothing. Sections use reference coordinates. Inactive entries are hidden; raw values and archived histories are available by member query.",
    };
    let epsilon = (reference.diagonal() * 1e-11).max(1e-12);
    let marker = (reference.diagonal() * 0.002).max(0.001);
    let section = plane(settings)?;
    let clip = Clip { settings, section, epsilon, marker };
    let mut active = 0usize;
    for (index, entry) in entries.iter().enumerate() {
        if !entry.active {
            continue;
        }
        active += 1;
        validate_result(entry, plate)?;
        let id = g
            .cells
            .len()
            .checked_add(if plate { index } else { data.plates.len().saturating_add(index) })
            .ok_or_else(|| bad(CMD, "structural display identity overflow"))?;
        scene.structural_hits.insert(id, if plate { json!({"plate":index,"plate_id":entry.id}) } else { json!({"beam":index,"beam_id":entry.id}) });
        let result = entry.result.as_ref().ok_or_else(|| bad(CMD, "missing structural result"))?;
        let points: Vec<_> = entry.nodes.iter().map(|n| point(data, *n)).collect::<Result<_>>()?;
        if plate {
            let a = *points.first().ok_or_else(|| bad(CMD, "missing plate corner"))?;
            let b = *points.get(1).ok_or_else(|| bad(CMD, "missing plate corner"))?;
            let c = *points.get(2).ok_or_else(|| bad(CMD, "missing plate corner"))?;
            let center = a.between(b, 0.5).between(c, 1. / 3.);
            let samples = values(result.get("samples"), 3)?;
            for (i, (corner, next, prior)) in [(a, b, c), (b, c, a), (c, a, b)].into_iter().enumerate() {
                let sample = samples.get(i).ok_or_else(|| bad(CMD, "missing raw DKT sample"))?;
                // The supported solver's sample order is tied to each corner.
                let bary = vector::<3>(sample.get("barycentric"))?;
                for (j, v) in bary.iter().enumerate() {
                    if (*v - if i == j { 2. / 3. } else { 1. / 6. }).abs() > 1e-12 {
                        return Err(bad(CMD, "unsupported DKT sample ordering"));
                    }
                }
                let q = *vector::<3>(sample.get(field))?.get(component).ok_or_else(|| bad(CMD, "invalid plate component"))?;
                scene.data_range[0] = scene.data_range[0].min(q);
                scene.data_range[1] = scene.data_range[1].max(q);
                plate_triangle(&mut scene, [corner, corner.between(next, 0.5), center], q, id, settings, section, epsilon)?;
                plate_triangle(&mut scene, [corner, center, corner.between(prior, 0.5)], q, id, settings, section, epsilon)?;
            }
        } else {
            let a = *points.first().ok_or_else(|| bad(CMD, "missing beam end"))?;
            let b = *points.get(1).ok_or_else(|| bad(CMD, "missing beam end"))?;
            let samples = values(result.get(field), 3)?;
            let mut q = [0.; 3];
            for (i, sample) in samples.iter().enumerate() {
                if let Some(value) = q.get_mut(i) {
                    *value = *vector::<6>(Some(sample))?.get(component).ok_or_else(|| bad(CMD, "invalid beam component"))?;
                }
            }
            for value in q {
                scene.data_range[0] = scene.data_range[0].min(value);
                scene.data_range[1] = scene.data_range[1].max(value);
            }
            let quadratic = 2. * q[0] - 4. * q[1] + 2. * q[2];
            let linear = -3. * q[0] + 4. * q[1] - q[2];
            if quadratic != 0. {
                let extremum = -linear / (2. * quadratic);
                if (0.0..1.0).contains(&extremum) {
                    let value = quadratic * extremum * extremum + linear * extremum + q[0];
                    scene.data_range[0] = scene.data_range[0].min(value);
                    scene.data_range[1] = scene.data_range[1].max(value);
                }
            }
            for i in 0..16 {
                let t = (f64::from(i) + 0.5) / 16.;
                let value = 2. * (t - 0.5) * (t - 1.) * q[0] + 4. * t * (1. - t) * q[1] + 2. * t * (t - 0.5) * q[2];
                scene.data_range[0] = scene.data_range[0].min(value);
                scene.data_range[1] = scene.data_range[1].max(value);
                clip_line(&mut scene, a.between(b, f64::from(i) / 16.), a.between(b, f64::from(i + 1) / 16.), value, id, &clip)?;
            }
        }
    }
    if active == 0 {
        scene.data_range = [0., 0.];
    }
    if !scene.data_range.iter().copied().all(finite) {
        return Err(bad(CMD, "structural display values are invalid"));
    }
    if scene.bounds.is_empty() {
        for point in &g.nodes_m {
            scene.bounds.add((Vec3::from(*point) - scene.render_origin_m) * 1000.);
        }
    }
    scene.color_range = if let Some(range) = settings.color_range {
        range
    } else if scene.data_range[0] == scene.data_range[1] {
        let v = scene.data_range[0];
        let half = (v.abs() * 0.01).max(1e-12);
        [v - half, v + half]
    } else {
        scene.data_range
    };
    scene.key =
        format!("{:x}", Sha256::digest(format!("{manifest}:{}", serde_json::to_string(settings).map_err(|e| bad(CMD, e.to_string()))?).as_bytes()));
    Ok(scene)
}
