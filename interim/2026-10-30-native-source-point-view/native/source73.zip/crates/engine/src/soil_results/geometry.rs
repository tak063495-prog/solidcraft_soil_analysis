//! Scientific display geometry. Tet10 is evaluated in its reference coordinates;
//! subdivisions approximate curved faces/sections, never alter the FEM solution.
use super::native::*;
use crate::{
    Result,
    geom::{Aabb3, Vec3},
    params::bad,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
const CMD: &str = "analysis.soil.results";
const FACES: [[usize; 3]; 4] = [[1, 2, 3], [0, 3, 2], [0, 1, 3], [0, 2, 1]];
const EDGES: [[usize; 2]; 6] = [[0, 1], [1, 2], [2, 0], [0, 3], [1, 3], [2, 3]];
const UNIT: [[f64; 4]; 4] = [[1., 0., 0., 0.], [0., 1., 0., 0.], [0., 0., 1., 0.], [0., 0., 0., 1.]];
const SUB: [[usize; 4]; 8] = [[0, 4, 6, 7], [4, 1, 5, 8], [6, 5, 2, 9], [7, 8, 9, 3], [4, 5, 6, 9], [4, 5, 8, 9], [4, 8, 7, 9], [4, 7, 6, 9]];
const MAX_TRIANGLES: usize = 1_000_000;

pub(super) fn check_boundary(g: &Geometry, f: &Frame) -> Result<()> {
    let mut owners: BTreeMap<[usize; 3], Vec<(usize, BTreeSet<usize>)>> = BTreeMap::new();
    for id in &f.active_element_ids {
        let cell = g.cells.get(*id).ok_or_else(|| bad(CMD, "missing active cell"))?;
        for face in FACES {
            let mut corners = [0usize; 3];
            let mut nodes = BTreeSet::new();
            for (i, local) in face.iter().enumerate() {
                let node = *cell.get(*local).ok_or_else(|| bad(CMD, "invalid face corner"))?;
                corners[i] = node;
                nodes.insert(node);
            }
            if cell.len() == 10 {
                for pair in [[face[0], face[1]], [face[1], face[2]], [face[2], face[0]]] {
                    let edge =
                        EDGES.iter().position(|e| e.contains(&pair[0]) && e.contains(&pair[1])).ok_or_else(|| bad(CMD, "invalid quadratic edge"))?;
                    nodes.insert(*cell.get(edge + 4).ok_or_else(|| bad(CMD, "missing quadratic edge node"))?);
                }
            }
            corners.sort_unstable();
            let entry = owners.entry(corners).or_default();
            if entry.len() >= 2 || entry.first().is_some_and(|(_, n)| *n != nodes) {
                return Err(bad(CMD, "nonmanifold or nonconforming active face"));
            }
            entry.push((*id, nodes));
        }
    }
    let expected: BTreeMap<_, _> =
        owners.into_iter().filter_map(|(key, v)| if v.len() == 1 { v.into_iter().next().map(|owner| (key, owner)) } else { None }).collect();
    if f.boundary_faces.len() != expected.len() {
        return Err(bad(CMD, "boundary face count differs from active topology"));
    }
    let mut seen = BTreeSet::new();
    for face in &f.boundary_faces {
        if !matches!(face.nodes.len(), 3 | 6) {
            return Err(bad(CMD, "expected Tri3 or Tri6 boundary"));
        }
        let mut key = [
            *face.nodes.first().ok_or_else(|| bad(CMD, "missing face node"))?,
            *face.nodes.get(1).ok_or_else(|| bad(CMD, "missing face node"))?,
            *face.nodes.get(2).ok_or_else(|| bad(CMD, "missing face node"))?,
        ];
        key.sort_unstable();
        if !seen.insert(key) || expected.get(&key) != Some(&(face.element_index, face.nodes.iter().copied().collect())) {
            return Err(bad(CMD, "boundary face identities differ from active topology"));
        }
        if face.nodes.iter().any(|n| *n >= g.nodes_m.len()) {
            return Err(bad(CMD, "boundary node out of range"));
        }
    }
    Ok(())
}

pub struct Principal {
    pub values: [f64; 3],
    pub axis: Option<Vec3>,
}
pub(super) fn principal(stress: [f64; 6]) -> Principal {
    let [xx, yy, zz, xy, yz, xz] = stress;
    let mut a = [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]];
    let mut vectors = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
    let scale = stress.iter().fold(1.0f64, |s, x| s.max(x.abs()));
    for _ in 0..32 {
        let (p, q) = [(0, 1), (0, 2), (1, 2)].into_iter().max_by(|(p, q), (r, s)| a[*p][*q].abs().total_cmp(&a[*r][*s].abs())).unwrap_or((0, 1));
        if a[p][q].abs() <= 1e-13 * scale {
            break;
        }
        let angle = 0.5 * (2. * a[p][q]).atan2(a[q][q] - a[p][p]);
        let (s, c) = angle.sin_cos();
        let mut rotation = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
        rotation[p][p] = c;
        rotation[q][q] = c;
        rotation[p][q] = s;
        rotation[q][p] = -s;
        let old = a;
        for i in 0..3 {
            for j in 0..3 {
                a[i][j] = (0..3).flat_map(|k| (0..3).map(move |l| (k, l))).map(|(k, l)| rotation[k][i] * old[k][l] * rotation[l][j]).sum();
            }
        }
        let old = vectors;
        for i in 0..3 {
            for j in 0..3 {
                vectors[i][j] = (0..3).map(|k| old[i][k] * rotation[k][j]).sum();
            }
        }
    }
    let mut order = [0, 1, 2];
    order.sort_by(|i, j| a[*j][*j].total_cmp(&a[*i][*i]));
    let values = order.map(|i| a[i][i]);
    let i = order[0];
    let axis = if (values[0] - values[1]).abs() > 1e-9 * scale { Vec3::new(vectors[0][i], vectors[1][i], vectors[2][i]).normalized() } else { None };
    Principal { values, axis }
}

fn weights(b: [f64; 4], quadratic: bool) -> Vec<f64> {
    if !quadratic {
        return b.to_vec();
    }
    let mut values = b.map(|v| v * (2. * v - 1.)).to_vec();
    values.extend(EDGES.map(|[a, c]| 4. * b[a] * b[c]));
    values
}
#[derive(Clone, Copy)]
struct Sample {
    natural: [f64; 4],
    reference: Vec3,
    displacement: Vec3,
    scalar: Option<f64>,
}
impl Sample {
    fn blend(self, other: Self, t: f64) -> Self {
        Self {
            natural: std::array::from_fn(|i| self.natural[i] * (1. - t) + other.natural[i] * t),
            reference: self.reference * (1. - t) + other.reference * t,
            displacement: self.displacement * (1. - t) + other.displacement * t,
            scalar: self.scalar.zip(other.scalar).map(|(a, b)| a * (1. - t) + b * t),
        }
    }
}
#[derive(Clone, Copy)]
struct Scalar {
    constant: Option<f64>,
    corners: Option<[f64; 4]>,
}
fn evaluate(g: &Geometry, cell: &[usize], u: &BTreeMap<usize, Vec3>, b: [f64; 4], settings: &Settings, constant: Scalar) -> Result<Sample> {
    let w = weights(b, cell.len() == 10);
    let mut point = Vec3::ZERO;
    let mut displacement = Vec3::ZERO;
    for (node, weight) in cell.iter().zip(w) {
        point += Vec3::from(*g.nodes_m.get(*node).ok_or_else(|| bad(CMD, "missing display node"))?) * weight;
        displacement += *u.get(node).ok_or_else(|| bad(CMD, "missing active nodal displacement"))? * weight;
    }
    let scalar = match settings.quantity {
        Quantity::VerticalDisplacement => Some(displacement.z * 1000.),
        Quantity::DisplacementMagnitude => Some(displacement.len() * 1000.),
        _ => constant.corners.map(|p| p.iter().zip(b).map(|(p, w)| p * w).sum()).or(constant.constant),
    };
    if !point.is_finite() || !displacement.is_finite() || scalar.is_some_and(|v| !v.is_finite()) {
        return Err(bad(CMD, "non-finite interpolated display sample"));
    }
    Ok(Sample { natural: b, reference: point, displacement, scalar })
}

// Section/clipping geometry remains on the planar display approximation. Its
// fields use the original element's shape functions at the interpolated natural
// position, rather than linear interpolation of a quadratic displacement or norm.
fn resample_fields(
    g: &Geometry,
    cell: &[usize],
    u: &BTreeMap<usize, Vec3>,
    settings: &Settings,
    constant: Scalar,
    polygon: &mut [Sample],
) -> Result<()> {
    for sample in polygon {
        let field = evaluate(g, cell, u, sample.natural, settings, constant)?;
        sample.displacement = field.displacement;
        sample.scalar = field.scalar;
    }
    Ok(())
}
fn midpoint(a: [f64; 4], b: [f64; 4]) -> [f64; 4] {
    std::array::from_fn(|i| (a[i] + b[i]) * 0.5)
}
fn split(tet: [[f64; 4]; 4]) -> Vec<[[f64; 4]; 4]> {
    let mut points = tet.to_vec();
    points.extend(EDGES.map(|[a, b]| midpoint(tet[a], tet[b])));
    SUB.map(|ids| ids.map(|i| points.get(i).copied().unwrap_or([0.; 4]))).to_vec()
}
fn cell_value(f: &CellFields, row: usize, q: &Quantity) -> Option<f64> {
    match q {
        Quantity::EffectiveStressZz => f.effective_stress_compression_positive_kpa.get(row).map(|s| s[2]),
        Quantity::MeanEffectiveStress => f.effective_stress_compression_positive_kpa.get(row).map(|s| (s[0] + s[1] + s[2]) / 3.),
        Quantity::MajorEffectiveStress => f.effective_stress_compression_positive_kpa.get(row).map(|s| principal(*s).values[0]),
        Quantity::VoidRatio => f.void_ratio.get(row).copied().flatten(),
        Quantity::PreconsolidationPressure => f.preconsolidation_pressure_kpa.get(row).copied().flatten(),
        Quantity::VolumetricPlasticStrain => f.plastic_strain_compression_positive.get(row).map(|s| s[0] + s[1] + s[2]),
        Quantity::WorkEffectiveStressZz => f
            .other
            .get("work_conjugate_effective_stress_compression_positive_kpa")
            .and_then(|v| v.get(row))
            .and_then(|v| v.get(2))
            .and_then(Value::as_f64),
        Quantity::KinematicVolumeStrain => {
            f.other.get("cumulative_kinematic_volume_strain_compression_positive").and_then(|v| v.get(row)).and_then(Value::as_f64)
        }
        _ => None,
    }
}
fn normalized_section(settings: &Settings) -> Option<(Vec3, f64, bool)> {
    settings.section.as_ref().map(|s| {
        let normal = Vec3::from(s.normal);
        let length = normal.len();
        (normal / length, s.offset_m / length, s.slice_only)
    })
}
fn clip(polygon: &[Sample], normal: Vec3, offset: f64, tolerance: f64) -> Vec<Sample> {
    let mut out = Vec::new();
    for (a, b) in polygon.iter().copied().zip(polygon.iter().copied().cycle().skip(1)).take(polygon.len()) {
        let da = normal.dot(a.reference) - offset;
        let db = normal.dot(b.reference) - offset;
        if da <= tolerance {
            out.push(a);
        }
        if (da < -tolerance && db > tolerance) || (da > tolerance && db < -tolerance) {
            out.push(a.blend(b, da / (da - db)));
        }
    }
    out
}
fn intersection(samples: [Sample; 4], normal: Vec3, offset: f64, tolerance: f64) -> Vec<Sample> {
    // Use the negative-side trace on coincident internal faces. Without this,
    // two neighbouring sub-tetrahedra publish the same cap with different means.
    if samples.iter().all(|p| normal.dot(p.reference) - offset >= -tolerance) {
        return Vec::new();
    }
    // Include every coplanar vertex, including local vertex 3 (which is never
    // the first endpoint in EDGES). Otherwise coincident faces lose a corner.
    let mut polygon: Vec<_> = samples.iter().copied().filter(|p| (normal.dot(p.reference) - offset).abs() <= tolerance).collect();
    for [a, b] in EDGES {
        let p = samples[a];
        let q = samples[b];
        let dp = normal.dot(p.reference) - offset;
        let dq = normal.dot(q.reference) - offset;
        if (dp < -tolerance && dq > tolerance) || (dp > tolerance && dq < -tolerance) {
            polygon.push(p.blend(q, dp / (dp - dq)));
        }
    }
    let mut unique: Vec<Sample> = Vec::new();
    for sample in polygon {
        if unique.iter().all(|s| s.reference.dist(sample.reference) > tolerance) {
            unique.push(sample);
        }
    }
    if unique.len() < 3 {
        return Vec::new();
    }
    let center = unique.iter().fold(Vec3::ZERO, |sum, s| sum + s.reference) / unique.len() as f64;
    let x = normal.cross(if normal.x.abs() < 0.9 { Vec3::X } else { Vec3::Y }).normalized().unwrap_or(Vec3::Z);
    let y = normal.cross(x);
    unique.sort_by(|a, b| {
        let a = a.reference - center;
        let b = b.reference - center;
        a.dot(y).atan2(a.dot(x)).total_cmp(&b.dot(y).atan2(b.dot(x)))
    });
    unique
}
fn push_polygon(scene: &mut Scene, polygon: &[Sample], element: usize, section: bool, scale: f64) -> Result<()> {
    for pair in polygon.get(1..).unwrap_or_default().windows(2) {
        if scene.triangles.len() >= MAX_TRIANGLES {
            return Err(bad(CMD, "display exceeds one million triangles; reduce refinement or use a section"));
        }
        let Some(first) = polygon.first().copied() else {
            continue;
        };
        let samples = [first, pair[0], pair[1]];
        let points = samples.map(|s| (s.reference + s.displacement * scale - scene.render_origin_m) * 1000.);
        if points.iter().any(|p| !p.is_finite() || !p.to_f32().iter().all(|v| v.is_finite())) {
            return Err(bad(CMD, "display coordinates exceed GPU precision/range"));
        }
        if (points[1] - points[0]).cross(points[2] - points[0]).len() < 1e-16 {
            continue;
        }
        for point in points {
            scene.bounds.add(point);
        }
        if section {
            scene.reference_section_area_m2 +=
                (samples[1].reference - samples[0].reference).cross(samples[2].reference - samples[0].reference).len() * 0.5;
        }
        for sample in samples {
            if let Some(value) = sample.scalar {
                scene.data_range[0] = scene.data_range[0].min(value);
                scene.data_range[1] = scene.data_range[1].max(value);
            }
        }
        scene.triangles.push(Triangle {
            vertices: std::array::from_fn(|i| Vertex { position_mm: points[i], scalar: samples[i].scalar }),
            element_id: element,
            section,
        });
    }
    Ok(())
}

fn section_center(triangles: &[Triangle]) -> Option<Vec3> {
    let mut moment = Vec3::ZERO;
    let mut area = 0.;
    for triangle in triangles.iter().filter(|t| t.section) {
        let [a, b, c] = triangle.vertices.map(|v| v.position_mm);
        let weight = (b - a).cross(c - a).len();
        moment += (a + b + c) * (weight / 3.);
        area += weight;
    }
    (area > 0. && area.is_finite() && moment.is_finite()).then(|| moment / area)
}

pub(super) fn build(g: &Geometry, f: &Frame, settings: &Settings, manifest: &str) -> Result<Scene> {
    if settings.quantity.structural() {
        return super::structures::build(g, f, settings, manifest);
    }
    let mut bounds = Aabb3::EMPTY;
    for point in &g.nodes_m {
        bounds.add(Vec3::from(*point));
    }
    let mut scene = Scene {
        key: String::new(),
        triangles: Vec::new(),
        glyphs: Vec::new(),
        member_lines: Vec::new(),
        structural_hits: BTreeMap::new(),
        bounds: Aabb3::EMPTY,
        data_range: [f64::INFINITY, f64::NEG_INFINITY],
        color_range: [0., 1.],
        render_origin_m: bounds.center(),
        unavailable_cells: 0,
        reference_section_area_m2: 0.,
        approximation: "Tet10 mapping sampled on refined reference tetrahedra; planar section geometry; original shape functions for cut-vertex displacement; no change to FEM values",
    };
    let tolerance = (bounds.diagonal() * 1e-11).max(1e-12);
    let section = normalized_section(settings);
    let vectors = f.node_fields.get(settings.displacement_reference.field()).ok_or_else(|| bad(CMD, "missing selected displacement reference"))?;
    let u: BTreeMap<_, _> = f.active_node_ids.iter().copied().zip(vectors.iter().copied().map(Vec3::from)).collect();
    if settings.quantity.nodal() {
        for value in u.values() {
            let q = if settings.quantity == Quantity::VerticalDisplacement { value.z * 1000. } else { value.len() * 1000. };
            scene.data_range[0] = scene.data_range[0].min(q);
            scene.data_range[1] = scene.data_range[1].max(q);
        }
    }
    let mut boundary: BTreeMap<usize, Vec<BTreeSet<usize>>> = BTreeMap::new();
    for face in &f.boundary_faces {
        boundary.entry(face.element_index).or_default().push(face.nodes.iter().copied().collect());
    }
    let sub_count = if g.cells.first().is_some_and(|c| c.len() == 10) { 8usize.pow(u32::from(settings.refinement)) } else { 1 };
    if f.active_element_ids.len().saturating_mul(sub_count) > 10_000_000 {
        return Err(bad(CMD, "display subdivision budget exceeded"));
    }
    if settings.principal_directions && f.active_element_ids.len() > 10_000 {
        return Err(bad(CMD, "principal glyph budget is 10000 active cells; disable glyphs for this model"));
    }
    let primary: BTreeMap<_, _> = f
        .mixed_primary
        .as_ref()
        .map(|p| {
            p.original_node_ids
                .iter()
                .zip(&p.material_ids)
                .enumerate()
                .filter_map(|(i, (n, m))| {
                    p.mean_effective_stress_compression_positive_kpa
                        .get(i)
                        .zip(p.cumulative_material_volume_strain_compression_positive.get(i))
                        .map(|(pressure, volume)| ((*n, *m), (*pressure, *volume)))
                })
                .collect()
        })
        .unwrap_or_default();
    for (row, element) in f.active_element_ids.iter().enumerate() {
        let cell = g.cells.get(*element).ok_or_else(|| bad(CMD, "missing original display cell"))?;
        let corners = if settings.quantity.primary() {
            f.cell_fields
                .material_id
                .get(row)
                .and_then(|material| {
                    cell.iter()
                        .take(4)
                        .map(|node| {
                            primary
                                .get(&(*node, *material))
                                .map(|v| if settings.quantity == Quantity::PrimaryMeanEffectiveStress { v.0 } else { v.1 })
                        })
                        .collect::<Option<Vec<_>>>()
                })
                .and_then(|v| v.try_into().ok())
        } else {
            None
        };
        let constant = Scalar { constant: cell_value(&f.cell_fields, row, &settings.quantity), corners };
        if !settings.quantity.nodal() {
            if let Some(values) = constant.corners {
                for v in values {
                    scene.data_range[0] = scene.data_range[0].min(v);
                    scene.data_range[1] = scene.data_range[1].max(v);
                }
            } else if let Some(v) = constant.constant {
                scene.data_range[0] = scene.data_range[0].min(v);
                scene.data_range[1] = scene.data_range[1].max(v);
            } else {
                scene.unavailable_cells += 1;
            }
        }
        let first_triangle = scene.triangles.len();
        let mut tets = vec![UNIT];
        if cell.len() == 10 {
            for _ in 0..settings.refinement {
                tets = tets.into_iter().flat_map(split).collect();
            }
        }
        for tet in tets {
            let samples: Vec<_> = tet.into_iter().map(|b| evaluate(g, cell, &u, b, settings, constant)).collect::<Result<_>>()?;
            let samples: [Sample; 4] = samples.try_into().map_err(|_| bad(CMD, "display tetrahedron arity"))?;
            if let Some((normal, offset, _)) = section {
                let mut polygon = intersection(samples, normal, offset, tolerance);
                resample_fields(g, cell, &u, settings, constant, &mut polygon)?;
                push_polygon(&mut scene, &polygon, *element, true, settings.deformation_scale)?;
            }
            if section.is_some_and(|(_, _, only)| only) {
                continue;
            }
            for local in FACES {
                // A reference face is on the exterior only when all its sample
                // barycentrics lie in the same original boundary face.
                let external = boundary.get(element).is_some_and(|faces| {
                    faces.iter().any(|nodes| {
                        let original_corner = cell.iter().take(4).position(|id| !nodes.contains(id));
                        original_corner.is_some_and(|opposite| local.iter().all(|i| tet[*i][opposite].abs() < 1e-13))
                    })
                });
                if !external {
                    continue;
                }
                let polygon: Vec<_> = local.map(|i| samples[i]).to_vec();
                if section.is_some_and(|(n, d, _)| polygon.iter().all(|p| (n.dot(p.reference) - d).abs() <= tolerance)) {
                    continue;
                }
                let mut polygon = if let Some((normal, offset, _)) = section { clip(&polygon, normal, offset, tolerance) } else { polygon };
                resample_fields(g, cell, &u, settings, constant, &mut polygon)?;
                push_polygon(&mut scene, &polygon, *element, false, settings.deformation_scale)?;
            }
        }
        if settings.principal_directions {
            let stress = *f.cell_fields.effective_stress_compression_positive_kpa.get(row).ok_or_else(|| bad(CMD, "missing mean stress"))?;
            if let Some(axis) = principal(stress).axis {
                let center = if section.is_some_and(|(_, _, only)| only) {
                    // A slice has no visible cell volume. Place one mean-tensor
                    // axis on each displayed cut-cell centroid, and omit cells
                    // that do not intersect the section at all.
                    section_center(scene.triangles.get(first_triangle..).unwrap_or_default())
                } else {
                    let sample = evaluate(g, cell, &u, [0.25; 4], settings, constant)?;
                    section
                        .is_none_or(|(n, d, _)| n.dot(sample.reference) <= d + tolerance)
                        .then(|| (sample.reference + sample.displacement * settings.deformation_scale - scene.render_origin_m) * 1000.)
                };
                if let Some(center) = center {
                    let mut box_cell = Aabb3::EMPTY;
                    for id in cell {
                        if let Some(p) = g.nodes_m.get(*id) {
                            box_cell.add(Vec3::from(*p));
                        }
                    }
                    let half = axis * (box_cell.diagonal() * 125.);
                    scene.glyphs.push(Glyph { a_mm: center - half, b_mm: center + half });
                }
            }
        }
    }
    if !scene.data_range.iter().all(|v| v.is_finite()) {
        return Err(bad(CMD, "selected quantity is unavailable for every active material"));
    }
    scene.color_range = legend_range(scene.data_range, &settings.quantity, settings.color_range);
    scene.key =
        format!("{:x}", Sha256::digest(format!("{manifest}:{}", serde_json::to_string(settings).map_err(|e| bad(CMD, e.to_string()))?).as_bytes()));
    Ok(scene)
}

fn legend_range(data: [f64; 2], quantity: &Quantity, fixed: Option<[f64; 2]>) -> [f64; 2] {
    if let Some(range) = fixed {
        return range;
    }
    let magnitude = data[0].abs().max(data[1].abs());
    if *quantity == Quantity::VerticalDisplacement {
        let max = magnitude.max(1e-12);
        return [-max, max];
    }
    // The legend prints six significant digits. Do not amplify differences below
    // that display resolution into a full rainbow on an almost uniform field.
    // Raw ranges, values, queries and an explicitly fixed range stay unchanged.
    if data[1] - data[0] <= magnitude * 1e-6 {
        let center = data[0] * 0.5 + data[1] * 0.5;
        let half = (magnitude * 0.01).max(1e-12);
        return [(center - half).max(-f64::MAX), (center + half).min(f64::MAX)];
    }
    data
}

pub(super) fn pick(scene: &Scene, origin: Vec3, direction: Vec3) -> Value {
    let mut nearest = None;
    let mut distance = f64::INFINITY;
    for t in &scene.triangles {
        let [a, b, c] = t.vertices.map(|v| v.position_mm);
        let ab = b - a;
        let ac = c - a;
        let p = direction.cross(ac);
        let det = ab.dot(p);
        if det.abs() < 1e-16 {
            continue;
        }
        let delta = origin - a;
        let u = delta.dot(p) / det;
        if !(0.0..=1.0).contains(&u) {
            continue;
        }
        let q = delta.cross(ab);
        let v = direction.dot(q) / det;
        if v < 0. || u + v > 1. {
            continue;
        }
        let d = ac.dot(q) / det;
        if d < 0. || d >= distance {
            continue;
        }
        let scalar = t.vertices[0].scalar.zip(t.vertices[1].scalar).zip(t.vertices[2].scalar).map(|((a, b), c)| a * (1. - u - v) + b * u + c * v);
        distance = d;
        nearest = Some(json!({"element":t.element_id,"section":t.section,"display_position_mm":origin+direction*d,"value":scalar,
            "display_position_m":(origin+direction*d)/1000.+scene.render_origin_m,
            "location":"display triangle interpolation for nodal quantities; constant original-cell mean otherwise"}));
        if let Some(meta) = scene.structural_hits.get(&t.element_id).and_then(Value::as_object)
            && let Some(hit) = nearest.as_mut().and_then(Value::as_object_mut)
        {
            hit.remove("element");
            hit.insert("location".into(), json!("raw plate sample displayed on its equal-area subregion; no nodal smoothing"));
            hit.extend(meta.iter().map(|(k, v)| (k.clone(), v.clone())));
        }
    }
    let radius = (scene.bounds.diagonal() * 0.004).max(1.);
    for line in &scene.member_lines {
        let edge = line.b_mm - line.a_mm;
        let r = origin - line.a_mm;
        let c = edge.dot(edge);
        if c <= 1e-20 {
            continue;
        }
        let b = direction.dot(edge);
        let d = direction.dot(r);
        let e = edge.dot(r);
        let denominator = c - b * b;
        let mut u = if denominator > c * 1e-14 { ((e - b * d) / denominator).clamp(0., 1.) } else { 0. };
        let mut t = (b * u - d).max(0.);
        u = ((e + b * t) / c).clamp(0., 1.);
        t = (b * u - d).max(0.);
        if t >= distance || (origin + direction * t - line.a_mm - edge * u).len() > radius {
            continue;
        }
        let Some(meta) = scene.structural_hits.get(&line.element_id).and_then(Value::as_object) else {
            continue;
        };
        distance = t;
        let mut hit = json!({"value":line.scalar,"display_position_mm":line.a_mm+edge*u,
            "display_position_m":(line.a_mm+edge*u)/1000.+scene.render_origin_m,
            "location":"member display segment; beam start/mid/end interpolation or raw plate section sample; stored values are available by member query"});
        if let Some(object) = hit.as_object_mut() {
            object.extend(meta.iter().map(|(k, v)| (k.clone(), v.clone())));
        }
        nearest = Some(hit);
    }
    nearest.unwrap_or(Value::Null)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn nearly_uniform_stress_does_not_display_numerical_noise_as_concentration() {
        // The actual Native MC partial-state scene exposed this 5.6e-9 kPa range.
        let measured = [69.72340410484648, 69.72340411044432];
        let range = legend_range(measured, &Quantity::MeanEffectiveStress, None);
        let coordinate = |v: f64| (v - range[0]) / (range[1] - range[0]);
        assert!((coordinate(measured[1]) - coordinate(measured[0])).abs() < 1e-6);
        assert!((coordinate(measured[0]) - 0.5).abs() < 1e-6);
        // A deliberate narrow range still allows examination of those raw values.
        assert_eq!(legend_range(measured, &Quantity::MeanEffectiveStress, Some(measured)), measured);
        assert_eq!(legend_range([69., 70.], &Quantity::MeanEffectiveStress, None), [69., 70.]);
        // The near-uniform decision is relative, not a unit-dependent absolute cut.
        assert_eq!(legend_range([1e-12, 2e-12], &Quantity::MeanEffectiveStress, None), [1e-12, 2e-12]);
        assert_eq!(legend_range([-2., 0.], &Quantity::VerticalDisplacement, None), [-2., 2.]);
        let zero = legend_range([0., 0.], &Quantity::MeanEffectiveStress, None);
        assert!(zero[0] < 0. && zero[1] > 0.);
        let huge = legend_range([f64::MAX, f64::MAX], &Quantity::MeanEffectiveStress, None);
        assert!(huge.iter().all(|v| v.is_finite()) && huge[0] < huge[1]);
    }
    fn fixture(quadratic: bool, curved: bool) -> (Geometry, Frame) {
        let mut nodes = vec![[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
        if quadratic {
            for [a, b] in EDGES {
                let p = (Vec3::from(nodes[a]) + Vec3::from(nodes[b])) * 0.5;
                nodes.push(p.into());
            }
            if curved {
                nodes[4][2] = 0.2;
            }
        }
        let count = nodes.len();
        let cell: Vec<_> = (0..count).collect();
        let mut faces = Vec::new();
        for corners in FACES {
            let mut face = corners.to_vec();
            if quadratic {
                for [a, b] in [[corners[0], corners[1]], [corners[1], corners[2]], [corners[2], corners[0]]] {
                    face.push(4 + EDGES.iter().position(|e| e.contains(&a) && e.contains(&b)).unwrap());
                }
            }
            faces.push(json!({"element_index":0,"nodes":face}));
        }
        let vectors: Vec<_> = nodes.iter().map(|p| [0., 0., 0.001 * p[0] * p[0]]).collect();
        let g=serde_json::from_value(json!({"schema":"soil-fem-view-geometry/1","length_unit":"m","axis":"Z-up","nodes_m":nodes,"cells":[cell],"cell_kind":if quadratic{"tetra10"}else{"tetra4"},"regions":[],"node_sets":{},"crs":"LOCAL","origin_m":[0,0,0]})).unwrap();
        let f=serde_json::from_value(json!({"schema":"soil-fem-view-frame/1","index":0,"name":"test","active_element_ids":[0],"active_node_ids":(0..count).collect::<Vec<_>>(),"boundary_faces":faces,
            "node_fields":{"displacement_m":vectors,"stage_displacement_increment_m":vectors,"total_displacement_from_seed_m":vectors,"display_reference_displacement_m":vec![[0.;3];count]},
            "cell_fields":{"effective_stress_compression_positive_kpa":[[3.,2.,1.,0.,0.,0.]],"plastic_strain_compression_positive":vec![[0.;6]],"void_ratio":[0.8],"preconsolidation_pressure_kpa":[123.],"material_id":[1],"region_id":[1],"material_model":[0]},
            "monitors":{},"relative_force_residual":0.,"maximum_normalized_yield":0.})).unwrap();
        (g, f)
    }
    #[test]
    fn quadratic_boundary_preserves_surface_area_and_cell_constant_values() {
        let (g, f) = fixture(true, false);
        check_boundary(&g, &f).unwrap();
        for (refinement, triangles) in [(1, 16), (2, 64), (3, 256)] {
            let settings = Settings { quantity: Quantity::PreconsolidationPressure, refinement, deformation_scale: 0., ..Default::default() };
            let scene = build(&g, &f, &settings, "synthetic").unwrap();
            assert_eq!(scene.triangles.len(), triangles);
            let area: f64 = scene
                .triangles
                .iter()
                .map(|t| {
                    let [a, b, c] = t.vertices.map(|v| v.position_mm);
                    (b - a).cross(c - a).len() * 0.5e-6
                })
                .sum();
            assert!((area - (1.5 + 3.0f64.sqrt() * 0.5)).abs() < 1e-12);
            assert!(scene.triangles.iter().flat_map(|t| t.vertices).all(|v| v.scalar == Some(123.)));
        }
    }
    #[test]
    fn refined_curved_section_converges_to_independent_area_and_quadratic_field() {
        let (g, f) = fixture(true, true);
        let mut settings = Settings {
            deformation_scale: 0.,
            section: Some(Section { normal: [1., 0., 0.], offset_m: 0.25, slice_only: true }),
            ..Default::default()
        };
        let coarse = build(&g, &f, &settings, "coarse").unwrap();
        assert!((coarse.reference_section_area_m2 - 0.24375).abs() < 1e-12);
        for refinement in [2, 3] {
            settings.refinement = refinement;
            let scene = build(&g, &f, &settings, "fine").unwrap();
            // z=t+0.8*r*(1-r-s-t); at r=1/4 this is affine in s,t.
            // The triangle has y extent 3/4 and z extent 3/4-3/20.
            assert!((scene.reference_section_area_m2 - 0.225).abs() < 1e-12);
            assert!(scene.triangles.iter().all(|t| t.section));
            let values: Vec<_> = scene.triangles.iter().flat_map(|t| t.vertices).map(|v| v.scalar.unwrap()).collect();
            assert!(values.iter().all(|v| (*v - 0.0625).abs() < 1e-12), "refinement {refinement}: {values:?}");
        }
    }
    #[test]
    fn section_on_subdivision_faces_is_not_double_counted_and_warp_follows_reference_cut() {
        let (g, f) = fixture(true, false);
        for refinement in [1, 2, 3] {
            let settings = Settings {
                refinement,
                deformation_scale: 100.,
                principal_directions: true,
                section: Some(Section { normal: [2., 0., 0.], offset_m: 1., slice_only: true }),
                ..Default::default()
            };
            let scene = build(&g, &f, &settings, "cut").unwrap();
            assert!((scene.reference_section_area_m2 - 0.125).abs() < 1e-12);
            assert!(scene.triangles.iter().flat_map(|t| t.vertices).all(|v| v.position_mm.x.abs() < 1e-10));
            assert_eq!(scene.glyphs.len(), 1);
            let anchor = (scene.glyphs[0].a_mm + scene.glyphs[0].b_mm) / 2000. + scene.render_origin_m;
            assert!((anchor.x - 0.5).abs() < 1e-12);
            assert!((anchor.y - 1. / 6.).abs() < 1e-12);
            assert!((anchor.z - (1. / 6. + 0.025)).abs() < 1e-12);
            let face = Settings {
                refinement,
                deformation_scale: 0.,
                section: Some(Section { normal: [-1., 0., 0.], offset_m: 0., slice_only: true }),
                ..Default::default()
            };
            let face_scene = build(&g, &f, &face, "coplanar face").unwrap();
            assert!((face_scene.reference_section_area_m2 - 0.5).abs() < 1e-12);
        }
        let outside = Settings {
            principal_directions: true,
            section: Some(Section { normal: [1., 0., 0.], offset_m: 2., slice_only: true }),
            ..Default::default()
        };
        let empty = build(&g, &f, &outside, "outside slice").unwrap();
        assert!(empty.triangles.is_empty());
        assert!(empty.glyphs.is_empty(), "a cell wholly on the retained side still has no slice intersection");
    }
    #[test]
    fn mean_tensor_axes_rotate_and_repeated_major_directions_are_not_invented() {
        let p = principal([3., 3., 1., 1., 0., 0.]);
        assert!((p.values[0] - 4.).abs() < 1e-12);
        assert!((p.values[1] - 2.).abs() < 1e-12);
        assert!((p.values[2] - 1.).abs() < 1e-12);
        let axis = p.axis.unwrap();
        let expected = Vec3::new(1., 1., 0.).normalized().unwrap();
        assert!((axis.dot(expected).abs() - 1.).abs() < 1e-12);
        assert!(principal([4., 4., 1., 0., 0., 0.]).axis.is_none());
        assert!(principal([3., 3., 3., 0., 0., 0.]).axis.is_none());
    }
    #[test]
    fn ray_queries_retain_original_element_and_world_display_position() {
        let (g, f) = fixture(true, false);
        let settings = Settings { quantity: Quantity::PreconsolidationPressure, deformation_scale: 0., ..Default::default() };
        let scene = build(&g, &f, &settings, "ray").unwrap();
        let hit = pick(&scene, Vec3::new(-400., -400., 2000.), -Vec3::Z);
        assert_eq!(hit["element"], 0);
        assert_eq!(hit["value"], 123.);
        assert!((hit["display_position_m"][2].as_f64().unwrap() - 0.8).abs() < 1e-12);
    }
    #[test]
    fn unavailable_values_are_not_zero_and_bad_connectivity_is_an_error() {
        let (mut g, mut f) = fixture(false, false);
        f.cell_fields.preconsolidation_pressure_kpa = vec![None];
        let settings = Settings { quantity: Quantity::PreconsolidationPressure, ..Default::default() };
        assert!(build(&g, &f, &settings, "null").is_err());
        g.cells[0][0] = usize::MAX;
        assert!(build(&g, &f, &Settings::default(), "bad").is_err());
    }
}
