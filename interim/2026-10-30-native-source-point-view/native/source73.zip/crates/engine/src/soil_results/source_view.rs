//! Shared access to dynamic histories and bounded, typed projected-MCC data.
//! Typed histories never become a whole serde_json::Value array.
use super::source_compact::{MccState, Point, Selected};
use crate::{Result, params::bad};
use serde_json::{Value, json};
use std::ops::Deref;

const CMD: &str = "analysis.soil.results";

pub(super) enum SourceRun {
    Dynamic(Value),
    Mcc { frame: usize, selected: Selected },
}
impl From<Value> for SourceRun {
    fn from(value: Value) -> Self {
        Self::Dynamic(value)
    }
}
impl Deref for SourceRun {
    type Target = Value;
    fn deref(&self) -> &Value {
        match self {
            Self::Dynamic(value) => value,
            Self::Mcc { selected, .. } => &selected.value,
        }
    }
}
impl SourceRun {
    pub fn histories(&self, index: usize) -> Result<History<'_>> {
        match self {
            Self::Mcc { frame, selected } if *frame == index => Ok(History::Mcc(&selected.states)),
            Self::Mcc { .. } => Err(bad(CMD, "typed source does not retain this frame's histories")),
            Self::Dynamic(value) => {
                let state = value
                    .get("frames")
                    .and_then(|a| a.get(index))
                    .and_then(|f| f.get("state"))
                    .ok_or_else(|| bad(CMD, "missing authoritative history frame"))?;
                History::from_state(state)
            }
        }
    }
    pub fn typed_layout(&self) -> Option<&[Point]> {
        match self {
            Self::Mcc { selected, .. } => Some(&selected.points),
            Self::Dynamic(_) => None,
        }
    }
    pub fn layout_count(&self) -> Option<usize> {
        self.typed_layout().map(<[Point]>::len).or_else(|| self.get("integration_points").and_then(Value::as_array).map(Vec::len))
    }
    pub fn natural(&self, id: usize) -> Result<[f64; 3]> {
        if let Some(points) = self.typed_layout() {
            return points.get(id).map(|p| p.natural_coordinates).ok_or_else(|| bad(CMD, "missing typed source natural coordinates"));
        }
        let value = self
            .get("integration_points")
            .and_then(|p| p.get(id))
            .and_then(|p| p.get("natural_coordinates"))
            .ok_or_else(|| bad(CMD, "missing source natural coordinates"))?;
        let values: [f64; 3] = serde_json::from_value(value.clone()).map_err(|e| bad(CMD, e.to_string()))?;
        if values.iter().any(|v| !v.is_finite() || v.abs() > 1e100) {
            return Err(bad(CMD, "invalid source natural coordinates"));
        }
        Ok(values)
    }
    pub fn storage(&self) -> Value {
        match self {
            Self::Dynamic(_) => json!({"representation":"bounded_dynamic_selected_frame"}),
            Self::Mcc { selected, .. } => json!({"representation":"typed_projected_MCC_selected_frame",
                "conservative_retained_accounted_bytes":selected.accounted_bytes,
                "material_history_count":selected.states.len(),"integration_layout_count":selected.points.len()}),
        }
    }
}

#[derive(Clone, Copy)]
pub(super) enum History<'a> {
    Dynamic(&'a [Value]),
    Mcc(&'a [MccState]),
}
impl<'a> History<'a> {
    pub fn from_state(state: &'a Value) -> Result<Self> {
        state
            .get("material_states")
            .and_then(Value::as_array)
            .map(|v| Self::Dynamic(v))
            .ok_or_else(|| bad(CMD, "missing authoritative material histories"))
    }
    pub fn len(self) -> usize {
        match self {
            Self::Dynamic(v) => v.len(),
            Self::Mcc(v) => v.len(),
        }
    }
    pub fn get(self, id: usize) -> Option<StateRef<'a>> {
        match self {
            Self::Dynamic(v) => v.get(id).map(StateRef::Dynamic),
            Self::Mcc(v) => v.get(id).map(StateRef::Mcc),
        }
    }
}

#[derive(Clone, Copy)]
pub(super) enum StateRef<'a> {
    Dynamic(&'a Value),
    Mcc(&'a MccState),
}
impl StateRef<'_> {
    pub fn model(self) -> u32 {
        match self {
            Self::Mcc(_) => 0,
            Self::Dynamic(s) if s.get("preconsolidation_pressure_kpa").is_some() => 0,
            Self::Dynamic(s) if s.get("cap_pressure_kpa").is_some() => 2,
            Self::Dynamic(_) => 1,
        }
    }
    pub fn scalar(self, key: &str) -> Option<f64> {
        match self {
            Self::Mcc(s) => match key {
                "void_ratio" => Some(s.void_ratio),
                "preconsolidation_pressure_kpa" => Some(s.preconsolidation_pressure_kpa),
                _ => None,
            },
            Self::Dynamic(s) => s.get(key).and_then(Value::as_f64),
        }
    }
    pub fn tensor(self, key: &str) -> Result<[f64; 6]> {
        match self {
            Self::Mcc(s) => match key {
                "effective_stress_compression_positive_kpa" => Ok(s.effective_stress_compression_positive_kpa),
                "plastic_strain_compression_positive" => Ok(s.plastic_strain_compression_positive),
                _ => Err(bad(CMD, "missing typed source tensor")),
            },
            Self::Dynamic(s) => {
                let values: [f64; 6] = serde_json::from_value(s.get(key).cloned().ok_or_else(|| bad(CMD, "missing source point tensor"))?)
                    .map_err(|e| bad(CMD, e.to_string()))?;
                if values.iter().any(|v| !v.is_finite() || v.abs() > 1e100) {
                    return Err(bad(CMD, "invalid source point tensor"));
                }
                Ok(values)
            }
        }
    }
}
