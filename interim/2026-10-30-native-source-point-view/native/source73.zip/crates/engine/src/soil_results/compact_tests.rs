#![allow(clippy::expect_used)]
use super::*;
use serde_json::json;

fn fixture() -> Value {
    let state = json!({"effective_stress_compression_positive_kpa":[12.,13.,14.,0.1,0.2,0.3],
        "void_ratio":0.8,"preconsolidation_pressure_kpa":30.,"plastic_strain_compression_positive":[0.01,0.02,0.03,0.04,0.05,0.06]});
    let frames: Vec<_> = (0..3)
        .map(|i| {
            json!({"name":format!("stage{i}"),"state":{
        "material_states":[state],"displacement_m":[[i as f64,2.,3.]],"active_elements":[true],
        "mixed_mcc":{"example":[1.,2.,3.]}}})
        })
        .collect();
    json!({"schema":"soil-fem-projected-mcc-stage-result/2","complete":true,
        "case":{"stages":[{"kind":"birth"}]},"frames":frames,
        "geostatic":{"discarded":"x".repeat(100_000)},
        "integration_points":[{"element_index":0,"local_index":0,"natural_coordinates":[0.1,0.2,0.3],"shape_functions":[1.,0.,0.,0.,0.,0.,0.,0.,0.,0.],"position_m":[1.,2.,3.],"weight_m3":0.5}],
        "transition_audits":[{"stage":"stage1","prepared_state":{"displacement_m":[[0.5,2.,3.]],"material_states":[state]}}]})
}
fn parse(value: &Value, frame: usize, budget: usize) -> Result<Selected, String> {
    let raw = serde_json::to_vec(value).expect("fixture");
    selected(raw.as_slice(), frame, raw.len(), budget)
}

#[test]
fn every_selected_history_and_layout_value_exact_and_previous_history_not_retained() {
    let original = fixture();
    let raw = serde_json::to_vec(&original).expect("fixture");
    for frame in 0..3 {
        let actual = parse(&original, frame, 32 << 10).expect("bounded typed selection");
        assert_eq!(actual.digest, format!("{:x}", Sha256::digest(&raw)));
        assert_eq!(serde_json::to_value(&actual.states).expect("states"), original["frames"][frame]["state"]["material_states"]);
        assert_eq!(serde_json::to_value(&actual.points).expect("points"), original["integration_points"]);
        let mut expected = original["frames"][frame].clone();
        expected["state"].as_object_mut().expect("state").remove("material_states");
        assert_eq!(actual.value["frames"][frame], expected);
        if frame > 0 {
            assert_eq!(actual.value["frames"][frame - 1]["state"]["displacement_m"], original["frames"][frame - 1]["state"]["displacement_m"]);
            assert!(actual.value["frames"][frame - 1]["state"].get("material_states").is_none());
        }
        assert!(actual.value.get("integration_points").is_none());
        assert!(actual.value.get("geostatic").is_none());
        assert!(actual.value["transition_audits"][0]["prepared_state"].get("material_states").is_none());
        assert!(actual.accounted_bytes < 32 << 10);
    }
}
#[test]
fn skipped_history_still_changes_complete_source_digest() {
    let original = fixture();
    let mut changed = original.clone();
    changed["frames"][0]["state"]["material_states"][0]["void_ratio"] = json!(0.7);
    let a = parse(&original, 2, 32 << 10).expect("a");
    let b = parse(&changed, 2, 32 << 10).expect("b");
    assert_ne!(a.digest, b.digest);
    assert_eq!(a.states, b.states);
    assert_eq!(a.value, b.value);
}
#[test]
fn numeric_and_point_count_and_schema_limits_are_independent() {
    let original = fixture();
    let mut v = original.clone();
    v["frames"][1]["state"]["material_states"][0]["void_ratio"] = json!(-1.);
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["frames"][1]["state"]["material_states"][0]["preconsolidation_pressure_kpa"] = json!(0.);
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["frames"][1]["state"]["material_states"][0]["effective_stress_compression_positive_kpa"][0] = json!(1e101);
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"][0]["weight_m3"] = json!(0.);
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"] = json!([]);
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["schema"] = json!("unsupported");
    assert!(parse(&v, 1, 1 << 20).is_err());
    v = original.clone();
    v["complete"] = json!(false);
    assert!(parse(&v, 1, 1 << 20).is_err());
    assert!(parse(&original, 3, 1 << 20).is_err());
    assert!(parse(&original, 257, 1 << 20).is_err());
    assert!(parse(&original, 1, 64).is_err());
}
#[test]
fn duplicate_retained_keys_unknown_material_fields_truncation_and_trailing_input_rejected() {
    let original = fixture();
    let raw = serde_json::to_string(&original).expect("fixture");
    let cases = [
        raw.replacen("\"complete\":true", "\"complete\":true,\"complete\":true", 1),
        raw.replacen("\"name\":\"stage0\"", "\"name\":\"stage0\",\"name\":\"stage0\"", 1),
        raw.replacen("\"void_ratio\":0.8", "\"void_ratio\":0.8,\"void_ratio\":0.8", 1),
        raw.replacen("\"void_ratio\":0.8", "\"void_ratio\":0.8,\"unexpected\":1", 1),
        raw.replacen("\"weight_m3\":0.5", "\"weight_m3\":0.5,\"weight_m3\":0.5", 1),
        format!("{raw} []"),
        raw[..raw.len() - 1].to_owned(),
    ];
    for bad in cases {
        assert!(selected(bad.as_bytes(), 0, 2 << 20, 1 << 20).is_err());
    }
    assert!(selected(raw.as_bytes(), 0, raw.len() - 1, 1 << 20).is_err());
}
#[test]
fn typed_entries_are_budgeted_before_unbounded_vector_growth() {
    let mut v = fixture();
    let point = v["integration_points"][0].clone();
    let state = v["frames"][0]["state"]["material_states"][0].clone();
    v["integration_points"] = Value::Array(vec![point; 1000]);
    v["frames"][0]["state"]["material_states"] = Value::Array(vec![state; 1000]);
    assert!(parse(&v, 0, 32 << 10).is_err());
    let actual = parse(&v, 0, 1 << 20).expect("bounded1000");
    assert_eq!(actual.states.len(), 1000);
    assert!(actual.accounted_bytes >= 2000 * (std::mem::size_of::<MccState>() + std::mem::size_of::<Point>()));
}

#[test]
fn full_layout_natural_coordinates_and_shape_functions_are_validated() {
    let original = fixture();
    let mut v = original.clone();
    v["integration_points"][0]["local_index"] = json!(512);
    assert!(parse(&v, 0, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"][0]["natural_coordinates"] = json!([0.5, 0.5, 0.5]);
    assert!(parse(&v, 0, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"][0]["shape_functions"][0] = json!(2.);
    assert!(parse(&v, 0, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"][0]["shape_functions"] = json!([1.]);
    assert!(parse(&v, 0, 1 << 20).is_err());
    v = original.clone();
    v["integration_points"][0]["unexpected"] = json!(1);
    assert!(parse(&v, 0, 1 << 20).is_err());
}

#[test]
fn short_array_cannot_exceed_accounted_capacity_at_initial_growth() {
    let state = fixture()["frames"][0]["state"]["material_states"][0].clone();
    let raw = serde_json::to_vec(&vec![state; 3]).expect("three states");
    // Three entries need capacity4. Budget for only six payloads cannot
    // conservatively cover both old/new allocations at that growth point.
    let budget = Budget(Cell::new(6 * std::mem::size_of::<MccState>()));
    let mut d = serde_json::Deserializer::from_slice(&raw);
    assert!(Typed::<MccState>(&budget, PhantomData).deserialize(&mut d).is_err());
    let budget = Budget(Cell::new(8 * std::mem::size_of::<MccState>()));
    let mut d = serde_json::Deserializer::from_slice(&raw);
    assert_eq!(Typed::<MccState>(&budget, PhantomData).deserialize(&mut d).expect("capacity4 within budget").len(), 3);
}
