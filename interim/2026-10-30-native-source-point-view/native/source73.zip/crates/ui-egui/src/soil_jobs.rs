//! Native job controls are a thin adapter over the engine's owned-process commands.
use crate::{SolveApp, ui_kit};
use serde_json::{Value, json};

pub(super) struct JobsPanel {
    directory: String,
    mesh_size_m: f64,
    element_order: u8,
    quadrature_order: u8,
    cooperative: bool,
    previous_directory: String,
    periodic_snapshot: bool,
    status: Value,
    next_poll: f64,
}

impl Default for JobsPanel {
    fn default() -> Self {
        Self {
            directory: String::new(),
            mesh_size_m: 2.,
            element_order: 2,
            quadrature_order: 3,
            cooperative: true,
            previous_directory: String::new(),
            periodic_snapshot: false,
            status: Value::Null,
            next_poll: 0.,
        }
    }
}

impl JobsPanel {
    pub(super) fn poll(&mut self, app: &mut SolveApp) -> Result<(), String> {
        if app.now >= self.next_poll || self.status.is_null() {
            self.next_poll = app.now + 0.5;
            self.status = app.run("analysis.soil.job.status", json!({}))?;
            if self.previous_directory.is_empty() && self.status.get("resume_available").and_then(Value::as_bool) == Some(true) {
                self.previous_directory = self.status.get("directory").and_then(Value::as_str).unwrap_or_default().to_string();
            }
        }
        Ok(())
    }

    pub(super) fn show(&mut self, ui: &mut egui::Ui, reviewed: bool) -> Option<&'static str> {
        let active = self.status.get("process_alive").and_then(Value::as_bool) == Some(true);
        let host = self.status.get("host_available").and_then(Value::as_bool) == Some(true);
        ui_kit::row(ui, "New job folder", |ui| {
            ui_kit::text_field(ui, &mut self.directory, "");
        });
        ui_kit::row(ui, "Mesh size (m)", |ui| {
            ui_kit::number_field(ui, &mut self.mesh_size_m, 0.001..=1e6, 0.1, "");
        });
        ui_kit::row(ui, "Element", |ui| {
            let mut selected = usize::from(self.element_order.saturating_sub(1));
            if ui_kit::segmented(ui, &mut selected, &["Tet4", "Tet10"], ui_kit::Segments::default()) {
                self.element_order = (selected + 1) as u8;
            }
        });
        ui_kit::row(ui, "Quadrature order", |ui| {
            let mut selected = usize::from(self.quadrature_order.saturating_sub(3));
            if ui_kit::segmented(ui, &mut selected, &["3", "4", "5"], ui_kit::Segments::default()) {
                self.quadrature_order = (selected + 3) as u8;
            }
        });
        ui_kit::checkbox(ui, crate::i18n::tr_label("Save a checkpoint when stopping"), &mut self.cooperative);
        ui_kit::row(ui, "Saved job folder", |ui| {
            ui_kit::text_field(ui, &mut self.previous_directory, "");
        });
        ui_kit::checkbox(ui, "Recover from a periodic snapshot", &mut self.periodic_snapshot);
        if self.periodic_snapshot {
            ui_kit::text(
                ui,
                "Fork the selected saved job into a new folder. The original job is not stopped or changed; it may still be running.",
                ui_kit::Text::Note("soil_job_periodic_recovery"),
            );
        }
        if !host {
            ui_kit::text(
                ui,
                "Set SOLIDCRAFT_SOIL_FEM_ROOT to the installed FEM environment before starting the desktop app.",
                ui_kit::Text::Note("soil_job_host"),
            );
        }
        let mut action = None;
        ui.horizontal(|ui| {
            if ui_kit::button(ui, "Start Soil Analysis", ui_kit::Button::Enabled(host && reviewed && !active && !self.directory.trim().is_empty()))
                .clicked()
            {
                action = Some("start");
            }
            if ui_kit::button(
                ui,
                "Stop Soil Analysis",
                ui_kit::Button::Enabled(active && self.status.get("cancel_requested").and_then(Value::as_bool) != Some(true)),
            )
            .clicked()
            {
                action = Some("cancel");
            }
            if ui_kit::button(
                ui,
                if self.periodic_snapshot { "Recover Soil Analysis" } else { "Resume Soil Analysis" },
                ui_kit::Button::Enabled(
                    host && reviewed && !active && !self.directory.trim().is_empty() && !self.previous_directory.trim().is_empty(),
                ),
            )
            .clicked()
            {
                action = Some("resume");
            }
        });
        let state = self.status.get("state").and_then(Value::as_str).unwrap_or("waiting");
        let phase = self.status.pointer("/worker_report/phase").and_then(Value::as_str).unwrap_or("waiting for worker");
        ui.label(format!("State: {state} · {phase}"));
        if let Some(seconds) = self.status.pointer("/worker_report/elapsed_seconds").and_then(Value::as_f64) {
            ui.label(format!("Elapsed: {seconds:.1} s"));
        }
        if let Some(progress) = self.status.pointer("/worker_report/solver_report/last_progress") {
            let stage = progress.get("stage").and_then(Value::as_str).unwrap_or("initialization");
            let fraction = progress.get("progress").and_then(Value::as_f64).unwrap_or(0.);
            let iteration = progress.get("newton_iteration").and_then(Value::as_u64).unwrap_or(0);
            ui.label(format!("{stage}: {:.1}% · Newton {iteration}", fraction * 100.));
        }
        if self.status.get("resume_usable").and_then(Value::as_bool) == Some(true) {
            ui_kit::text(ui, "Checkpoint verified for this model. Choose a new job folder and resume.", ui_kit::Text::Note("soil_job_saved"));
        }
        if let Some(input) = self.status.get("input_sha256").and_then(Value::as_str) {
            ui.label(format!("Input SHA-256: {input}"));
        }
        if let Some(directory) = self.status.get("directory").and_then(Value::as_str) {
            ui.label(format!("Job: {directory}"));
        }
        if self.status.get("stale").and_then(Value::as_bool) == Some(true) {
            ui_kit::text(
                ui,
                "CAD or analysis inputs changed. This job uses its captured input; its results do not apply to the current model.",
                ui_kit::Text::Report("soil_job_stale", true),
            );
        }
        if self.status.get("result_usable").and_then(Value::as_bool) == Some(true) {
            ui_kit::text(
                ui,
                "Completed result and VTU audit verified for the current input. Open Soil Result Viewer to inspect this captured result.",
                ui_kit::Text::Note("soil_job_complete"),
            );
            if ui_kit::button(ui, crate::i18n::tr_label("Soil Result Viewer"), ui_kit::Button::Normal).clicked() {
                action = Some("view_results");
            }
        }
        if let Some(error) = self.status.pointer("/worker_report/error").and_then(Value::as_str) {
            ui_kit::text(ui, error, ui_kit::Text::Report("soil_job_error", true));
        }
        if let Some(error) = self.status.get("observation_error").and_then(Value::as_str) {
            ui_kit::text(ui, error, ui_kit::Text::Note("soil_job_observation"));
        }
        if let Some(tail) = self.status.pointer("/worker_report/tail").and_then(Value::as_array) {
            ui_kit::section(ui, "soil_worker_log", "Worker log", false, |ui| {
                for line in tail.iter().filter_map(Value::as_str).take(30) {
                    ui.label(line);
                }
            });
        }
        ui_kit::text(
            ui,
            if self.status.get("stop_policy").and_then(Value::as_str) == Some("cooperative_staged_checkpoint") || (!active && self.cooperative) {
                "Stop waits for an accepted increment and saves a checkpoint. Resume uses the same installed solver and workflow version. Before solving starts, Stop cancels preparation."
            } else {
                "Legacy Stop ends the owned worker process tree without creating a new checkpoint."
            },
            ui_kit::Text::Note("soil_job_stop_policy"),
        );
        action
    }

    pub(super) fn act(&mut self, app: &mut SolveApp, action: &str) -> Result<(), String> {
        if action == "view_results" {
            let path = self.status.get("result").and_then(Value::as_str).ok_or("No completed result path")?;
            let snapshot = app.run("analysis.soil.snapshot", json!({}))?;
            let info = app.run("analysis.soil.results.open", json!({"manifest":path,"expected_input_sha256":snapshot.get("input_sha256")}))?;
            if let Some(mut settings) = app.session.soil_result_settings() {
                settings.frame = info.get("frames").and_then(Value::as_array).map_or(0, |v| v.len().saturating_sub(1));
                app.run("analysis.soil.results.configure", serde_json::to_value(settings).map_err(|e| e.to_string())?)?;
            }
            crate::soil_results::open_viewer(app);
            return Ok(());
        }
        self.status = if action == "start" {
            let snapshot = app.run("analysis.soil.snapshot", json!({}))?;
            app.run(
                "analysis.soil.job.start",
                json!({"directory":self.directory.trim(),"expected_input_sha256":snapshot.get("input_sha256"),
                "mesh_size_m":self.mesh_size_m,"element_order":self.element_order,"quadrature_order":self.quadrature_order,"cooperative":self.cooperative}),
            )?
        } else if action == "resume" {
            let snapshot = app.run("analysis.soil.snapshot", json!({}))?;
            app.run(
                "analysis.soil.job.resume",
                json!({"directory":self.directory.trim(),"previous_directory":self.previous_directory.trim(),
                "expected_input_sha256":snapshot.get("input_sha256"),"periodic_snapshot":self.periodic_snapshot}),
            )?
        } else if action == "cancel" {
            app.run("analysis.soil.job.cancel", json!({"job":self.status.get("job")}))?
        } else {
            return Err("Unknown soil job action".into());
        };
        Ok(())
    }
}
