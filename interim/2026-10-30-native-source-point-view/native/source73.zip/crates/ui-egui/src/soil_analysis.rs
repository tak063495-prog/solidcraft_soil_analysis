//! A thin editor over analysis.soil.*. Drafts live here; saved attributes,
//! identity resolution, source checks and native STEP captures belong to L4.
use crate::{SolveApp, ui_kit};
use serde_json::{Value, json};
use solidcraft_engine::soil_fem::{self, Setup};
use std::collections::BTreeMap;

pub struct SoilAnalysis {
    pub ground: Option<Value>,
    pub stages: Option<Value>,
    pub bindings: BTreeMap<String, String>,
    status: Value,
    expected_cad: String,
    expected_setup: String,
    revision: u64,
    page: u8,
    pub error: Option<String>,
    notice: Option<String>,
    dirty: bool,
    pub output_directory: String,
    #[cfg(not(target_arch = "wasm32"))]
    jobs: super::soil_jobs::JobsPanel,
}

impl SoilAnalysis {
    fn new(app: &SolveApp) -> Self {
        let status = soil_fem::inspect(&app.session).unwrap_or_else(|e| json!({"issues":[e.to_string()]}));
        let saved = status.get("configuration").cloned().and_then(|v| serde_json::from_value::<Setup>(v).ok());
        Self {
            ground: saved.as_ref().map(|v| v.ground.clone()),
            stages: saved.as_ref().map(|v| v.stages.clone()),
            bindings: saved.as_ref().map(|v| v.bindings.iter().map(|b| (b.analysis_body.clone(), b.cad_body.clone())).collect()).unwrap_or_default(),
            expected_cad: status.get("cad_sha256").and_then(Value::as_str).unwrap_or_default().to_string(),
            expected_setup: status.get("setup_sha256").and_then(Value::as_str).unwrap_or_default().to_string(),
            status,
            revision: app.session.revision,
            page: 0,
            error: None,
            notice: None,
            dirty: false,
            output_directory: String::new(),
            #[cfg(not(target_arch = "wasm32"))]
            jobs: Default::default(),
        }
    }

    fn save(&mut self, app: &mut SolveApp) {
        let (Some(ground), Some(stages)) = (&self.ground, &self.stages) else {
            self.error = Some("Load ground and construction inputs first".into());
            return;
        };
        let bindings: Vec<_> = self.bindings.iter().map(|(a, b)| json!({"analysis_body":a,"cad_body":b})).collect();
        let request = json!({"ground":ground,"stages":stages,"bindings":bindings,"expected_cad_sha256":self.expected_cad,"expected_setup_sha256":self.expected_setup});
        match app.run("analysis.soil.configure", request) {
            Ok(_) => {
                let page = self.page;
                let output_directory = self.output_directory.clone();
                #[cfg(not(target_arch = "wasm32"))]
                let jobs = std::mem::take(&mut self.jobs);
                *self = Self::new(app);
                self.page = page;
                self.output_directory = output_directory;
                #[cfg(not(target_arch = "wasm32"))]
                {
                    self.jobs = jobs;
                }
                self.notice = Some("Analysis attributes saved in this design".into());
            }
            Err(e) => self.error = Some(e),
        }
    }

    fn load(&mut self, value: Value, cad: &[String]) {
        self.ground = value.get("ground").cloned();
        self.stages = value.get("stages").cloned();
        self.bindings.clear();
        for name in value.get("required_body_labels").and_then(Value::as_array).into_iter().flatten().filter_map(Value::as_str) {
            self.bindings.insert(name.to_string(), if cad.iter().any(|n| n == name) { name.to_string() } else { String::new() });
        }
        self.error = None;
        self.notice = Some("Review the material parameters, construction and CAD body assignments before saving".into());
        self.dirty = true;
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn export(&mut self, app: &mut SolveApp) {
        let snapshot = match app.run("analysis.soil.snapshot", json!({})) {
            Ok(v) => v,
            Err(e) => {
                self.error = Some(e);
                return;
            }
        };
        let directory = self.output_directory.trim().to_string();
        if directory.is_empty() {
            self.error = Some("Choose a new capture folder".into());
            return;
        }
        match app.run("analysis.soil.export", json!({"directory":directory,"expected_input_sha256":snapshot.get("input_sha256")})) {
            Ok(_) => {
                self.error = None;
                self.notice = Some(format!("STEP and analysis inputs exported to {}", directory));
            }
            Err(e) => self.error = Some(e),
        }
    }
}

pub fn open(app: &mut SolveApp) {
    app.soil_analysis = Some(SoilAnalysis::new(app));
}

pub fn open_jobs(app: &mut SolveApp) {
    open(app);
    if let Some(draft) = app.soil_analysis.as_mut() {
        draft.page = 3;
    }
}

fn start_import(app: &mut SolveApp) {
    app.pick_file("Ground materials and initial state", &["json"], |app, ground| {
        let Some(ground) = ground else { return };
        app.pick_file("Construction stages", &["json"], move |app, stages| {
            let Some(stages) = stages else { return };
            let result = app.run("analysis.soil.read_inputs", json!({"ground_path":ground,"stages_path":stages}));
            let cad: Vec<_> = app.session.model.state().bodies.iter().map(|b| b.name.clone()).collect();
            if let Some(d) = app.soil_analysis.as_mut() {
                match result {
                    Ok(v) => d.load(v, &cad),
                    Err(e) => d.error = Some(e),
                }
            }
        });
    });
}

/// Preserve integer identifiers and show small scalars without hiding their scale.
fn number_input(ui: &mut egui::Ui, value: &mut serde_json::Number) -> bool {
    if let Some(mut x) = value.as_u64() {
        let changed = ui_kit::number_field(ui, &mut x, 0..=u64::MAX, 1., "").changed();
        if changed {
            *value = x.into();
        }
        return changed;
    }
    if let Some(mut x) = value.as_i64() {
        let changed = ui_kit::number_field(ui, &mut x, i64::MIN..=i64::MAX, 1., "").changed();
        if changed {
            *value = x.into();
        }
        return changed;
    }
    if let Some(mut x) = value.as_f64() {
        let magnitude = x.abs();
        let speed = if magnitude > 0.0 && magnitude < 0.001 { (magnitude * 0.01).max(f64::MIN_POSITIVE) } else { 0.001 };
        if ui_kit::formatted_number_field(ui, &mut x, f64::MIN..=f64::MAX, speed, "", |v, decimals| {
            if v != 0.0 && !(1e-4..1e8).contains(&v.abs()) { format!("{v:.3e}") } else { egui::emath::format_with_decimals_in_range(v, decimals) }
        })
        .changed()
            && x.is_finite()
            && let Some(number) = serde_json::Number::from_f64(x)
        {
            *value = number;
            return true;
        }
    }
    false
}

/// Typed JSON forms are view adapters only. No constitutive law, CAD identity
/// guess or unit conversion is performed in the front end.
fn properties(ui: &mut egui::Ui, id: &str, value: &mut Value, depth: usize, budget: &mut usize) -> bool {
    if depth > 10 || *budget == 0 {
        ui.label("Additional input values are retained");
        return false;
    }
    *budget -= 1;
    let mut changed = false;
    match value {
        Value::Object(map) => {
            for (key, v) in map {
                if matches!(key.as_str(), "schema" | "units" | "settings" | "verification_reject_once" | "verification_reject_once_stages") {
                    continue;
                }
                let path = format!("{id}.{key}");
                match v {
                    Value::Object(_) | Value::Array(_) => {
                        ui_kit::section(ui, &path, field_label(key), depth < 1, |ui| {
                            changed |= properties(ui, &path, v, depth + 1, budget);
                        });
                    }
                    Value::Number(n) => {
                        ui_kit::row(ui, field_label(key), |ui| {
                            changed |= number_input(ui, n);
                        });
                    }
                    Value::String(text) => {
                        ui_kit::row(ui, field_label(key), |ui| {
                            if matches!(key.as_str(), "kind" | "method" | "definition" | "flow") {
                                ui.label(text.as_str());
                            } else {
                                changed |= ui_kit::text_field(ui, text, "").1;
                            }
                        });
                    }
                    Value::Bool(x) => {
                        changed |= ui_kit::checkbox(ui, crate::i18n::tr_label(field_label(key)), x).changed();
                    }
                    _ => {
                        ui_kit::row(ui, field_label(key), |ui| {
                            ui.label("Not specified");
                        });
                    }
                }
            }
        }
        Value::Array(values) => {
            for (i, v) in values.iter_mut().enumerate() {
                let path = format!("{id}.{i}");
                if let Value::String(text) = v {
                    ui_kit::row(ui, &format!("{}", i + 1), |ui| {
                        changed |= ui_kit::text_field(ui, text, "").1;
                    });
                } else {
                    ui_kit::section(ui, &path, &format!("{}", i + 1), depth < 2, |ui| {
                        changed |= properties(ui, &path, v, depth + 1, budget);
                    });
                }
                if *budget == 0 {
                    break;
                }
            }
        }
        Value::Number(n) => {
            changed |= number_input(ui, n);
        }
        _ => {
            ui.label(value.to_string());
        }
    }
    changed
}

fn choose<T: PartialEq>(ui: &mut egui::Ui, value: &mut T, next: T, label: &str) -> bool {
    if ui_kit::list_picker(ui, label, crate::i18n::tr_label(label), *value == next).clicked() && *value != next {
        *value = next;
        return true;
    }
    false
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum MccIntegration {
    Material,
    BackwardEuler,
    Midpoint,
    Unsupported,
}

impl MccIntegration {
    fn read(stages: &Value) -> Self {
        match stages.pointer("/settings/mcc_integration") {
            None | Some(Value::Null) => Self::Material,
            Some(Value::String(v)) if v == "backward_euler" => Self::BackwardEuler,
            Some(Value::String(v)) if v == "midpoint" => Self::Midpoint,
            _ => Self::Unsupported,
        }
    }

    fn label(self) -> &'static str {
        match self {
            Self::Material => "Use material settings",
            Self::BackwardEuler => "Backward Euler",
            Self::Midpoint => "Midpoint (second order)",
            Self::Unsupported => "Unsupported MCC integration",
        }
    }

    fn write(self, stages: &mut Value) -> bool {
        let Some(root) = stages.as_object_mut() else { return false };
        if self == Self::Material {
            return root.get_mut("settings").and_then(Value::as_object_mut).and_then(|settings| settings.remove("mcc_integration")).is_some();
        }
        let name = match self {
            Self::BackwardEuler => "backward_euler",
            Self::Midpoint => "midpoint",
            Self::Material | Self::Unsupported => return false,
        };
        let Some(settings) = root.entry("settings").or_insert_with(|| json!({})).as_object_mut() else { return false };
        let desired = json!(name);
        if settings.get("mcc_integration") == Some(&desired) {
            return false;
        }
        settings.insert("mcc_integration".into(), desired);
        true
    }
}

fn mcc_integration(ui: &mut egui::Ui, stages: &mut Value) -> bool {
    let mut selected = MccIntegration::read(stages);
    let previous = selected;
    ui_kit::row(ui, "MCC integration", |ui| {
        ui_kit::dropdown_menu(ui, "soil_mcc_integration", crate::i18n::tr_label(selected.label()), |ui| {
            choose(ui, &mut selected, MccIntegration::Material, MccIntegration::Material.label());
            choose(ui, &mut selected, MccIntegration::BackwardEuler, MccIntegration::BackwardEuler.label());
            choose(ui, &mut selected, MccIntegration::Midpoint, MccIntegration::Midpoint.label());
        });
    });
    previous != selected && selected.write(stages)
}

fn field_label(key: &str) -> &str {
    match key {
        "materials" => "Materials",
        "initialization" => "Initial ground state",
        "layers" => "Soil layers",
        "bodies" => "Soil bodies",
        "unit_weight_kn_m3" => "Unit weight (kN/m³)",
        "young_kpa" => "Young's modulus (kPa)",
        "poisson" => "Poisson ratio",
        "lambda" => "Compression slope λ",
        "kappa" => "Swelling slope κ",
        "critical_state_m" => "Critical-state M",
        "k0_x" => "K₀ in X",
        "k0_y" => "K₀ in Y",
        "void_ratio" => "Void ratio",
        "consolidation" => "Consolidation history",
        "water_level_m" => "Water elevation (m)",
        "surface_surcharge_kpa" => "Surface surcharge (kPa)",
        "body" => "Analysis body label",
        "material_id" => "Material ID",
        "excavation_bodies" => "Excavation tools",
        "stages" => "Construction stages",
        "name" => "Name",
        "kind" => "Stage type",
        _ => key,
    }
}

pub fn show(app: &mut SolveApp, ctx: &egui::Context) {
    let Some(mut d) = app.soil_analysis.take() else { return };
    #[cfg(not(target_arch = "wasm32"))]
    {
        if let Err(error) = d.jobs.poll(app) {
            d.error = Some(error);
        }
        ctx.request_repaint_after(std::time::Duration::from_millis(500));
    }
    if d.revision != app.session.revision {
        match soil_fem::inspect(&app.session) {
            Ok(v) => d.status = v,
            Err(e) => d.error = Some(e.to_string()),
        };
        d.revision = app.session.revision;
    }
    let mut reload = false;
    let mut review = false;
    #[cfg(not(target_arch = "wasm32"))]
    let mut export = false;
    let mut import = false;
    #[cfg(not(target_arch = "wasm32"))]
    let mut job_action = None;
    let valid = d.ground.is_some() && d.stages.is_some();
    let title = crate::i18n::tr_label("Soil Analysis");
    let (closed,action)=ui_kit::Window::new(egui::Id::new("sc_soil_analysis"),"settings",title)
        .cards(2.5).fields().keep_open_on_escape().actions("Save","Close",None).show(ctx,valid,|ui|{
            let mut page=usize::from(d.page); if ui_kit::segmented(ui,&mut page,&["Ground","Construction","CAD bodies","Analysis"],ui_kit::Segments::default()){d.page=page as u8;}
            ui_kit::text(ui,"Analysis units: m, kN, kPa. CAD geometry is exported in mm.",ui_kit::Text::Note("soil_units"));
            ui.horizontal(|ui|{
                import=ui_kit::button(ui,crate::i18n::tr_label("Load analysis inputs…"),ui_kit::Button::Normal).clicked();
                reload=ui_kit::button(ui,crate::i18n::tr_label("Reload from design"),ui_kit::Button::Normal).clicked();
            });
            if d.expected_cad!=d.status.get("cad_sha256").and_then(Value::as_str).unwrap_or_default() || d.status.get("cad_changed_since_review").and_then(Value::as_bool)==Some(true){
                ui_kit::text(ui,"CAD changed while this editor was open. Review every body assignment before saving.",ui_kit::Text::Report("soil_stale",true));
                review=ui_kit::button(ui,crate::i18n::tr_label("Review current CAD"),ui_kit::Button::Normal).clicked();
            }
            if let Some(issues)=d.status.get("issues").and_then(Value::as_array){for v in issues {if let Some(text)=v.as_str(){ui_kit::text(ui,text,ui_kit::Text::Report("soil_issue",true));}}}
            match d.page {
                0=>if let Some(v)=&mut d.ground {d.dirty|=properties(ui,"soil_ground",v,0,&mut 512);}else{ui.label("Load the ground-material and initial-state inputs to begin.");},
                1=>if let Some(v)=&mut d.stages {
                    let mut projected=v.get("schema").and_then(Value::as_str)==Some("soil-fem-projected-mcc-stages/1");
                    ui_kit::row(ui,"Continuum formulation",|ui|{ui_kit::dropdown_menu(ui,"soil_formulation",crate::i18n::tr_label(if projected{"MCC: Tet10 displacement + P1 pressure/volume"}else{"Displacement formulation"}),|ui|{let changed=choose(ui, &mut projected, false, "Displacement formulation")
                            | choose(ui, &mut projected, true, "MCC: Tet10 displacement + P1 pressure/volume");
                            if changed && let Some(object)=v.as_object_mut() {object.insert("schema".into(),json!(if projected{"soil-fem-projected-mcc-stages/1"}else{"soil-fem-stages/1"}));d.dirty=true;}});});
                    let has_mcc=d.ground.as_ref().and_then(|g|g.get("materials")).and_then(Value::as_array).is_some_and(|materials|materials.iter().any(|m|m.get("mcc").is_some_and(Value::is_object)));
                    if has_mcc || v.pointer("/settings/mcc_integration").is_some() {
                        d.dirty|=mcc_integration(ui,v);
                        ui_kit::text(ui,"This choice applies to all MCC materials. Refine construction increments separately from material integration.",ui_kit::Text::Note("soil_mcc_integration_scope"));
                    }
                    if projected {ui_kit::text(ui,"Dry MCC with Tet10 only. Material GP stress, primary pressure and work-conjugate stress remain distinct. Linear frames and plates are supported; water, anchors and contact need another formulation.",ui_kit::Text::Note("soil_projected_scope"));}
                    d.dirty|=properties(ui,"soil_stages",v,0,&mut 512);
                }else{ui.label("Load construction inputs to begin.");},
                2=>{
                    let names:Vec<String>=d.status.get("cad_bodies").and_then(Value::as_array).into_iter().flatten().filter_map(|v|v.get("cad_body").and_then(Value::as_str).map(str::to_string)).collect();
                    for (logical,cad) in &mut d.bindings {ui_kit::row(ui,logical,|ui|{
                        let selected=if cad.is_empty(){crate::i18n::tr_label("Choose CAD body").to_string()}else{cad.clone()}; ui_kit::dropdown_menu(ui,("soil_binding",logical),&selected,|ui|{
                            for name in &names {if ui_kit::list_picker(ui,name,name,cad==name).clicked() && cad!=name {*cad=name.clone();d.dirty=true;}}
                        });
                    });}
                    ui_kit::text(ui,"Body labels in the analysis stay separate from CAD names. Splits, missing producers and ambiguous outputs require explicit reassignment.",ui_kit::Text::Note("soil_binding_note"));
                },
                _=>{
                    #[cfg(not(target_arch="wasm32"))]
                    { job_action=d.jobs.show(ui,valid && !d.dirty && d.status.get("cad_changed_since_review").and_then(Value::as_bool)!=Some(true)
                        && d.expected_cad==d.status.get("cad_sha256").and_then(Value::as_str).unwrap_or_default()
                        && d.expected_setup==d.status.get("setup_sha256").and_then(Value::as_str).unwrap_or_default()
                        && d.status.get("issues").and_then(Value::as_array).is_some_and(|v|v.is_empty())); }
                    #[cfg(target_arch="wasm32")]
                    { ui.label("External FEM jobs require the native desktop application."); }
                },
            }
            #[cfg(not(target_arch="wasm32"))]
            {ui_kit::row(ui,"New capture folder",|ui|{ui_kit::text_field(ui,&mut d.output_directory,"");});
             let reviewed=d.status.get("cad_changed_since_review").and_then(Value::as_bool)!=Some(true)
                && d.expected_cad==d.status.get("cad_sha256").and_then(Value::as_str).unwrap_or_default()
                && d.expected_setup==d.status.get("setup_sha256").and_then(Value::as_str).unwrap_or_default()
                && d.status.get("issues").and_then(Value::as_array).is_some_and(|v|v.is_empty());
             export=ui_kit::button(ui,"Export analysis inputs…",ui_kit::Button::Enabled(valid && !d.dirty && reviewed && !d.output_directory.trim().is_empty())).clicked();}
            ui_kit::text(ui,"This editor saves attributes and exports an input capture. Meshing, engineering validation and solving are performed by the external FEM workflow.",ui_kit::Text::Note("soil_scope"));
            if let Some(text)=&d.notice {ui_kit::text(ui,text,ui_kit::Text::Note("soil_notice"));}
            if let Some(text)=&d.error {ui_kit::text(ui,text,ui_kit::Text::Report("soil_error",true));}
        });
    if closed || action == ui_kit::Action::Cancel {
        return;
    }
    if let (Some(ground), Some(stages)) = (&d.ground, &d.stages)
        && let Ok(names) = soil_fem::required_body_labels(ground, stages)
    {
        d.bindings = names
            .into_iter()
            .map(|name| {
                let cad = d.bindings.get(&name).cloned().unwrap_or_default();
                (name, cad)
            })
            .collect();
    }
    if reload {
        d = SoilAnalysis::new(app);
    }
    if review {
        if d.expected_setup == d.status.get("setup_sha256").and_then(Value::as_str).unwrap_or_default() {
            d.expected_cad = d.status.get("cad_sha256").and_then(Value::as_str).unwrap_or_default().to_string();
            d.dirty = true;
            d.error = None;
        } else {
            d.error = Some("Saved analysis attributes also changed. Reload before editing.".into());
        }
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        if let Some(action) = job_action {
            match d.jobs.act(app, action) {
                Ok(()) => {
                    d.error = None;
                    if action == "view_results" {
                        return;
                    }
                }
                Err(error) => d.error = Some(error),
            }
        }
        if export {
            d.export(app);
        }
    }
    if action == ui_kit::Action::Ok {
        d.save(app);
    }
    app.soil_analysis = Some(d);
    if import {
        start_import(app);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scenario::Harness;
    #[test]
    fn mcc_integration_editor_preserves_defaults_and_rejects_malformed_settings() {
        let original = json!({"settings":{"kinematics":"explicit","initial_increment":0.0625},"stages":[]});
        let mut value = original.clone();
        assert_eq!(MccIntegration::read(&value), MccIntegration::Material);
        assert!(!MccIntegration::Material.write(&mut value));
        assert_eq!(value, original);
        assert!(MccIntegration::Midpoint.write(&mut value));
        assert_eq!(MccIntegration::read(&value), MccIntegration::Midpoint);
        assert!(!MccIntegration::Midpoint.write(&mut value));
        assert!(MccIntegration::BackwardEuler.write(&mut value));
        assert_eq!(MccIntegration::read(&value), MccIntegration::BackwardEuler);
        assert!(MccIntegration::Material.write(&mut value));
        assert_eq!(value, original);
        let unknown = json!({"settings":{"mcc_integration":"future"}});
        assert_eq!(MccIntegration::read(&unknown), MccIntegration::Unsupported);
        for mut invalid in [Value::Null, json!([]), json!({"settings":null}), json!({"settings":[]})] {
            let before = invalid.clone();
            assert!(!MccIntegration::Midpoint.write(&mut invalid));
            assert_eq!(invalid, before);
        }
    }

    #[test]
    fn mcc_integration_picker_saves_only_on_command_and_undo_restores_the_input() {
        for (language, label, choice) in [
            ("en", "MCC integration", "Midpoint (second order)"),
            ("ja", "MCC積分法", "中点法（二次精度）"),
            ("zh", "MCC 积分方法", "中点法（二阶精度）"),
        ] {
            let mut h = configured();
            h.app.preferences.language = language.into();
            let translated = |text: &str| {
                let _language = crate::i18n::scope(language);
                crate::i18n::tr_label(text).to_string()
            };
            let save = translated("Save");
            let close = translated("Close");
            let material = translated("Use material settings");
            h.step(&json!({"start":"analysis.soil.model"})).unwrap();
            {
                let draft = h.app.soil_analysis.as_mut().unwrap();
                draft.ground.as_mut().unwrap()["materials"] = json!([{"id":1,"mcc":{}}]);
                draft.stages.as_mut().unwrap()["settings"] = json!({"kinematics":"side_rollers"});
            }
            h.frames(2);
            h.step(&json!({"widget":save})).unwrap();
            assert!(h.app.soil_analysis.as_ref().unwrap().error.is_none());
            let before = h.app.run("analysis.soil.snapshot", json!({})).unwrap();
            let undo = h.app.session.undo.len();
            // Segmented controls currently paint their raw option labels (see i18n's guard).
            h.step(&json!({"widget":"Construction"})).unwrap();
            assert!(h.widget(label).is_some(), "the MCC field label must be translated in {language}");
            h.step(&json!({"widget":material})).unwrap();
            assert!(h.widget(choice).is_some(), "the MCC choice must be translated in {language}");
            h.step(&json!({"widget":choice})).unwrap();
            assert_eq!(h.app.soil_analysis.as_ref().unwrap().stages.as_ref().unwrap()["settings"]["mcc_integration"], "midpoint");
            assert_eq!(h.app.run("analysis.soil.snapshot", json!({})).unwrap(), before);
            h.frames(2);
            h.step(&json!({"widget":save})).unwrap();
            assert!(h.app.soil_analysis.as_ref().unwrap().error.is_none());
            assert_eq!(h.app.session.undo.len(), undo + 1);
            let saved = h.app.run("analysis.soil.snapshot", json!({})).unwrap();
            assert_ne!(saved["input_sha256"], before["input_sha256"]);
            assert_eq!(saved["snapshot"]["stages"]["settings"]["mcc_integration"], "midpoint");
            h.step(&json!({"widget":close})).unwrap();
            h.step(&json!({"start":"analysis.soil.model"})).unwrap();
            assert_eq!(MccIntegration::read(h.app.soil_analysis.as_ref().unwrap().stages.as_ref().unwrap()), MccIntegration::Midpoint);
            h.step(&json!({"widget":close})).unwrap();
            h.app.run("edit.undo", json!({})).unwrap();
            assert_eq!(h.app.run("analysis.soil.snapshot", json!({})).unwrap(), before);
        }
    }

    #[test]
    fn kit_numeric_display_preserves_exact_ids_and_small_material_values() {
        for original in [json!(u64::MAX), json!(i64::MIN), json!(1.25e-12), json!(5.125e12)] {
            let mut number = original.as_number().unwrap().clone();
            let ctx = crate::fonts::test_context();
            let output = ctx.run_ui(egui::RawInput::default(), |ui| {
                ui_kit::row(ui, "Value", |ui| {
                    assert!(!number_input(ui, &mut number));
                });
            });
            assert_eq!(Value::Number(number), original);
            if original == json!(1.25e-12) {
                assert!(
                    output.shapes.iter().any(|shape| match &shape.shape {
                        egui::Shape::Text(text) => text.galley.job.text.contains("1.250e-12"),
                        _ => false,
                    }),
                    "small values must remain visible in scientific notation"
                );
            }
        }
    }
    fn configured() -> Harness {
        let mut h = Harness::new();
        h.app.run("solid.box", json!({"length":10000,"width":10000,"height":4000})).unwrap();
        let body = h.app.session.model.state().bodies.first().unwrap().name.clone();
        let status = soil_fem::inspect(&h.app.session).unwrap();
        h.app
            .run(
                "analysis.soil.configure",
                json!({
            "ground":{"schema":"soil-fem-ground/1","units":"m-kN-kPa","initialization":{"method":"equilibrate"},
                "materials":[{"id":1,"name":"Clay material","mohr_coulomb":{"young_kpa":100000.0}}],"bodies":[{"body":"Clay","material_id":1}]},
            "stages":{"schema":"soil-fem-stages/1","stages":[]},"bindings":[{"analysis_body":"Clay","cad_body":body}],
            "expected_cad_sha256":status["cad_sha256"],"expected_setup_sha256":status["setup_sha256"]}),
            )
            .unwrap();
        h
    }
    #[test]
    fn editor_save_uses_one_engine_undo_step_and_close_discards_only_the_draft() {
        let mut h = configured();
        let undo = h.app.session.undo.len();
        h.step(&json!({"start":"analysis.soil.model"})).unwrap();
        assert!(h.app.soil_analysis.is_some());
        let draft = h.app.soil_analysis.as_mut().unwrap();
        draft.ground.as_mut().unwrap()["materials"][0]["mohr_coulomb"]["young_kpa"] = json!(120000.0);
        h.frames(2);
        h.step(&json!({"widget":"Save"})).unwrap();
        assert!(h.app.soil_analysis.as_ref().unwrap().error.is_none());
        assert_eq!(h.app.session.undo.len(), undo + 1);
        assert_eq!(h.app.session.doc.metadata.get(soil_fem::KEY).unwrap()["ground"]["materials"][0]["mohr_coulomb"]["young_kpa"], 120000.0);
        h.app.soil_analysis.as_mut().unwrap().ground.as_mut().unwrap()["materials"][0]["name"] = json!("discarded");
        h.frames(2);
        h.step(&json!({"widget":"Close"})).unwrap();
        assert!(h.app.soil_analysis.is_none());
        assert_eq!(h.app.session.doc.metadata.get(soil_fem::KEY).unwrap()["ground"]["materials"][0]["name"], "Clay material");
        h.app.run("edit.undo", json!({})).unwrap();
        assert_eq!(h.app.session.doc.metadata.get(soil_fem::KEY).unwrap()["ground"]["materials"][0]["mohr_coulomb"]["young_kpa"], 100000.0);
    }
    #[test]
    fn changed_cad_cannot_be_silently_saved_from_an_open_editor() {
        let mut h = configured();
        h.step(&json!({"start":"analysis.soil.configure"})).unwrap();
        h.app.run("solid.box", json!({"corner":[20000,0,0],"length":1000,"width":1000,"height":1000,"operation":"new"})).unwrap();
        let doc = h.app.session.doc.to_json();
        let undo = h.app.session.undo.len();
        h.frames(2);
        h.step(&json!({"widget":"Save"})).unwrap();
        assert!(h.app.soil_analysis.as_ref().unwrap().error.as_deref().is_some_and(|e| e.contains("changed")));
        assert_eq!(h.app.session.doc.to_json(), doc);
        assert_eq!(h.app.session.undo.len(), undo);
        h.step(&json!({"widget":"Reload from design"})).unwrap();
        assert!(h.app.soil_analysis.as_ref().unwrap().status["cad_changed_since_review"].as_bool().unwrap());
        h.frames(2);
        h.step(&json!({"widget":"Save"})).unwrap();
        assert!(h.app.soil_analysis.as_ref().unwrap().error.is_none());
        assert!(h.app.run("analysis.soil.snapshot", json!({})).is_ok());
    }

    #[test]
    fn input_pickers_return_to_the_event_loop_and_only_save_changes_the_design() {
        use std::cell::RefCell;
        use std::rc::Rc;
        let mut h = Harness::new();
        h.app.run("solid.box", json!({"length":1000,"width":1000,"height":1000,"body_name":"Clay"})).unwrap();
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/soil-editor-input-tests");
        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let folder = root.join(format!("{}-{nonce}", std::process::id()));
        std::fs::create_dir_all(&folder).unwrap();
        std::fs::write(
            folder.join("ground.json"),
            json!({"schema":"soil-fem-ground/1","units":"m-kN-kPa","initialization":{"method":"equilibrate"},
            "materials":[{"id":1}],"bodies":[{"body":"Clay","material_id":1}]})
            .to_string(),
        )
        .unwrap();
        std::fs::write(folder.join("stages.json"), json!({"schema":"soil-fem-stages/1","stages":[]}).to_string()).unwrap();
        let paths = Rc::new(RefCell::new(std::collections::VecDeque::from([
            folder.join("ground.json").to_string_lossy().into_owned(),
            folder.join("stages.json").to_string_lossy().into_owned(),
        ])));
        h.app.services.pick_file = Some(Box::new(move |_, _| {
            let path = paths.borrow_mut().pop_front();
            Box::pin(async move { path })
        }));
        h.step(&json!({"start":"analysis.soil.model"})).unwrap();
        h.step(&json!({"widget":"Load analysis inputs…"})).unwrap();
        h.frames(4);
        assert!(h.app.session.doc.metadata.get(soil_fem::KEY).is_none());
        assert_eq!(h.app.soil_analysis.as_ref().unwrap().bindings.get("Clay").map(String::as_str), Some("Clay"));
        h.step(&json!({"widget":"Save"})).unwrap();
        assert!(h.app.soil_analysis.as_ref().unwrap().error.is_none());
        assert!(h.app.session.doc.metadata.get(soil_fem::KEY).is_some());
    }
}
