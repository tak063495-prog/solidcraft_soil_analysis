#[allow(dead_code)]
mod linalg;
use linalg::{CsrMatrix,CsrPattern};
use std::{hint::black_box,time::Instant};

fn main() -> Result<(),Box<dyn std::error::Error>> {
    let pattern=CsrPattern::from_connectivity(512,(0..15).map(|i|(32*i..32*i+38).collect()))?;
    let theta:Vec<_>=(160..164).collect();let u:Vec<_>=(164..194).collect();let p:Vec<_>=(194..198).collect();
    let mut pairs=Vec::new();
    for &i in &theta {for &j in &theta {pairs.push((i,j));}}
    for &i in &u {
        for &t in &theta {pairs.push((i,t));pairs.push((t,i));}
        for &j in &u {pairs.push((i,j));}
        for &j in &p {pairs.push((i,j));pairs.push((j,i));}
    }
    for &i in &p {for &t in &theta {pairs.push((t,i));pairs.push((i,t));}}
    assert_eq!(pairs.len(),1428);
    let values:Vec<_>=(0..pairs.len()).map(|i|((i%17) as f64-8.)*1e-4).collect();
    let begin=Instant::now();let plan=pattern.compile_assembly(&pairs)?;let preparation=begin.elapsed().as_secs_f64();
    let mut samples=Vec::new();
    for round in 0..6 {
        let repetitions=if round==0 {100} else {10000};
        let mut a=CsrMatrix::zeros(pattern.clone());let mut b=CsrMatrix::zeros(pattern.clone());
        let mut times=[0.;2];
        let order=if round%2==0 {[0,1]} else {[1,0]};
        for kind in order {
            let begin=Instant::now();
            for _ in 0..repetitions {
                if kind==0 {
                    for (&(r,c),&value) in pairs.iter().zip(&values) {a.add(r,c,black_box(value))?;}
                } else {
                    let mut cursor=b.assembly_cursor(&plan)?;
                    for (&(r,c),&value) in pairs.iter().zip(&values) {cursor.add(r,c,black_box(value))?;}
                    cursor.finish()?;
                }
            }
            times[kind]=begin.elapsed().as_secs_f64();
        }
        assert_eq!(black_box(a.values()),black_box(b.values()));
        if round>0 {samples.push(serde_json::json!({"repetitions":repetitions,"contributions_per_repetition":pairs.len(),"original_seconds":times[0],"cached_seconds":times[1],"all_matrix_values_bit_exact":true,"original_to_cached_elapsed_ratio":times[0]/times[1]}));}
    }
    let output=serde_json::json!({"passed":true,"scope":"CSR lookup-only synthetic microbenchmark; not an actual FEM or constitutive performance acceptance","candidate_linalg_source_used_unmodified":true,"pattern_dimension":pattern.dimension(),"pattern_nonzeros":pattern.nonzeros(),"plan_compilation_seconds":preparation,"nominal_plan_offsets_bytes":pairs.len()*size_of::<usize>(),"concurrent_other_jobs":true,"isolated_throughput_benchmark":false,"samples":samples,"p6_complete":false});
    std::fs::write("measurements.json",serde_json::to_vec_pretty(&output)?)?;
    println!("{}",output);
    Ok(())
}
