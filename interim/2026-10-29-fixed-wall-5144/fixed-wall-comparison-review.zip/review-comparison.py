from pathlib import Path
import hashlib,json,os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
import numpy as np
from scipy.spatial import cKDTree
import sys
p=Path(__file__).resolve().parent
read=lambda q:json.loads(q.read_text('utf-8-sig'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
metadata=read(p/'metadata.json')
assert all(sha(p/n)==h for n,h in metadata['files_sha256'].items())
sys.path.insert(0,str(p/'geometry-tools'))
from tet10_overlap import Overlay
meshes=[read(p/('mesh'+str(n))/'ground/mesh.json') for n in [2865,5144]]
results=[read(p/('mesh'+str(n))/'comparison-fields.json') for n in [2865,5144]]
assert all(r['schema']=='soil-fem-fixed-wall-comparison-fields/1' and not r['full_gp_material_histories_included'] for r in results)
recorded=read(p/'comparison-recorded.json')
for c,r in zip(metadata['cases'],results):assert c['original_full_result_sha256']==r['source_full_result_sha256']
configs=[r['case']['beam_system'] for r in results]
xyz=[np.asarray([n['position_m'] for n in cfg['nodes']]) for cfg in configs]
distance,node_map=cKDTree(xyz[1]).query(xyz[0]);assert distance.max()==0 and len(set(node_map))==len(xyz[0])==440
def plate_keys(cfg):
 nodes={n['id']:tuple(n['position_m']) for n in cfg['nodes']}
 answer={}
 for plate in cfg['plates']:
  corners=[nodes[n] for n in plate['nodes']]
  key=min(tuple(corners[k:]+corners[:k]) for k in range(3))
  assert key not in answer;answer[key]=plate
 return answer
keyed=[plate_keys(c) for c in configs];assert set(keyed[0])==set(keyed[1]) and len(keyed[0])==832
def metric(a,b,w):
 a,b=np.asarray(a),np.asarray(b);w=np.asarray(w);assert a.shape==b.shape and len(w)==len(a)
 d=(a-b).reshape(len(a),-1);v=b.reshape(len(b),-1)
 dn=float(np.sqrt(np.sum(w[:,None]*d*d)));vn=float(np.sqrt(np.sum(w[:,None]*v*v)))
 return dict(relative_l2=dn/vn if vn>1e-20 else None,weighted_rms_difference=dn/float(np.sqrt(w.sum())),maximum_absolute_difference=float(abs(d).max()),reference_l2=vn)
def tensor(values,axes):
 nxx,nyy,nxy=values;axes=np.asarray(axes);assert np.max(abs(axes@axes.T-np.eye(3)))<1e-12
 return axes[:2].T@np.asarray([[nxx,nxy],[nxy,nyy]])@axes[:2]
# Independent closed-form Frobenius and rotated-axis checks for the comparison operator.
angle=.37;c,s=np.cos(angle),np.sin(angle);axes=np.asarray([[c,s,0],[-s,c,0],[0,0,1]])
value=tensor([2,3,4],axes);assert abs(float(np.sum(value*value))-(2**2+3**2+2*4**2))<1e-12
assert abs(metric([[1.,2.]],[[2.,4.]],[3.])['relative_l2']-.5)<1e-14
overlay=Overlay(*meshes,progress=lambda e,n,pairs:print(f'Overlay {e}/{n}, intersections {pairs}',flush=True))
origins=[np.asarray(r['reference_displacement_m']) for r in results]
previous=[np.zeros_like(v) for v in origins];rows=[]
for fa,fb in zip(results[0]['frames'],results[1]['frames'],strict=True):
 assert fa['name']==fb['name'];a,b=fa['state'],fb['state'];u,v=np.asarray(a['displacement_m']),np.asarray(b['displacement_m'])
 active_a,active_b=a['active_elements'],b['active_elements']
 row=dict(stage=fa['name'],from_seed=overlay.compare(u,v,active_a,active_b),from_construction_origin=overlay.compare(u-origins[0],v-origins[1],active_a,active_b),stage_increment=overlay.compare(u-previous[0],v-previous[1],active_a,active_b))
 ba,bb=a['beams'],b['beams'];assert not any(ba['active_members']) and not any(bb['active_members'])
 row['wall_node_coefficients']={k:metric(ba[k],np.asarray(bb[k])[node_map],np.ones(440)) for k in ['node_displacement_m','node_rotation_rad']}
 plate_results=[{r['id']:r for r in frame['beam_results'].get('plates',[])} for frame in [fa,fb]]
 assert all(len(pr)==sum(state['beams']['active_plates']) for pr,state in zip(plate_results,[a,b]))
 samples={k:([],[],[]) for k in ['membrane_force_kn_m','bending_moment_kn']}
 for key in sorted(keyed[0]):
  pa,pb=[keyed[i][key] for i in [0,1]];ra=plate_results[0].get(pa['id']);rb=plate_results[1].get(pb['id'])
  assert (ra is None)==(rb is None)
  if ra is None:continue
  assert abs(ra['area_m2']-rb['area_m2'])<1e-13
  coords=[]
  for cfg,plate,res in [(configs[0],pa,ra),(configs[1],pb,rb)]:
   nodes={n['id']:np.asarray(n['position_m']) for n in cfg['nodes']};tri=np.asarray([nodes[n] for n in plate['nodes']])
   coords.append(np.asarray([np.asarray(s['barycentric'])@tri for s in res['samples']]))
  dist,mapping=cKDTree(coords[1]).query(coords[0]);assert dist.max()<1e-12 and len(set(mapping))==len(coords[0])==3
  assert np.dot(ra['local_axes'][2],rb['local_axes'][2])>1-1e-12
  for i,j in enumerate(mapping):
   for name,(x,y,w) in samples.items():
    x.append(tensor(ra['samples'][i][name],ra['local_axes']));y.append(tensor(rb['samples'][j][name],rb['local_axes']));w.append(ra['area_m2']/3)
 row['wall_area_weighted_global_tensors']={k:metric(x,y,w) for k,(x,y,w) in samples.items() if x}
 rows.append(row);previous=[u,v]
assert rows==recorded['frames'], 'comparison replay changed'
assert overlay.metadata==recorded['geometry']
q=p/'comparison-recomputed.json'
with q.open('x',encoding='utf-8') as f:json.dump(dict(passed=True,all5_nodal_and_wall_comparison_rows_exact=True,geometry_metadata_exact=True,full_gp_histories_not_revalidated_by_subset=True,original_full_gp_audits_recorded_separately=True,frames=rows,geometry=overlay.metadata,spatial_convergence_accepted=False,p6_complete=False),f,indent=2)
print('PASS exact5-frame nodal/wall comparison replay; full GP histories require the complete FEM results')
