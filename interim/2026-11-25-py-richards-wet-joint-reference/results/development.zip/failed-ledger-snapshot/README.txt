Development evidence before extended-precision state storage. First ledger audit rejected space-linear-16 at two initial times. Not the final result. Original C-04 files were never changed.
