import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import source_point_descriptor as points

class SourcePointDescriptorTests(unittest.TestCase):
 def fixture(self):
  return dict(schema='soil-fem-projected-mcc-stage-result/2',complete=True,failure_reason=None,
    integration_points=[{'element_index':0},{'element_index':1},{'element_index':0}],
    frames=[dict(name='excavate',state=dict(active_elements=[True,False],material_states=[{}, {}, {}]))])
 def test_exact_source_count_active_mask_frame_units_and_components(self):
  run=self.fixture();descriptor=points.make(run,0,'a'*64)
  self.assertEqual(descriptor,dict(schema='soil-fem-view-source-points/1',
    source_result_schema='soil-fem-projected-mcc-stage-result/2',source_result_sha256='a'*64,
    frame_index=0,frame_name='excavate',integration_point_count=3,active_integration_point_count=2,
    length_unit='m',stress_unit='kPa',stress_sign='compression_positive',stress_components=['xx','yy','zz','xy','yz','xz']))
  self.assertNotIn('fields',descriptor);self.assertNotIn('positions_m',descriptor)
  points.validate(descriptor,run,0,'a'*64)
 def test_each_binding_and_semantic_tamper_is_rejected(self):
  run=self.fixture();base=points.make(run,0,'a'*64)
  for key,value in [('source_result_sha256','b'*64),('frame_index',True),('frame_name','preload'),
    ('integration_point_count',2),('active_integration_point_count',3),('length_unit','mm'),
    ('stress_unit','Pa'),('stress_sign','tension_positive'),('stress_components',['zz','yy','xx','xy','yz','xz']),
    ('schema','soil-fem-view-points/1'),('unexpected','value')]:
   descriptor=copy.deepcopy(base);descriptor[key]=value
   with self.subTest(key=key),self.assertRaises(ValueError):points.validate(descriptor,run,0,'a'*64)
 def test_incomplete_wrong_family_invalid_hash_and_frame_are_rejected(self):
  for key,value in [('complete',False),('failure_reason','not converged'),('schema','soil-fem-stage-result/2')]:
   run=self.fixture();run[key]=value
   with self.assertRaises(ValueError):points.make(run,0,'a'*64)
  for index in [-1,1,True]:
   with self.assertRaises(ValueError):points.make(self.fixture(),index,'a'*64)
  for digest in ['a'*63,'A'*64,'../result.json']:
   with self.assertRaises(ValueError):points.make(self.fixture(),0,digest)
 def test_invalid_inventory_owner_and_empty_domain_are_rejected(self):
  run=self.fixture();run['frames'][0]['state']['material_states'].pop()
  with self.assertRaises(ValueError):points.make(run,0,'a'*64)
  for owner in [-1,2,True]:
   run=self.fixture();run['integration_points'][0]['element_index']=owner
   with self.assertRaises(ValueError):points.make(run,0,'a'*64)
  run=self.fixture();run['frames'][0]['state']['active_elements']=[False,False]
  with self.assertRaises(ValueError):points.make(run,0,'a'*64)

if __name__=='__main__':unittest.main()
