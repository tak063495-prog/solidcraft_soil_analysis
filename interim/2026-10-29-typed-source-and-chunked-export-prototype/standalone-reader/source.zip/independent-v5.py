"""Independent event-parser comparison of all raw MCC GP/layout values, not physics."""
from pathlib import Path
import hashlib,json,struct,sys,time
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'deps'))
import ijson
from ijson.common import ObjectBuilder
read=lambda q:json.loads(q.read_text('utf-8'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source=p.parent/'mcc-next-fixed-wall-durable-pair-20261029-v1/mesh8061/workflow/analysis/stage-results.json'
expected=next(v for k,v in read(p.parent/'mcc-next-fixed-wall-durable-pair-20261029-v1/mesh8061/field-verification.json')['sha256'].items() if k.endswith('analysis\\stage-results.json'))
assert sha(source)==expected
start=time.monotonic();root=p/'real8061-v4'
reports=[read(root/f'frame{i}.json') for i in range(5)]
assert all(r['passed'] and r['source_sha256']==expected and r['points']==217647 for r in reports)
material_hashes=[hashlib.sha256() for _ in range(5)];counts=[0]*5
layout_hash=hashlib.sha256();layout_count=0;frame=-1
frame_builder=point_builder=state_builder=case_builder=None
rows=[];case=None
states_prefix='frames.item.state.material_states'
state_keys={'effective_stress_compression_positive_kpa','void_ratio','preconsolidation_pressure_kpa','plastic_strain_compression_positive'}
with source.open('rb') as handle:
 for prefix,event,value in ijson.parse(handle,use_float=True):
  if prefix=='case' and event=='start_map':case_builder=ObjectBuilder()
  if case_builder is not None and (prefix=='case' or prefix.startswith('case.')):
   case_builder.event(event,value)
   if prefix=='case' and event=='end_map':case=case_builder.value;case_builder=None
  if prefix=='frames.item' and event=='start_map':
   frame+=1;assert frame<5;frame_builder=ObjectBuilder()
  if frame_builder is not None:
   if not (prefix==states_prefix or prefix.startswith(states_prefix+'.') or
           prefix=='frames.item.state' and event=='map_key' and value=='material_states'):
    frame_builder.event(event,value)
   if prefix=='frames.item' and event=='end_map':
    retained=read(root/f'frame{frame}.retained.json')
    assert frame_builder.value==retained['frames'][frame],('selected frame differs',frame)
    assert retained['case']==case and retained['complete'] is True
    if frame>0:
     prior=read(root/f'frame{frame-1}.retained.json')['frames'][frame-1]['state']['displacement_m']
     assert retained['frames'][frame-1]['state']['displacement_m']==prior
    rows.append(dict(frame=frame,all_other_selected_frame_fields_equal=True,previous_displacement_equal=True,case_equal=True))
    frame_builder=None
  if prefix==states_prefix+'.item' and event=='start_map':state_builder=ObjectBuilder()
  if state_builder is not None and (prefix==states_prefix+'.item' or prefix.startswith(states_prefix+'.item.')):
   state_builder.event(event,value)
   if prefix==states_prefix+'.item' and event=='end_map':
    s=state_builder.value;assert set(s)==state_keys
    values=[*s['effective_stress_compression_positive_kpa'],s['void_ratio'],s['preconsolidation_pressure_kpa'],*s['plastic_strain_compression_positive']]
    assert len(values)==14
    material_hashes[frame].update(struct.pack('<14d',*values));counts[frame]+=1;state_builder=None
  if prefix=='integration_points.item' and event=='start_map':point_builder=ObjectBuilder()
  if point_builder is not None and (prefix=='integration_points.item' or prefix.startswith('integration_points.item.')):
   point_builder.event(event,value)
   if prefix=='integration_points.item' and event=='end_map':
    q=point_builder.value;assert set(q)=={'element_index','local_index','natural_coordinates','position_m','weight_m3','shape_functions'}
    layout_hash.update(struct.pack('<QQ17d',q['element_index'],q['local_index'],*q['natural_coordinates'],*q['position_m'],q['weight_m3'],*q['shape_functions']))
    layout_count+=1;point_builder=None
assert frame==4 and len(rows)==5 and layout_count==217647 and counts==[217647]*5
for i,r in enumerate(reports):
 assert r['material_f64_le_sha256']==material_hashes[i].hexdigest(),('all GP f64 mismatch',i)
 assert r['layout_u64_f64_le_sha256']==layout_hash.hexdigest(),('all layout mismatch',i)
assert sha(source)==expected
wheel=next((p/'wheels').glob('*.whl'))
v=dict(passed=True,source_sha256=expected,source_bytes=source.stat().st_size,
 frames=rows,all5_material_states_per_frame=counts,all5_scalar_values_compared=sum(counts)*14,
 all_layout_entries=layout_count,all_material_and_layout_IEEE754_little_endian_digests_equal=True,
 includes_frozen_removed_point_histories=True,independent_parser='ijson',independent_parser_version=ijson.__version__,
 independent_backend=ijson.backend,dependency_wheel_sha256=sha(wheel),dependency_location_isolated_from_Root_venv=True,
 original_source_unchanged=True,elapsed_seconds=time.monotonic()-start,
 this_checks_decoding_not_constitutive_accuracy=True,full_Native_integration_and_GUI_pending=True,p6_complete=False)
with (p/'independent-verification-v5.json').open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
print(json.dumps(v),flush=True)
