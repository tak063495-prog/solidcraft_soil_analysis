"""Run bounded parser gates and real1.46GB reads; do not alter production source."""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,subprocess,sys,time
from ctypes import wintypes
p=Path(__file__).resolve().parent;root=p.parents[1];reader=p/'reader-v4'
read=lambda q:json.loads(q.read_text('utf-8'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def dump(q,v):
 with q.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
dump(p/'driver-v5-child.json',dict(pid=os.getpid(),executable=sys._base_executable,script=str(Path(__file__).resolve()),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
files=[*reader.glob('Cargo.*'),*reader.glob('src/*.rs'),p/'independent-v5.py',p/'run-v5.py']
binding={str(q.relative_to(p)):sha(q) for q in files}
dump(p/'source-binding-v5.json',binding)
class Memory(ctypes.Structure):
 _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
getmem=ctypes.WinDLL('psapi',use_last_error=True).GetProcessMemoryInfo
getmem.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD];getmem.restype=wintypes.BOOL
def peak(child):
 m=Memory();m.cb=ctypes.sizeof(m)
 return int(m.PeakWorkingSetSize) if getmem(wintypes.HANDLE(int(child._handle)),ctypes.byref(m),m.cb) else 0
records=[]
def check():
 assert all(sha(p/name)==h for name,h in binding.items())
 if (p/'pause-requested').exists():raise SystemExit(2)
def call(label,command):
 check();start=time.monotonic();maximum=0
 with (p/('v5-'+label+'.log')).open('x',encoding='utf-8') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  dump(p/('v5-'+label+'-child.json'),dict(pid=child.pid,parent_pid=os.getpid(),executable=command[0],arguments=command[1:],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  while child.poll() is None:maximum=max(maximum,peak(child));time.sleep(.25)
  maximum=max(maximum,peak(child));code=child.wait()
 check();row=dict(step=label,exit_code=code,elapsed_seconds=time.monotonic()-start,observed_peak_working_set_bytes=maximum,source_unchanged=True)
 dump(p/('v5-'+label+'-terminal.json'),row);records.append(row);print(json.dumps(row),flush=True);assert code==0
 return row
cargo='C:/Users/link_/.cargo/bin/cargo.exe';manifest=str(reader/'Cargo.toml')
call('format',[cargo,'fmt','--manifest-path',manifest,'--','--check'])
call('tests',[cargo,'test','--offline','--locked','--manifest-path',manifest])
call('clippy',[cargo,'clippy','--offline','--locked','--manifest-path',manifest,'--all-targets','--','-D','warnings'])
call('release-build',[cargo,'build','--offline','--locked','--release','--manifest-path',manifest])
binary=reader/'target/release/soil-typed-source-probe.exe';binary_sha=sha(binary)
source=p.parent/'mcc-next-fixed-wall-durable-pair-20261029-v1/mesh8061/workflow/analysis/stage-results.json'
expected=next(v for k,v in read(p.parent/'mcc-next-fixed-wall-durable-pair-20261029-v1/mesh8061/field-verification.json')['sha256'].items() if k.endswith('analysis\\stage-results.json'))
assert sha(source)==expected
out=p/'real8061-v4';out.mkdir()
for frame in range(5):
 assert sha(binary)==binary_sha
 row=call('real8061-frame'+str(frame),[str(binary),str(source),str(frame),expected,str(out/f'frame{frame}.json')])
 assert row['observed_peak_working_set_bytes']>0 and row['observed_peak_working_set_bytes']<512<<20
call('independent',[sys.executable,'-X','utf8',str(p/'independent-v5.py')])
assert read(p/'independent-verification-v5.json')['passed'] and sha(source)==expected
dump(p/'terminal-v5.json',dict(passed=True,records=records,source_files_unchanged=True,binary_sha256=binary_sha,
 real_source_bytes=source.stat().st_size,real_all5_frames_and_all_GP_layout_independent_match=True,
 each_native_probe_observed_peak_below512MiB=True,existing_production_Native_cap_and_sources_unchanged=True,
 production_integration_not_yet_implemented=True,p6_complete=False))
print('PASS typed MCC standalone read all5 from1.46GB; full Native integration remains pending',flush=True)
