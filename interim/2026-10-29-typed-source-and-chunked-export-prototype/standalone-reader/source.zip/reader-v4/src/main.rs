mod source;

use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::PathBuf;

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    let [input, frame, expected, output]: [_; 4] = args
        .try_into()
        .map_err(|_| "usage: probe SOURCE FRAME EXPECTED_SHA256 REPORT")?;
    let input = PathBuf::from(input);
    let output = PathBuf::from(output);
    let frame: usize = frame.to_str().ok_or("frame is not UTF8")?.parse()?;
    let expected = expected.to_str().ok_or("digest is not UTF8")?;
    if expected.len() != 64 || !expected.bytes().all(|c| c.is_ascii_hexdigit()) {
        return Err("invalid expected digest".into());
    }
    // The standalone experiment may read 2GiB while independently retaining at
    // most512MiB. The production Native1GiB limit is unchanged.
    let source_limit = 2usize << 30;
    if input.metadata()?.len() > source_limit as u64 {
        return Err("source exceeds experimental2GiB input budget".into());
    }
    let selected = source::selected(File::open(&input)?, frame, source_limit, 512 << 20)?;
    if selected.digest != expected {
        return Err("complete authoritative source digest mismatch".into());
    }
    let mut material_hash = Sha256::new();
    for s in &selected.states {
        for v in s.effective_stress_compression_positive_kpa {
            material_hash.update(v.to_le_bytes());
        }
        material_hash.update(s.void_ratio.to_le_bytes());
        material_hash.update(s.preconsolidation_pressure_kpa.to_le_bytes());
        for v in s.plastic_strain_compression_positive {
            material_hash.update(v.to_le_bytes());
        }
    }
    let mut layout_hash = Sha256::new();
    for point in &selected.points {
        layout_hash.update(u64::try_from(point.element_index)?.to_le_bytes());
        layout_hash.update(u64::try_from(point.local_index)?.to_le_bytes());
        for v in point.natural_coordinates {
            layout_hash.update(v.to_le_bytes());
        }
        for v in point.position_m {
            layout_hash.update(v.to_le_bytes());
        }
        layout_hash.update(point.weight_m3.to_le_bytes());
        for v in point.shape_functions {
            layout_hash.update(v.to_le_bytes());
        }
    }
    let state_name = selected
        .value
        .pointer(&format!("/frames/{frame}/name"))
        .and_then(serde_json::Value::as_str)
        .ok_or("frame name missing")?;
    let retained_path = output.with_extension("retained.json");
    let mut file = BufWriter::new(
        File::options()
            .write(true)
            .create_new(true)
            .open(&retained_path)?,
    );
    serde_json::to_writer(&mut file, &selected.value)?;
    file.flush()?;
    let report = serde_json::json!({
        "passed":true,"prototype_only":true,"production_Native_not_changed":true,
        "source_sha256":selected.digest,"source_bytes":input.metadata()?.len(),"frame":frame,"name":state_name,
        "points":selected.points.len(),"material_states":selected.states.len(),
        "material_f64_le_sha256":format!("{:x}",material_hash.finalize()),
        "layout_u64_f64_le_sha256":format!("{:x}",layout_hash.finalize()),
        "typed_states_live_bytes":selected.states.len()*std::mem::size_of::<source::MccState>(),
        "typed_states_capacity_bytes":selected.states.capacity()*std::mem::size_of::<source::MccState>(),
        "typed_layout_capacity_bytes":selected.points.capacity()*std::mem::size_of::<source::Point>(),
        "conservative_retained_accounted_bytes":selected.accounted_bytes,
        "retained_budget_bytes":512usize<<20,"all_other_selected_frame_fields_retained":true,
        "independent_value_comparison_pending":true,"full_Native_integration_pending":true,"p6_complete":false
    });
    let mut file = BufWriter::new(File::options().write(true).create_new(true).open(&output)?);
    serde_json::to_writer_pretty(&mut file, &report)?;
    file.flush()?;
    println!(
        "PASS typed source frame{frame}: {} points; retained accounting{} bytes",
        selected.points.len(),
        selected.accounted_bytes
    );
    Ok(())
}

fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("{e}");
            std::process::ExitCode::FAILURE
        }
    }
}
