//! Dedicated material-continuation sources. Never synthesize a construction Run.
use super::*;
use std::io::Read;

pub(super) const SCHEMA: &str = "soil-fem-solidcraft-mc-epoch-view/1";

#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Metadata {
    origin_manifest: String,
    snapshot: String,
    origin: String,
    mesh: String,
    job: String,
    verification: String,
    parameter_progress: f64,
    path_complete: bool,
    stop_reason: Option<String>,
    stability_classification: String,
}

pub(super) struct Source {
    snapshot: Value,
    metadata: Metadata,
    original_parameters: Vec<Value>,
    current_parameters: Vec<Value>,
    material_ids: Vec<u64>,
}

fn file_hash(root: &Path, name: &str) -> Result<String> {
    if !safe_name(name) {
        return Err(bad(CMD, "unsafe material source path"));
    }
    let path = root.join(name);
    solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
    let mut file = std::fs::File::open(path).map_err(|e| bad(CMD, e.to_string()))?;
    if file.metadata().map_err(|e| bad(CMD, e.to_string()))?.len() > MAX_SOURCE_RESULT as u64 {
        return Err(bad(CMD, "material source exceeds unchanged source limit"));
    }
    let mut hash = Sha256::new();
    let mut buffer = [0u8; 64 << 10];
    let mut count = 0usize;
    loop {
        let n = file.read(&mut buffer).map_err(|e| bad(CMD, e.to_string()))?;
        if n == 0 {
            break;
        }
        count = count.checked_add(n).ok_or_else(|| bad(CMD, "source length overflow"))?;
        if count > MAX_SOURCE_RESULT {
            return Err(bad(CMD, "source grew beyond byte budget"));
        }
        hash.update(buffer.get(..n).ok_or_else(|| bad(CMD, "source buffer size"))?);
    }
    Ok(format!("{:x}", hash.finalize()))
}

fn retained(root: &Path, name: &str, m: &Manifest) -> Result<Value> {
    if !safe_name(name) {
        return Err(bad(CMD, "unsafe material source"));
    }
    let path = root.join(name);
    solidcraft_io::vfs::check(&path.to_string_lossy()).map_err(|e| bad(CMD, e.to_string()))?;
    let file = std::fs::File::open(path).map_err(|e| bad(CMD, e.to_string()))?;
    let (value, hash) = super::super::source_stream::whole(file, MAX_SOURCE_RESULT, MAX_RETAINED_SOURCE / 2).map_err(|e| bad(CMD, e))?;
    if m.job_sources_sha256.get(name) != Some(&hash) {
        return Err(bad(CMD, "retained material source hash mismatch"));
    }
    Ok(value)
}

impl Source {
    pub(super) fn state<'a>(&'a self, origin: &'a Value, index: usize) -> Result<&'a Value> {
        match index {
            0 => origin.get("last_committed"),
            1 => self.snapshot.pointer("/checkpoint/payload/material_checkpoint/payload/committed"),
            _ => None,
        }
        .ok_or_else(|| bad(CMD, "invalid material endpoint index/state"))
    }
    pub(super) fn status(&self, index: usize) -> Value {
        json!({"parameter_progress":self.metadata.parameter_progress,"path_complete":self.metadata.path_complete,
            "displayed_parameter_progress":if index==0 {0.} else {self.metadata.parameter_progress},
            "stop_reason":self.metadata.stop_reason,"stability_classification":"not_evaluated",
            "displayed_endpoint":if index==0 {"unreduced_construction"} else {"accepted_material_continuation"},
            "material_ids":self.material_ids,"parameters":if index==0 {&self.original_parameters} else {&self.current_parameters},
            "increment_reference":"original unreduced construction endpoint; z up"})
    }
    pub(super) fn validate_frame(&self, g: &Geometry, f: &Frame, origin: &SourceRun, mesh: &Value, layout: &[PointMeta]) -> Result<()> {
        let expected = match f.index {
            0 => "Unreduced construction endpoint",
            1 => "Accepted material continuation",
            _ => return Err(bad(CMD, "invalid material frame index")),
        };
        if f.schema != "soil-fem-view-frame/4" || f.name != expected || f.structures.is_some() || f.mixed_primary.is_some() || f.monitors != json!({})
        {
            return Err(bad(CMD, "invalid dedicated material-continuation frame"));
        }
        let state = self.state(origin, f.index)?;
        let previous = self.state(origin, 0)?;
        validate_state_against_source(g, f, origin, mesh, layout, Some((state, previous)))
    }
    fn validate_history(&self, origin: &Value, layout: &[PointMeta]) -> Result<()> {
        let old = self.state(origin, 0)?;
        let current = self.state(origin, 1)?;
        let old_object = old.as_object().ok_or_else(|| bad(CMD, "missing original committed state"))?;
        let current_object = current.as_object().ok_or_else(|| bad(CMD, "missing material committed state"))?;
        if old_object.keys().ne(current_object.keys())
            || old_object.iter().any(|(key, value)| key != "displacement_m" && key != "material_states" && current_object.get(key) != Some(value))
        {
            return Err(bad(CMD, "material path changed construction/load/domain metadata"));
        }
        let mask = current.get("active_elements").and_then(Value::as_array).ok_or_else(|| bad(CMD, "missing material domain"))?;
        let a = old
            .get("material_states")
            .and_then(Value::as_array)
            .filter(|v| v.len() == layout.len())
            .ok_or_else(|| bad(CMD, "original material layout differs"))?;
        let b = current
            .get("material_states")
            .and_then(Value::as_array)
            .filter(|v| v.len() == layout.len())
            .ok_or_else(|| bad(CMD, "current material layout differs"))?;
        for (i, point) in layout.iter().enumerate() {
            let previous = a.get(i).ok_or_else(|| bad(CMD, "missing original material point"))?;
            let now = b.get(i).ok_or_else(|| bad(CMD, "missing current material point"))?;
            let active = mask.get(point.element_index).and_then(Value::as_bool).ok_or_else(|| bad(CMD, "invalid material active flag"))?;
            if !active && previous != now {
                return Err(bad(CMD, "material path changed a removed point history"));
            }
            for key in ["equivalent_plastic_strain", "plastic_work_kpa"] {
                let p = previous
                    .get(key)
                    .and_then(Value::as_f64)
                    .filter(|v| v.is_finite() && *v >= 0.)
                    .ok_or_else(|| bad(CMD, "invalid original MC history"))?;
                let n = now
                    .get(key)
                    .and_then(Value::as_f64)
                    .filter(|v| v.is_finite() && *v >= 0.)
                    .ok_or_else(|| bad(CMD, "invalid current MC history"))?;
                if n + 1e-12 * p.abs().max(1.) < p {
                    return Err(bad(CMD, "material path lost cumulative plastic history"));
                }
            }
        }
        Ok(())
    }
}

pub(super) fn load(root: PathBuf, m: Manifest, manifest_sha: String, expected: &str) -> Result<Loaded> {
    let metadata = m.epoch.clone().ok_or_else(|| bad(CMD, "material manifest lacks dedicated metadata"))?;
    if !m.complete
        || m.input_sha256 != expected
        || m.frames.len() != 2
        || m.geometry != "geometry.json"
        || metadata.origin_manifest != "origin/view/view-manifest.json"
        || metadata.snapshot != "epoch/accepted-snapshot.json"
        || metadata.origin != "epoch/origin.json"
        || metadata.mesh != "epoch/mesh.json"
        || metadata.job != "epoch/job.json"
        || metadata.verification != "epoch/verified.json"
        || !metadata.parameter_progress.is_finite()
        || !(0. ..=1.).contains(&metadata.parameter_progress)
        || metadata.path_complete != (metadata.parameter_progress == 1.)
        || metadata.stability_classification != "not_evaluated"
        || m.semantics.get("length_unit").and_then(Value::as_str) != Some("m")
        || m.semantics.get("stress_unit").and_then(Value::as_str) != Some("kPa")
        || m.semantics.get("stress_sign").and_then(Value::as_str) != Some("compression positive")
        || m.semantics.get("stress_components") != Some(&json!(["xx", "yy", "zz", "xy", "yz", "xz"]))
        || m.job_sources_sha256.len() > 1024
    {
        return Err(bad(CMD, "invalid/incomplete material-continuation view metadata"));
    }
    let origin_manifest: Manifest = json_file(&root, &metadata.origin_manifest, 256 << 10)?;
    if origin_manifest.schema != "soil-fem-solidcraft-view/1" || origin_manifest.epoch.is_some() {
        return Err(bad(CMD, "material origin must be an ordinary continuum workflow"));
    }
    let path = root.join(&metadata.origin_manifest);
    let original = super::load(path.to_str().ok_or_else(|| bad(CMD, "material path must be Unicode"))?, expected)?;
    if (m.cad_sha256.as_str(), m.exporter_binary_sha256.as_str(), m.solver_binary_sha256.as_str())
        != (original.manifest.cad_sha256.as_str(), original.manifest.exporter_binary_sha256.as_str(), original.manifest.solver_binary_sha256.as_str())
    {
        return Err(bad(CMD, "material origin CAD/exporter/solver identity mismatch"));
    }
    let mut total_sources = 0u64;
    for (name, digest) in &m.job_sources_sha256 {
        if !safe_name(name) {
            return Err(bad(CMD, "unsafe material source inventory"));
        }
        total_sources = total_sources.saturating_add(std::fs::metadata(root.join(name)).map_err(|e| bad(CMD, e.to_string()))?.len());
        if total_sources > 2 * MAX_SOURCE_RESULT as u64 + MAX_TOTAL {
            return Err(bad(CMD, "material source aggregate budget exceeded"));
        }
        if !is_sha(digest) || file_hash(&root, name)? != *digest {
            return Err(bad(CMD, "material source inventory checksum mismatch"));
        }
    }
    let audit: Value = json_file(&root, "view-verification.json", 256 << 10)?;
    if audit.get("passed") != Some(&json!(true))
        || audit.get("input_sha256").and_then(Value::as_str) != Some(expected)
        || audit.get("view_manifest_sha256").and_then(Value::as_str) != Some(&manifest_sha)
    {
        return Err(bad(CMD, "material view export audit mismatch"));
    }
    let mut expected_files = BTreeSet::from(["geometry.json".to_owned()]);
    let mut total = 0u64;
    for (i, entry) in m.frames.iter().enumerate() {
        if entry.index != i || entry.frame != format!("frame-{i:03}.json") || entry.integration_points != format!("points-{i:03}.json") {
            return Err(bad(CMD, "invalid material frame inventory"));
        }
        expected_files.insert(entry.frame.clone());
        expected_files.insert(entry.integration_points.clone());
    }
    if expected_files != m.files_sha256.keys().cloned().collect() {
        return Err(bad(CMD, "material display inventory differs"));
    }
    for (name, digest) in &m.files_sha256 {
        let bytes = read(&root, &format!("view/{name}"), MAX_FILE)?;
        total = total.saturating_add(bytes.len() as u64);
        if total > MAX_TOTAL || !is_sha(digest) || sha(&bytes) != *digest {
            return Err(bad(CMD, "material display budget/hash mismatch"));
        }
    }
    let origin = SourceRun::from(retained(&root, &metadata.origin, &m)?);
    let snapshot = retained(&root, &metadata.snapshot, &m)?;
    let mesh = retained(&root, &metadata.mesh, &m)?;
    let job = retained(&root, &metadata.job, &m)?;
    let verified = retained(&root, &metadata.verification, &m)?;
    if m.job_sources_sha256.get(&metadata.origin) != original.manifest.job_sources_sha256.get("analysis/stage-results.json")
        || m.job_sources_sha256.get(&metadata.mesh) != original.manifest.job_sources_sha256.get("analysis/ground/mesh.json")
        || job.pointer("/binding/files_sha256/inputs~1origin.json").and_then(Value::as_str)
            != m.job_sources_sha256.get(&metadata.origin).map(String::as_str)
        || job.pointer("/binding/files_sha256/inputs~1mesh.json").and_then(Value::as_str)
            != m.job_sources_sha256.get(&metadata.mesh).map(String::as_str)
        || job.pointer("/binding/files_sha256/solver~1soil-fem-3d.exe").and_then(Value::as_str) != Some(&m.solver_binary_sha256)
        || snapshot.get("schema").and_then(Value::as_str) != Some("soil-fem-mc-epoch-snapshot/1")
        || snapshot.pointer("/checkpoint/schema").and_then(Value::as_str) != Some("soil-fem-mc-epoch-path-checkpoint/1")
        || snapshot.pointer("/checkpoint/payload/material_checkpoint/schema").and_then(Value::as_str) != Some("soil-fem-mc-epoch-checkpoint/1")
        || job.get("job_id").and_then(Value::as_str).is_none_or(|id| !is_sha(id))
        || snapshot.get("generation").and_then(Value::as_u64).is_none_or(|generation| generation == 0)
        || verified.get("schema").and_then(Value::as_str) != Some("soil-fem-mc-epoch-snapshot-verification/1")
        || verified.get("job_id") != job.get("job_id")
        || snapshot.get("job_id") != job.get("job_id")
        || verified.get("generation") != snapshot.get("generation")
        || verified.get("checkpoint_sha256").and_then(Value::as_str) != m.job_sources_sha256.get(&metadata.snapshot).map(String::as_str)
        || verified.get("payload_sha256") != snapshot.pointer("/checkpoint/payload_sha256")
        || verified.get("progress").and_then(Value::as_f64) != Some(metadata.parameter_progress)
        || verified.get("complete") != Some(&json!(metadata.path_complete))
        || snapshot.pointer("/checkpoint/payload/continuation/progress").and_then(Value::as_f64) != Some(metadata.parameter_progress)
        || verified.get("stop_reason") != snapshot.pointer("/checkpoint/payload/continuation/stop_reason")
        || verified.get("stop_reason") != Some(&json!(metadata.stop_reason))
    {
        return Err(bad(CMD, "material source/verified snapshot binding mismatch"));
    }
    let materials = origin.pointer("/ground/materials").and_then(Value::as_array).ok_or_else(|| bad(CMD, "missing original MC materials"))?;
    let mut material_ids = Vec::new();
    let mut original_parameters = Vec::new();
    for material in materials {
        let id = material
            .get("id")
            .and_then(Value::as_u64)
            .filter(|id| *id > 0 && *id <= u32::MAX as u64 && !material_ids.contains(id))
            .ok_or_else(|| bad(CMD, "invalid/duplicate original MC material id"))?;
        material_ids.push(id);
        original_parameters
            .push(material.get("mohr_coulomb").filter(|v| v.is_object()).cloned().ok_or_else(|| bad(CMD, "material view requires all MC origin"))?);
    }
    let current_parameters = snapshot
        .pointer("/checkpoint/payload/material_checkpoint/payload/parameters")
        .and_then(Value::as_array)
        .filter(|a| a.len() == original_parameters.len())
        .cloned()
        .ok_or_else(|| bad(CMD, "MC parameter table length mismatch"))?;
    for (a, b) in original_parameters.iter().zip(&current_parameters) {
        if ["young_kpa", "poisson", "flow"].iter().any(|key| a.get(key) != b.get(key)) {
            return Err(bad(CMD, "MC view changed elastic constants/flow family"));
        }
        let number = |key: &str| b.get(key).and_then(Value::as_f64).filter(|v| v.is_finite()).ok_or_else(|| bad(CMD, "invalid MC view parameter"));
        let phi = number("friction_deg")?;
        let psi = number("dilation_deg")?;
        if number("young_kpa")? <= 0.
            || !(-1. ..0.5).contains(&number("poisson")?)
            || number("cohesion_kpa")? < 0.
            || !(0. ..89.).contains(&phi)
            || !(0. ..=phi).contains(&psi)
            || b.get("tension_cutoff_kpa").filter(|v| !v.is_null()).is_some_and(|v| v.as_f64().is_none_or(|v| !v.is_finite() || v < 0.))
        {
            return Err(bad(CMD, "MC view parameter outside admissible range"));
        }
    }
    let source = Source { snapshot, metadata, original_parameters, current_parameters, material_ids };
    let geometry: Geometry = hashed(&root, &m.geometry, &m.files_sha256)?;
    validate_geometry(&geometry)?;
    if serde_json::to_value(&geometry.nodes_m).map_err(|e| bad(CMD, e.to_string()))?
        != serde_json::to_value(&original.geometry.nodes_m).map_err(|e| bad(CMD, e.to_string()))?
        || geometry.cells != original.geometry.cells
        || geometry.node_sets != original.geometry.node_sets
        || geometry.crs != original.geometry.crs
        || geometry.origin_m != original.geometry.origin_m
        || geometry.regions != original.geometry.regions
    {
        return Err(bad(CMD, "material geometry differs from Native origin"));
    }
    let layout = source_layout(&geometry, &origin)?;
    source.validate_history(&origin, &layout)?;
    let first = m.frames.first().ok_or_else(|| bad(CMD, "missing material frame"))?;
    let frame: Frame = hashed(&root, &first.frame, &m.files_sha256)?;
    validate_frame(&geometry, &frame, first)?;
    source.validate_frame(&geometry, &frame, &origin, &mesh, &layout)?;
    let settings = Settings::default();
    let scene = Arc::new(geometry::build(&geometry, &frame, &settings, &manifest_sha)?);
    Ok(Loaded {
        root,
        manifest: Arc::new(m),
        manifest_sha,
        geometry: Arc::new(geometry),
        frame: Arc::new(frame),
        source_run: Arc::new(origin),
        source_mesh: Arc::new(mesh),
        epoch: Some(Arc::new(source)),
        layout: Arc::new(layout),
        scene,
        settings,
    })
}
