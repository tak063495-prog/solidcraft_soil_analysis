"""Start full Python only after every required archive was materialized and checked."""
import os,time,subprocess,json
from pathlib import Path
root=Path.cwd();prepared=root/'work/a01hp-preparation';proof=prepared/'recovery/summary.json'
while not proof.exists():time.sleep(10)
manifest=json.loads(proof.read_text())
assert all((root/item['path']).is_file() for job in manifest['results'] for item in job['files'])
env=dict(os.environ)
ps=prepared/'powershell'
env['PATH']=str(ps/'bin')+os.pathsep+env['PATH']
for key,name in [('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data')]:env[key]=str(ps/name)
args=[str(root/'.venv/bin/python'),'interim/2027-01-04-a01-high-precision-nullspace/a01hp_validation.py','python','--output','interim/2027-01-04-a01-high-precision-nullspace/validation/python']
print('All required archives physically present; starting all Python groups.',flush=True)
with (prepared/'python-driver.log').open('x') as f:p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
(prepared/'python-launch.json').write_text(json.dumps(dict(command=args,exit_code=p.returncode,prerequisite_recovery_sha256=__import__('hashlib').sha256(proof.read_bytes()).hexdigest()),indent=2)+'\n')
print('Python driver exit',p.returncode,flush=True)
