"""Fixed-OID filtered recovery; verify working bytes before evicting single-blob caches."""
from pathlib import Path
import subprocess,os,json,time,concurrent.futures,hashlib,threading,shutil
root=Path.cwd();out=root/'work/a01hp-preparation/recovery2';out.mkdir(exist_ok=True);env=dict(os.environ,GIT_NO_LAZY_FETCH='1');base='5984f0955c37542f808335cb17cae5f766356945';paths={}
for line in subprocess.check_output(['git','ls-tree','-r',base],text=True,env=env).splitlines():
 meta,name=line.split('\t');mode,kind,oid=meta.split()
 if kind!='blob' or name.startswith('interim/2026-11-10-nc-postfold-branches/evidence.tar.gz.part'):continue
 if not (root/name).is_file():paths.setdefault(oid,[]).append((name,mode))
logs=out/'fetches';logs.mkdir(exist_ok=True);lock=threading.Lock();completed=0
# Index single-object promisor packs by their sole object, including new packs.
def locate_pack(oid):
 for idx in (root/'.git/objects/pack').glob('pack-*.idx'):
  try:
   with idx.open('rb') as f:
    f.seek(8+255*4);count=int.from_bytes(f.read(4),'big')
    if count!=1:continue
    f.seek(8+256*4);found=f.read(20).hex()
  except FileNotFoundError:
   continue
  if found==oid:return idx
 return None

def fetch(job):
 global completed
 oid,names=job;attempts=[];rows=[]
 exists=subprocess.run(['git','cat-file','-e',oid],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 if not exists:
  for retry in range(3):
   cmd=['git','-c','http.version=HTTP/1.1','-c','fetch.negotiationAlgorithm=noop','-c','gc.auto=0','-c','maintenance.auto=false','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin',oid]
   start=time.monotonic()
   with (logs/(oid+'-'+str(retry)+'.log')).open('x') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   attempts.append(dict(command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
   if p.returncode==0:break
  if p.returncode:raise RuntimeError(oid)
 for name,mode in names:
  path=root/name;path.parent.mkdir(exist_ok=True,parents=True)
  if not path.exists():
   with path.open('xb') as f:subprocess.run(['git','cat-file','blob',oid],env=env,stdout=f,check=True)
  h=hashlib.sha1(('blob '+str(path.stat().st_size)+'\0').encode());s=hashlib.sha256()
  with path.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b);s.update(b)
  assert h.hexdigest()==oid,name
  if mode=='100755':path.chmod(0o755)
  rows.append(dict(path=name,git_blob_sha1=oid,sha256=s.hexdigest(),bytes=path.stat().st_size))
 # As in B-02/C-04, remove only a refetchable, single-blob promisor cache.
 idx=locate_pack(oid);pruned=None
 if idx and idx.with_suffix('.promisor').exists() and idx.with_suffix('.pack').stat().st_size>1024*1024:
  pack=idx.with_suffix('.pack');pruned=dict(pack=pack.name,bytes=pack.stat().st_size,oid=oid)
  for suffix in ('.pack','.idx','.promisor','.rev'):idx.with_suffix(suffix).unlink(missing_ok=True)
 result=dict(files=rows,attempts=attempts,pruned_verified_single_blob_cache=pruned)
 (logs/(oid+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 with lock:
  completed+=1
  if completed%20==0:print('recovered',completed,'/',len(paths),'free_GB',round(shutil.disk_usage(root).free/1e9,2),flush=True)
 return result
print('required missing paths',sum(map(len,paths.values())),'unique blobs',len(paths),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:results=list(pool.map(fetch,sorted(paths.items())))
(out/'summary.json').write_text(json.dumps(dict(base=base,unique_blobs=len(paths),results=results,only_existing_ci_postfold_excluded=True),indent=2)+'\n')
print('ALL RECOVERED',flush=True)
