"""Audit every old physical byte against fixed Git OIDs and prior SHA256s."""
import json,subprocess,hashlib,time,os,re
from pathlib import Path
root=Path.cwd();prep=root/'work/a01hp-preparation';dest=root/'interim/2027-01-04-a01-high-precision-nullspace/validation'
while not (prep/'recovery2/summary.json').exists():time.sleep(10)
base='5984f0955c37542f808335cb17cae5f766356945';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
prior={r['path']:r for r in json.loads((root/'interim/2027-01-03-c04-transient-water-cloud-followup/base-tree-binding.json').read_text())}
rows=[];excluded=[];special=[]
allowed=('interim/2026-12-06-p6-01-status-reconciliation/audit_status.py','interim/2026-12-10-ci-p601-inventory-fix/inventory.toml')
for line in subprocess.check_output(['git','ls-tree','-r',base],text=True,env=env).splitlines():
 meta,name=line.split('\t');mode,kind,oid=meta.split();assert kind=='blob'
 if name.startswith('interim/2026-11-10-nc-postfold-branches/evidence.tar.gz.part'):
  excluded.append(dict(path=name,oid=oid,git_reference_preserved=True,existing_ci_exclusion=True));continue
 path=root/name;assert path.is_file(),name
 h=hashlib.sha1(('blob '+str(path.stat().st_size)+'\0').encode());s=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);s.update(b)
 if name in allowed:
  old=subprocess.check_output(['git','show',base+':'+name],env=env);new=path.read_bytes()
  if name.endswith('inventory.toml'):assert new.startswith(old)
  else:
   pattern=rb"SUPPLEMENTAL_SHA256 = '[0-9a-f]{64}'"
   assert re.sub(pattern,b'PIN',old)==re.sub(pattern,b'PIN',new)
  special.append(dict(path=name,allowed_change_only=True,old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=s.hexdigest()));continue
 assert h.hexdigest()==oid,name
 if name in prior and prior[name]['git_blob_sha1']==oid:assert s.hexdigest()==prior[name]['sha256'],name
 rows.append(dict(path=name,git_blob_sha1=oid,sha256=s.hexdigest(),bytes=path.stat().st_size,exact=True))
 if len(rows)%1000==0:print('verified old files',len(rows),flush=True)
(dest/'base-tree-binding.json').write_text(json.dumps(rows,indent=2)+'\n')
summary=dict(base=base,exact_old_files=len(rows),bytes=sum(r['bytes'] for r in rows),special=special,existing_ci_exclusions=excluded,all_materialized_old_bytes_equal_git=True,missing_required_archives=0)
(dest/'base-preservation-before-full-python.json').write_text(json.dumps(summary,indent=2)+'\n')
(prep/'recovery/summary.json').write_text(json.dumps(dict(base=base,results=[dict(files=rows)],all_required_physical_files_verified=True,only_existing_ci_postfold_excluded=True,prior_cache_race_retained=True),indent=2)+'\n')
print('ALL OLD BYTES VERIFIED; full Python may start',flush=True)
