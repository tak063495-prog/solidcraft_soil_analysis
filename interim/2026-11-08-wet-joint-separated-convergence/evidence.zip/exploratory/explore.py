import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']: os.environ[k]='1'
import sys,time,json,copy,subprocess
from pathlib import Path
sys.path.insert(0,'tools')
import fem_reference as fem
from verify_wet_structures import read
from wet_joint_cycle_reference import reference,serializable,differences,native_fields
p=Path('work/wet-cycle'); mesh=read('examples/joint-water-column-tet10-mesh.json'); ground=read('examples/ground-joint-water-mc.json'); case=read('examples/stages-joint-water-cycle.json')
for n,c in [(64,1),(64,8),(64,32),(128,8),(256,8)]:
 out=p/f'ref-{n}-{c}.json'
 if out.exists():continue
 t=time.monotonic();r=reference(mesh,fem.normalize_ground(copy.deepcopy(ground)),fem.normalize_stage_case(copy.deepcopy(case)),n,c,5)
 out.write_text(json.dumps(serializable(r)));print('ref',n,c,time.monotonic()-t,flush=True)
for n,h in [(64,5e-5),(64,5e-6),(64,5e-7),(128,5e-7),(256,5e-7)]:
 out=p/f'native-{n}-{h}.json'
 if out.exists():continue
 c=copy.deepcopy(case); c['settings']['initial_increment']=1/n
 for s in c['stages']:s['initial_increment']=1/n
 c['joint_system']['maximum_increment_m']=h;c['joint_system']['tangent_step_m']=min(1e-8,h/100)
 cp=p/f'case-{n}-{h}.json';cp.write_text(json.dumps(c));t=time.monotonic()
 with (p/f'native-{n}-{h}.log').open('w') as log:
  r=subprocess.run(['target/release/soil-fem-3d','solve-stages','examples/joint-water-column-tet10-mesh.json','examples/ground-joint-water-mc.json',str(cp),str(out)],stdout=log,stderr=subprocess.STDOUT)
 print('native',n,h,r.returncode,time.monotonic()-t,flush=True)
