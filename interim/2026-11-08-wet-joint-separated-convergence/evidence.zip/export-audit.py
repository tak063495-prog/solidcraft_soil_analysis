import sys, json
from pathlib import Path
sys.path.insert(0,'tools')
from export_stages import export
from verify_joint_water import audit
from verify_wet_structures import read
import fem_reference as fem
p=Path('work/wet-cycle/separated'); rows={}
for key in ['g64-m0.0005','g64-m5e-05','g64-m5e-06','g128-m5e-06','g256-m5e-06','rejected']:
 f=p/key;export(f/'mesh.json',f/'stage-results.json',f/'results')
 rows[key]=audit(read(f/'mesh.json'),fem.normalize_ground(read(f/'ground.json')),read(f/'stage-results.json'),f/'results')
 print(key,'all seven frames exported and audited',flush=True)
(p/'output-audits.json').write_text(json.dumps(rows,indent=2))
